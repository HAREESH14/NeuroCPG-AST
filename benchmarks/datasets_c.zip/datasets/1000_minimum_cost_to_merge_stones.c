#include <stdio.h>
#include <stdlib.h>

int minDeletionSize(char* strs[], int strs_len);

int minDeletionSize(char* strs[], int strs_len)
{
  int rows = strs_len;
  int cols = strs[0];
  int count = 0;
  for (int c = 0; c < cols; ++c)
  {
    for (int r = 1; r < rows; ++r)
    {
      if (strs[r - 1] > strs[r])
      {
        ++count;
        break;
      }
    }

  }

  return count;
}



int main()
{
  return 0;
}


