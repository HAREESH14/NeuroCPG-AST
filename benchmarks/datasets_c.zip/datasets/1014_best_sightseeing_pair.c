#include <stdio.h>
#include <stdlib.h>

int kClosest(int points[], int k);

int kClosest(int points[], int k)
{
  // sort(points); // Needs manual sort implementation
  return copyOfRange(points, 0, k);
}



int main()
{
  return 0;
}


