#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int largestPerimeter(int nums[]);

int largestPerimeter(int nums[])
{
  sort(nums);
  for (int i = strlen(nums) - 1; i >= 2; --i)
  {
    if (nums[i] < (nums[i - 1] + nums[i - 2]))
    {
      return (nums[i] + nums[i - 1]) + nums[i - 2];
    }
  }

  return 0;
}



int main()
{
  return 0;
}


