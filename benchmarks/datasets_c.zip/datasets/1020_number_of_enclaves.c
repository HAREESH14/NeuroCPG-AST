#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxTurbulenceSize(int arr[], int arr_len);

int maxTurbulenceSize(int arr[], int arr_len)
{
  int n = arr_len;
  int result = 1;
  int i = 0;
  while (i < (n - 1))
  {
    if (arr[i] == arr[i + 1])
    {
      i++;
      continue;
    }
    int j = i + 1;
    while ((j < (n - 1)) && ((arr[j] > arr[j + 1]) != (arr[j - 1] > arr[j])))
    {
      j++;
    }

    result = fmax(result, (j - i) + 1);
    i = j;
  }

  return result;
}



int main()
{
  return 0;
}


