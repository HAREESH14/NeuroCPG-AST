#include <stdio.h>
#include <stdlib.h>

int countAndTriples(int nums[], int nums_len);

int countAndTriples(int nums[], int nums_len)
{
  int count = 0;
  for (int i = 0; i < nums_len; i++)
  {
    for (int j = i + 1; j < nums_len; j++)
    {
      for (int k = j + 1; k < nums_len; k++)
      {
        if (((nums[i] & nums[j]) & nums[k]) != 0)
        {
          count++;
        }
      }

    }

  }

  return count;
}



int main()
{
  return 0;
}


