
typedef struct TreeNode {
    int val;
    struct TreeNode *left;
    struct TreeNode *right;
} TreeNode;

#include <stdio.h>
#include <stdlib.h>

int val;
TreeNode left;
TreeNode right;
