#include <stdio.h>
#include <stdlib.h>

int equationsPossible(char* equations[]);
int find(int x, int parent[]);

int equationsPossible(char* equations[])
{
  int parent[26];
  for (int i = 0; i < 26; ++i)
  {
    parent[i] = i;
  }

  for (int _fi1 = 0; _fi1 < (sizeof(equations) / sizeof(equations[0])); _fi1++)
  {
    char* e = equations[_fi1];
    if (e[1] == '=')
    {
      int x = e[0] - 'a';
      int y = e[3] - 'a';
      parent[find(x, parent)] = find(y, parent);
    }
  }

  for (int _fi2 = 0; _fi2 < (sizeof(equations) / sizeof(equations[0])); _fi2++)
  {
    char* e = equations[_fi2];
    if ((e[1] == '!') && (find(e[0] - 'a', parent) == find(e[3] - 'a', parent)))
    {
      return 0;
    }
  }

  return 1;
}



int find(int x, int parent[])
{
  if (parent[x] != x)
  {
    parent[x] = find(parent[x], parent);
  }
  return parent[x];
}



int main()
{
  return 0;
}


