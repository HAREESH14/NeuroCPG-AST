#include <stdio.h>
#include <stdlib.h>

int brokenCalc(int startValue, int target);

int brokenCalc(int startValue, int target)
{
  int operations = 0;
  while (target > startValue)
  {
    target = ((target % 2) == 0 ? target / 2 : target + 1);
    operations++;
  }

  return (operations + startValue) - target;
}



int main()
{
  return 0;
}


