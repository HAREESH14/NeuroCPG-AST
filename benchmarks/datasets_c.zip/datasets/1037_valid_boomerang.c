#include <stdio.h>
#include <stdlib.h>

int minKBitFlips(int nums[], int nums_len, int k);

int minKBitFlips(int nums[], int nums_len, int k)
{
  int n = nums_len;
  int res = 0;
  int flipped = 0;
  int change[n];
  for (int i = 0; i <= (n - k); i++)
  {
    flipped ^= change[i];
    if (nums[i] == flipped)
    {
      res++;
      flipped ^= 1;
      if ((i + k) < n)
      {
        change[i + k] ^= 1;
      }
    }
  }

  for (int i = (n - k) + 1; i < n; i++)
  {
    flipped ^= change[i];
    if (nums[i] == flipped)
    {
      return 1;
    }
  }

  return res;
}



int main()
{
  return 0;
}


