#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int longestOnes(int nums[], int nums_len, int k);

int longestOnes(int nums[], int nums_len, int k)
{
  int left = 0;
  int right = 0;
  int maxOnes = 0;
  int zeroCount = 0;
  while (right < nums_len)
  {
    if (nums[right] == 0)
    {
      zeroCount++;
    }
    while (zeroCount > k)
    {
      if (nums[left] == 0)
      {
        zeroCount--;
      }
      left++;
    }

    maxOnes = fmax(maxOnes, (right - left) + 1);
    right++;
  }

  return maxOnes;
}



int main()
{
  return 0;
}


