#include <stdio.h>
#include <stdlib.h>

int clumsy(int n);

int clumsy(int n)
{
  if (n <= 2)
  {
    return n;
  }
  if (n == 3)
  {
    return 6;
  }
  int result = ((n * (n - 1)) / (n - 2)) + (n - 3);
  n -= 4;
  while (n >= 4)
  {
    result = (result - ((n * (n - 1)) / (n - 2))) + (n - 3);
    n -= 4;
  }

  return result - clumsy(n);
}



int main()
{
  return 0;
}


