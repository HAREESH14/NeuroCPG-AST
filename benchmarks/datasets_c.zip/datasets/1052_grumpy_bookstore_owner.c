#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxSatisfied(int customers[], int customers_len, int grumpy[], int minutes);

int maxSatisfied(int customers[], int customers_len, int grumpy[], int minutes)
{
  int total_customers = 0;
  int max_extra_customers = 0;
  int extra_customers = 0;
  for (int i = 0; i < customers_len; ++i)
  {
    if (grumpy[i] == 0)
    {
      total_customers += customers[i];
    }
    if (i < minutes)
    {
      extra_customers += customers[i] * grumpy[i];
    }
    else
    {
      extra_customers += (customers[i] * grumpy[i]) - (customers[i - minutes] * grumpy[i - minutes]);
    }
    max_extra_customers = fmax(max_extra_customers, extra_customers);
  }

  return total_customers + max_extra_customers;
}



int main()
{
  return 0;
}


