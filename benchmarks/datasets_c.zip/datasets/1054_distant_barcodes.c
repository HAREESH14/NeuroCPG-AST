#include <stdio.h>
#include <stdlib.h>

int bitwiseComplement(int n);

int bitwiseComplement(int n)
{
  int x = 1;
  while (n > x)
  {
    x = (x * 2) + 1;
  }

  return x - n;
}



int main()
{
  return 0;
}


