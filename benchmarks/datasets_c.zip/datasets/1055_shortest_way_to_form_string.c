#include <stdio.h>
#include <stdlib.h>

int numPairsDivisibleBy60(int time[]);

int numPairsDivisibleBy60(int time[])
{
  int count[60];
  int pairs = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(time) / sizeof(time[0])); _fi1++)
  {
    int t = time[_fi1];
    int mod = t % 60;
    pairs += count[(60 - mod) % 60];
    count[mod]++;
  }

  return pairs;
}



int main()
{
  return 0;
}


