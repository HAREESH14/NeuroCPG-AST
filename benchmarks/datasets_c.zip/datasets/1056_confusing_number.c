#include <stdio.h>
#include <stdlib.h>

int shipWithinDays(int weights[], int days);

int shipWithinDays(int weights[], int days)
{
  int left = stream(weights);
  int right = stream(weights);
  while (left < right)
  {
    int mid = left + ((right - left) / 2);
    int day_count = 1;
    int curr_capacity = 0;
    for (int _fi1 = 0; _fi1 < (sizeof(weights) / sizeof(weights[0])); _fi1++)
    {
      int w = weights[_fi1];
      curr_capacity += w;
      if (curr_capacity > mid)
      {
        day_count++;
        curr_capacity = w;
      }
    }

    if (day_count > days)
    {
      left = mid + 1;
    }
    else
    {
      right = mid;
    }
  }

  return left;
}



int main()
{
  return 0;
}


