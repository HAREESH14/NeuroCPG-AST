#include <stdio.h>
#include <stdlib.h>

int findKthPositive(int nums[], int nums_len, int k);

int findKthPositive(int nums[], int nums_len, int k)
{
  int left = 0;
  int right = nums_len;
  while (left < right)
  {
    int mid = left + ((right - left) / 2);
    if (((nums[mid] - mid) - 1) < k)
    {
      left = mid + 1;
    }
    else
    {
      right = mid;
    }
  }

  return left + k;
}



int main()
{
  return 0;
}


