#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int findLongestRepeatingSubstring(char* s);

int findLongestRepeatingSubstring(char* s)
{
  int n = strlen(s);
  int maxSubstrLength = 0;
  for (int len = 1; len <= (n / 2); ++len)
  {
    int maxRepeatCount = 0;
    int repeatCount = 0;
    for (int i = 0; i < (n - len); ++i)
    {
      if (s + i)
      {
        repeatCount++;
      }
      else
      {
        maxRepeatCount = fmax(maxRepeatCount, repeatCount);
        repeatCount = 0;
      }
    }

    maxSubstrLength = fmax(maxSubstrLength, maxRepeatCount * len);
  }

  return maxSubstrLength;
}



int main()
{
  return 0;
}


