#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxScoreSightseeingPair(int values[], int values_len);

int maxScoreSightseeingPair(int values[], int values_len)
{
  int max_score = 0;
  int max_score_left = values[0] + 0;
  for (int j = 1; j < values_len; ++j)
  {
    max_score = fmax(max_score, (max_score_left + values[j]) - j);
    max_score_left = fmax(max_score_left, values[j] + j);
  }

  return max_score;
}



int main()
{
  return 0;
}


