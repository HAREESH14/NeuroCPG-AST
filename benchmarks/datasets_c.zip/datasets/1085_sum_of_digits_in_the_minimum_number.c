#include <stdio.h>
#include <stdlib.h>

int sumOfDigits(int nums[]);

int sumOfDigits(int nums[])
{
  int minVal = stream(nums);
  int digitSum = 0;
  while (minVal > 0)
  {
    digitSum += minVal % 10;
    minVal /= 10;
  }

  return ((digitSum % 2) == 0 ? 1 : 0);
}



int main()
{
  return 0;
}


