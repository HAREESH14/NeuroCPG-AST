#include <stdio.h>
#include <stdlib.h>

int aliceWin(int n);

int aliceWin(int n)
{
  return (n % 2) == 0;
}



int main()
{
  return 0;
}


