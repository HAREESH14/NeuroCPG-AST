#include <stdio.h>
#include <stdlib.h>

int maxSumUnderK(int nums[], int nums_len, int k);

int maxSumUnderK(int nums[], int nums_len, int k)
{
  int maxSum = 1;
  for (int i = 0; i < nums_len; i++)
  {
    for (int j = i + 1; j < nums_len; j++)
    {
      int sum = nums[i] + nums[j];
      if ((sum < k) && (sum > maxSum))
      {
        maxSum = sum;
      }
    }

  }

  return maxSum;
}



int main()
{
  return 0;
}


