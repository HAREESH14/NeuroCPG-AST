#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int distributeCandies(int candies, int num_people);

int distributeCandies(int candies, int num_people)
{
  int result[num_people];
  int i = 0;
  int count = 1;
  while (candies > 0)
  {
    result[i % num_people] += fmin(candies, count);
    candies -= count;
    count++;
    i++;
  }

  return result;
}



int main()
{
  return 0;
}


