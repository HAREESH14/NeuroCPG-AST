#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxUncrossedLines(int nums1[], int nums1_len, int nums2[], int nums2_len);

int maxUncrossedLines(int nums1[], int nums1_len, int nums2[], int nums2_len)
{
  int m = nums1_len;
  int n = nums2_len;
  int dp[m + 1][n + 1];
  for (int i = 1; i <= m; i++)
  {
    for (int j = 1; j <= n; j++)
    {
      if (nums1[i - 1] == nums2[j - 1])
      {
        dp[i][j] = dp[i - 1][j - 1] + 1;
      }
      else
      {
        dp[i][j] = fmax(dp[i - 1][j], dp[i][j - 1]);
      }
    }

  }

  return dp[m][n];
}



int main()
{
  return 0;
}


