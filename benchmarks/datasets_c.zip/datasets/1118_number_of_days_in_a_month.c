#include <stdio.h>
#include <stdlib.h>

int numberOfDays(int year, int month);

int numberOfDays(int year, int month)
{
  if (month == 2)
  {
    if ((((year % 4) == 0) && ((year % 100) != 0)) || ((year % 400) == 0))
    {
      return 29;
    }
    return 28;
  }
  if ((((month == 4) || (month == 6)) || (month == 9)) || (month == 11))
  {
    return 30;
  }
  return 31;
}



int main()
{
  return 0;
}


