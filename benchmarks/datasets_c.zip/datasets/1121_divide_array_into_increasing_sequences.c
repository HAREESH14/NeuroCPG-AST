#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxSumAfterPartitioning(int arr[], int arr_len, int k);

int maxSumAfterPartitioning(int arr[], int arr_len, int k)
{
  int n = arr_len;
  int dp[n + 1];
  for (int i = 1; i <= n; ++i)
  {
    int current_max = 0;
    for (int j = 1; (j <= k) && ((i - j) >= 0); ++j)
    {
      current_max = fmax(current_max, arr[i - j]);
      dp[i] = fmax(dp[i], dp[i - j] + (current_max * j));
    }

  }

  return dp[n];
}



int main()
{
  return 0;
}


