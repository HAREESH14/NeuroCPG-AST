#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* -- HashMap simulation -- */
#define HASHMAP_SIZE 100
typedef struct { int keys[HASHMAP_SIZE]; int vals[HASHMAP_SIZE]; int count; } HashMap;
HashMap hashmap_create() { HashMap m; m.count=0; return m; }
void hashmap_put(HashMap *m,int k,int v){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k){m->vals[i]=v;return;}m->keys[m->count]=k;m->vals[m->count]=v;m->count++;}
int hashmap_get(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return m->vals[i];return -1;}
int hashmap_contains(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return 1;return 0;}
/* -------------------------*/


int longestWellPerformingInterval(int hours[], int hours_len);

int longestWellPerformingInterval(int hours[], int hours_len)
{
  int sum = 0;
  int longest = 0;
  HashMap firstSumIndex = hashmap_create();
  for (int i = 0; i < hours_len; i++)
  {
    sum += (hours[i] > 8 ? 1 : 1);
    if (sum > 0)
    {
      longest = i + 1;
    }
    else
    {
      if (hashmap_contains(&firstSumIndex, sum - 1))
      {
        longest = fmax(longest, i - hashmap_get(&firstSumIndex, sum - 1));
      }
      if (hashmap_contains(&firstSumIndex, sum))
      {
        hashmap_put(&firstSumIndex, sum, i);
      }
    }
  }

  return longest;
}



int main()
{
  return 0;
}


