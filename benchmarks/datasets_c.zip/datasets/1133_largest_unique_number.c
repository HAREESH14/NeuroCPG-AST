#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* lastSubstring(char* s);

char* lastSubstring(char* s)
{
  int i = 0;
  int j = 1;
  int k = 0;
  int n = strlen(s);
  while ((j + k) < n)
  {
    if (s[i + k] == s[j + k])
    {
      k++;
    }
    else
      if (s[i + k] < s[j + k])
    {
      i = j;
      j++;
      k = 0;
    }
    else
    {
      j++;
      k = 0;
    }
  }

  return s + i;
}



int main()
{
  return 0;
}


