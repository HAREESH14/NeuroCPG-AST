#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int isArmstrong(int n);

int isArmstrong(int n)
{
  int power_sum = 0;
  int original = n;
  int k = n;
  while (n > 0)
  {
    int digit = n % 10;
    power_sum += pow(digit, k);
    n /= 10;
  }

  return power_sum == original;
}



int main()
{
  return 0;
}


