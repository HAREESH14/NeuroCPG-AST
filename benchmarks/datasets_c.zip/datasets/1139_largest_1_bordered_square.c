#include <stdio.h>
#include <stdlib.h>

int prevPermOpt1(int arr[], int arr_len);

int prevPermOpt1(int arr[], int arr_len)
{
  int n = arr_len;
  for (int i = n - 2; i >= 0; i--)
  {
    if (arr[i] > arr[i + 1])
    {
      int j = i + 1;
      while ((j < n) && (arr[j] < arr[i]))
      {
        j++;
      }

      int temp = arr[i];
      arr[i] = arr[j - 1];
      arr[j - 1] = temp;
      return arr;
    }
  }

  return arr;
}



int main()
{
  return 0;
}


