#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int movesToMakeZigzag(int nums[], int nums_len);

int movesToMakeZigzag(int nums[], int nums_len)
{
  int evenMoves = 0;
  int oddMoves = 0;
  for (int i = 0; i < nums_len; i++)
  {
    int left = (i > 0 ? nums[i - 1] : 1001);
    int right = (i < (nums_len - 1) ? nums[i + 1] : 1001);
    int minValue = fmin(left, right);
    if (nums[i] >= minValue)
    {
      if ((i % 2) == 0)
      {
        evenMoves += (nums[i] - minValue) + 1;
      }
      else
      {
        oddMoves += (nums[i] - minValue) + 1;
      }
    }
  }

  return fmin(evenMoves, oddMoves);
}



int main()
{
  return 0;
}


