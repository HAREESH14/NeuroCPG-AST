#include <stdio.h>
#include <stdlib.h>

int isMajorityElement(int nums[], int nums_len, int target);

int isMajorityElement(int nums[], int nums_len, int target)
{
  int count = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    if (num == target)
    {
      count++;
    }
    if (count > (nums_len / 2))
    {
      return 1;
    }
  }

  return 0;
}



int main()
{
  return 0;
}


