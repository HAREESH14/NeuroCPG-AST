#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minSwaps(int data[], int data_len);

int minSwaps(int data[], int data_len)
{
  int ones = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(data) / sizeof(data[0])); _fi1++)
  {
    int d = data[_fi1];
    ones += d;
  }

  int cur_ones = 0;
  int max_ones = 0;
  for (int i = 0; i < data_len; i++)
  {
    cur_ones += data[i];
    if (i >= ones)
    {
      cur_ones -= data[i - ones];
    }
    max_ones = fmax(max_ones, cur_ones);
  }

  return ones - max_ones;
}



int main()
{
  return 0;
}


