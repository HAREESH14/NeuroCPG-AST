#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* -- HashMap simulation -- */
#define HASHMAP_SIZE 100
typedef struct { int keys[HASHMAP_SIZE]; int vals[HASHMAP_SIZE]; int count; } HashMap;
HashMap hashmap_create() { HashMap m; m.count=0; return m; }
void hashmap_put(HashMap *m,int k,int v){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k){m->vals[i]=v;return;}m->keys[m->count]=k;m->vals[m->count]=v;m->count++;}
int hashmap_get(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return m->vals[i];return -1;}
int hashmap_contains(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return 1;return 0;}
/* -------------------------*/


int canConvert(char* str1, char* str2);

int canConvert(char* str1, char* str2)
{
  if (strcmp(str1, str2) == 0)
  {
    return 1;
  }
  HashMap conversion = hashmap_create();
  for (int i = 0; i < strlen(str1); ++i)
  {
    if (hashmap_contains(&conversion, str1[i]) && (hashmap_get(&conversion, str1[i]) != str2[i]))
    {
      return 0;
    }
    hashmap_put(&conversion, str1[i], str2[i]);
  }

  return HashSet() < 26;
}



int main()
{
  return 0;
}


