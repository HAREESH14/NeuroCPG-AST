#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int dayOfYear(char* date);
int isLeapYear(int year);

int dayOfYear(char* date)
{
  int daysInMonth[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
  int year = atoi(date + 0);
  int month = atoi(date + 5);
  int day = atoi(date + 8);
  if (isLeapYear(year))
  {
    daysInMonth[1] = 29;
  }
  int result = 0;
  for (int i = 0; i < (month - 1); ++i)
  {
    result += daysInMonth[i];
  }

  return result + day;
}



int isLeapYear(int year)
{
  return (((year % 4) == 0) && ((year % 100) != 0)) || ((year % 400) == 0);
}



int main()
{
  return 0;
}


