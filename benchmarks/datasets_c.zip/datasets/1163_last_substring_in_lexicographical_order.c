#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* lastSubstring(char* s);

char* lastSubstring(char* s)
{
  int maxIndex = 0;
  int curIndex = 1;
  while (curIndex < strlen(s))
  {
    int i = 0;
    while (((curIndex + i) < strlen(s)) && (s[maxIndex + i] == s[curIndex + i]))
    {
      i++;
    }

    if ((curIndex + i) == strlen(s))
    {
      break;
    }
    if (s[maxIndex + i] < s[curIndex + i])
    {
      maxIndex = curIndex;
    }
    curIndex++;
  }

  return s + maxIndex;
}



int main()
{
  return 0;
}


