#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* -- HashMap simulation -- */
#define HASHMAP_SIZE 100
typedef struct { int keys[HASHMAP_SIZE]; int vals[HASHMAP_SIZE]; int count; } HashMap;
HashMap hashmap_create() { HashMap m; m.count=0; return m; }
void hashmap_put(HashMap *m,int k,int v){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k){m->vals[i]=v;return;}m->keys[m->count]=k;m->vals[m->count]=v;m->count++;}
int hashmap_get(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return m->vals[i];return -1;}
int hashmap_contains(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return 1;return 0;}
/* -------------------------*/


const HashMap pathMap;

int createPath(char* path, int value);
int get(char* path);

int createPath(char* path, int value)
{
  if (hashmap_contains(&pathMap, path))
  {
    return 0;
  }
  char* parentPath = path + 0;
  if ((strlen(parentPath) == 0) && hashmap_contains(&pathMap, parentPath))
  {
    return 0;
  }
  hashmap_put(&pathMap, path, value);
  return 1;
}



int get(char* path)
{
  return getOrDefault(path, 1);
}


