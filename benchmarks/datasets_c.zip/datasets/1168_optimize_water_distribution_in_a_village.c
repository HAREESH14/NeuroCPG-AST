#include <stdio.h>
#include <stdlib.h>

void duplicateZeros(int arr[], int arr_len);

void duplicateZeros(int arr[], int arr_len)
{
  int n = arr_len;
  for (int i = 0; i < (n - 1); i++)
  {
    if (arr[i] == 0)
    {
      for (int j = n - 2; j > i; j--)
      {
        arr[j + 1] = arr[j];
      }

      arr[i + 1] = 0;
      i++;
    }
  }

}



int main()
{
  return 0;
}


