#include <stdio.h>
#include <stdlib.h>

int numPrimeArrangements(int n);

int numPrimeArrangements(int n)
{
  int isPrime[n + 1];
  fill(isPrime, 1);
  isPrime[0] = 0;
  isPrime[1] = 0;
  for (int i = 2; (i * i) <= n; i++)
  {
    if (isPrime[i])
    {
      for (int j = i * i; j <= n; j += i)
      {
        isPrime[j] = 0;
      }

    }
  }

  int primeCount = 0;
  for (int i = 2; i <= n; i++)
  {
    if (isPrime[i])
    {
      primeCount++;
    }
  }

  int compositeCount = n - primeCount;
  long res = 1;
  int MOD = 1000000007;
  for (int i = 1; i <= primeCount; i++)
  {
    res = (res * i) % MOD;
  }

  for (int i = 1; i <= compositeCount; i++)
  {
    res = (res * i) % MOD;
  }

  return (int) res;
}



int main()
{
  return 0;
}


