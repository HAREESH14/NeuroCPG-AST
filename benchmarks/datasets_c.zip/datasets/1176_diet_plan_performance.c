#include <stdio.h>
#include <stdlib.h>

int dietPlanPerformance(int calories[], int calories_len, int k, int lower, int upper);

int dietPlanPerformance(int calories[], int calories_len, int k, int lower, int upper)
{
  int points = 0;
  int T = 0;
  for (int i = 0; i < calories_len; i++)
  {
    T += calories[i];
    if (i >= k)
    {
      T -= calories[i - k];
    }
    if (i >= (k - 1))
    {
      if (T < lower)
      {
        points--;
      }
      if (T > upper)
      {
        points++;
      }
    }
  }

  return points;
}



int main()
{
  return 0;
}


