#include <stdio.h>
#include <stdlib.h>

double sampleStats(int count[]);

double sampleStats(int count[])
{
  double minVal = 1;
  double maxVal = 1;
  double mode = 0;
  double median = 0;
  double mean = 0;
  long totalCount = 0;
  long modeCount = 0;
  long curCount = 0;
  double sum = 0;
  for (int i = 0; i <= 255; i++)
  {
    if (count[i] > 0)
    {
      if (minVal == 1)
      {
        minVal = i;
      }
      maxVal = i;
      sum += ((double) i) * count[i];
      totalCount += count[i];
      if (count[i] > modeCount)
      {
        modeCount = count[i];
        mode = i;
      }
    }
  }

  mean = sum / totalCount;
  int isEven = (totalCount % 2) == 0;
  long mid1 = totalCount / 2;
  long mid2 = mid1 - 1;
  if (isEven)
  {
    mid2++;
  }
  for (int i = 0; i <= 255; i++)
  {
    curCount += count[i];
    if (isEven && (curCount >= mid2))
    {
      median += i;
      mid2 = totalCount;
      isEven = 0;
    }
    if (curCount >= mid1)
    {
      median += i;
      break;
    }
  }

  if (!isEven)
  {
    median /= 2;
  }
  return minVal, maxVal, mean, median, mode;
}



int main()
{
  return 0;
}


