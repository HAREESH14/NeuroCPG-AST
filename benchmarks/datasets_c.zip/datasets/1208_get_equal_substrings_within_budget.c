#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int splitString(char* seq);

int splitString(char* seq)
{
  int result[strlen(seq)];
  int count = 0;
  for (int i = 0; i < strlen(seq); ++i)
  {
    if (seq[i] == '(')
    {
      result[i] = count % 2;
      count++;
    }
    else
    {
      count--;
      result[i] = count % 2;
    }
  }

  return result;
}



int main()
{
  return 0;
}


