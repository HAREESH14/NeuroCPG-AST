#include <stdio.h>
#include <stdlib.h>

double trimmedMean(int arr[], int arr_len);

double trimmedMean(int arr[], int arr_len)
{
  int n = arr_len;
  int remove = (int) (n * 0.05);
  sort(arr);
  double sum = 0.0;
  for (int i = remove; i < (n - remove); i++)
  {
    sum += arr[i];
  }

  return sum / (n - (2 * remove));
}



int main()
{
  return 0;
}


