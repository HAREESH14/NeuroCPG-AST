#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* -- HashMap simulation -- */
#define HASHMAP_SIZE 100
typedef struct { int keys[HASHMAP_SIZE]; int vals[HASHMAP_SIZE]; int count; } HashMap;
HashMap hashmap_create() { HashMap m; m.count=0; return m; }
void hashmap_put(HashMap *m,int k,int v){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k){m->vals[i]=v;return;}m->keys[m->count]=k;m->vals[m->count]=v;m->count++;}
int hashmap_get(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return m->vals[i];return -1;}
int hashmap_contains(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return 1;return 0;}
/* -------------------------*/


int longestWPI(int hours[], int hours_len);

int longestWPI(int hours[], int hours_len)
{
  int score = 0;
  int maxLength = 0;
  HashMap firstOccurrence = hashmap_create();
  for (int i = 0; i < hours_len; ++i)
  {
    score += (hours[i] > 8 ? 1 : 1);
    if (score > 0)
    {
      maxLength = i + 1;
    }
    else
    {
      putIfAbsent(score, i);
      if (hashmap_contains(&firstOccurrence, score - 1))
      {
        maxLength = fmax(maxLength, i - hashmap_get(&firstOccurrence, score - 1));
      }
    }
  }

  return maxLength;
}



int main()
{
  return 0;
}


