#include <stdio.h>
#include <stdlib.h>

int findSpecialInteger(int arr[], int arr_len);

int findSpecialInteger(int arr[], int arr_len)
{
  int n = arr_len;
  int requiredCount = n / 4;
  for (int i = 0; i < n; i++)
  {
    if (arr[i] == arr[i + requiredCount])
    {
      return arr[i];
    }
  }

  return 1;
}



int main()
{
  return 0;
}


