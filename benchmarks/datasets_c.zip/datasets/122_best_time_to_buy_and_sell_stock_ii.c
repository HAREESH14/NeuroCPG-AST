#include <stdio.h>
#include <stdlib.h>

int maxProfit(int prices[], int prices_len);

int maxProfit(int prices[], int prices_len)
{
  int max_profit = 0;
  for (int i = 1; i < prices_len; i++)
  {
    if (prices[i] > prices[i - 1])
    {
      max_profit += prices[i] - prices[i - 1];
    }
  }

  return max_profit;
}



int main()
{
  return 0;
}


