#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int replaceElements(int arr[], int arr_len);

int replaceElements(int arr[], int arr_len)
{
  int n = arr_len;
  int maxElement = 1;
  for (int i = n - 1; i >= 0; i--)
  {
    int temp = arr[i];
    arr[i] = maxElement;
    maxElement = fmax(maxElement, temp);
  }

  return arr;
}



int main()
{
  return 0;
}


