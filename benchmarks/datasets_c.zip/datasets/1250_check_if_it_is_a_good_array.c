#include <stdio.h>
#include <stdlib.h>

int isGoodArray(int nums[]);
int gcd(int a, int b);

int isGoodArray(int nums[])
{
  int res = nums[0];
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    res = gcd(res, num);
  }

  return res == 1;
}



int gcd(int a, int b)
{
  return (b == 0 ? a : gcd(b, a % b));
}


