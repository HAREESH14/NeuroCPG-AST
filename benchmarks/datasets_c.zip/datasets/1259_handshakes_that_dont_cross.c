#include <stdio.h>
#include <stdlib.h>

int numberOfWays(int numPeople);

int numberOfWays(int numPeople)
{
  int MOD = 1000000007;
  int dp[(numPeople / 2) + 1];
  dp[0] = 1;
  for (int i = 1; i <= (numPeople / 2); ++i)
  {
    for (int j = 1; j <= i; ++j)
    {
      dp[i] = (dp[i] + ((int) ((((long) dp[i - j]) * dp[j - 1]) % MOD))) % MOD;
    }

  }

  return dp[numPeople / 2];
}



int main()
{
  return 0;
}


