#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int dayOfYear(char* date);

int dayOfYear(char* date)
{
  int year = atoi(date + 0);
  int month = atoi(date + 5);
  int day = atoi(date + 8);
  int daysInMonth[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
  if (((year % 4) == 0) && (((year % 100) != 0) || ((year % 400) == 0)))
  {
    daysInMonth[2] = 29;
  }
  int dayOfYear = 0;
  for (int i = 1; i < month; i++)
  {
    dayOfYear += daysInMonth[i];
  }

  dayOfYear += day;
  return dayOfYear;
}



int main()
{
  return 0;
}


