#include <stdio.h>
#include <stdlib.h>

int numRollsToTarget(int n, int k, int target);

int numRollsToTarget(int n, int k, int target)
{
  const int MOD = 1000000007;
  int dp[n + 1][target + 1];
  dp[0][0] = 1;
  for (int i = 1; i <= n; ++i)
  {
    for (int j = 1; j <= target; ++j)
    {
      for (int l = 1; l <= k; ++l)
      {
        if (j >= l)
        {
          dp[i][j] = (dp[i][j] + dp[i - 1][j - l]) % MOD;
        }
      }

    }

  }

  return dp[n][target];
}



int main()
{
  return 0;
}


