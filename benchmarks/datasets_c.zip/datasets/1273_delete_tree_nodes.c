#include <stdio.h>
#include <stdlib.h>

int countSmallerFrequencies(char* words[], int words_len, char* queries[], int queries_len);

int countSmallerFrequencies(char* words[], int words_len, char* queries[], int queries_len)
{
  int freqWords[words_len];
  for (int i = 0; i < words_len; i++)
  {
    char minChar = words[i];
    freqWords[i] = (int) words[i];
  }

  int ans[queries_len];
  for (int i = 0; i < queries_len; i++)
  {
    char minChar = queries[i];
    int freqQuery = (int) queries[i];
    ans[i] = (int) stream(freqWords);
  }

  return ans;
}



int main()
{
  return 0;
}


