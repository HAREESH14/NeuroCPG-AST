
typedef struct TreeNode {
    int val;
    struct TreeNode *left;
    struct TreeNode *right;
} TreeNode;

#include <stdio.h>
#include <stdlib.h>

int validateBinaryTreeNodes(int n, int leftChild[], int rightChild[]);

int validateBinaryTreeNodes(int n, int leftChild[], int rightChild[])
{
  int parent[n];
  fill(parent, 1);
  for (int i = 0; i < n; i++)
  {
    if (leftChild[i] != 1)
    {
      if (parent[leftChild[i]] != 1)
      {
        return 0;
      }
      parent[leftChild[i]] = i;
    }
    if (rightChild[i] != 1)
    {
      if (parent[rightChild[i]] != 1)
      {
        return 0;
      }
      parent[rightChild[i]] = i;
    }
  }

  int root = 1;
  for (int i = 0; i < n; i++)
  {
    if (parent[i] == 1)
    {
      if (root != 1)
      {
        return 0;
      }
      root = i;
    }
  }

  return root != 1;
}



int main()
{
  return 0;
}


