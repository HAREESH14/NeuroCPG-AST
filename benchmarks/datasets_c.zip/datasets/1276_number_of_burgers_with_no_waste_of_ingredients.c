#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int closestFactors(int num);

int closestFactors(int num)
{
  int factor1 = (int) sqrt(num + 2);
  while (1)
  {
    int factor2 = (num + 2) / factor1;
    if ((factor1 * factor2) == (num + 2))
    {
      return factor1, factor2;
    }
    factor2 = (num + 1) / factor1;
    if ((factor1 * factor2) == (num + 1))
    {
      return factor1, factor2;
    }
    factor1--;
  }

}



int main()
{
  return 0;
}


