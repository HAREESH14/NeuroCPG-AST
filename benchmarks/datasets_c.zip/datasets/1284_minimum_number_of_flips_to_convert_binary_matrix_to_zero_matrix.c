#include <stdio.h>
#include <stdlib.h>

int sumOfDivisorsWithFourDivisors(int nums[]);

int sumOfDivisorsWithFourDivisors(int nums[])
{
  int sum = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    int divCount = 0;
    int divSum = 0;
    for (int i = 1; (i * i) <= num; ++i)
    {
      if ((num % i) == 0)
      {
        divSum += i;
        ++divCount;
        if ((num / i) != i)
        {
          divSum += num / i;
          ++divCount;
        }
      }
      if (divCount > 4)
      {
        break;
      }
    }

    if (divCount == 4)
    {
      sum += divSum;
    }
  }

  return sum;
}



int main()
{
  return 0;
}


