#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxSumSubsequence(int nums[], int nums_len, int k);

int maxSumSubsequence(int nums[], int nums_len, int k)
{
  int n = nums_len;
  int dp[n];
  int result = 0;
  for (int i = 0; i < n; ++i)
  {
    dp[i] = nums[i];
    for (int j = fmax(0, i - k); j < i; ++j)
    {
      dp[i] = fmax(dp[i], dp[j] + nums[i]);
    }

    result = fmax(result, dp[i]);
  }

  return result;
}



int main()
{
  return 0;
}


