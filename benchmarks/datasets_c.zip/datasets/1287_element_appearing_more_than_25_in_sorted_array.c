#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int shortestDistance(int distance[], int distance_len, int start, int destination);

int shortestDistance(int distance[], int distance_len, int start, int destination)
{
  int total_distance = 0;
  int clockwise_distance = 0;
  for (int i = 0; i < distance_len; ++i)
  {
    total_distance += distance[i];
    if ((i >= start) && (i < destination))
    {
      clockwise_distance += distance[i];
    }
  }

  return fmin(clockwise_distance, total_distance - clockwise_distance);
}



int main()
{
  return 0;
}


