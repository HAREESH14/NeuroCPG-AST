#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maximumSum(int arr[], int arr_len);

int maximumSum(int arr[], int arr_len)
{
  int n = arr_len;
  int sumWithoutDeletion[n];
  int sumWithDeletion[n];
  sumWithoutDeletion[0] = arr[0];
  sumWithDeletion[0] = 0;
  int maxSum = arr[0];
  for (int i = 1; i < n; i++)
  {
    sumWithoutDeletion[i] = fmax(arr[i], sumWithoutDeletion[i - 1] + arr[i]);
    sumWithDeletion[i] = fmax(sumWithDeletion[i - 1] + arr[i], sumWithoutDeletion[i - 1]);
    maxSum = fmax(maxSum, fmax(sumWithoutDeletion[i], sumWithDeletion[i]));
  }

  return maxSum;
}



int main()
{
  return 0;
}


