#include <stdio.h>
#include <stdlib.h>

char* dayOfTheWeek(int day, int month, int year);

char* dayOfTheWeek(int day, int month, int year)
{
  char* days[] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
  if (month < 3)
  {
    month += 12;
    year -= 1;
  }
  int k = year % 100;
  int j = year / 100;
  int dayOfWeek = (((((day + ((13 * (month + 1)) / 5)) + k) + (k / 4)) + (5 * j)) + (j / 4)) % 7;
  return days[dayOfWeek];
}



int main()
{
  return 0;
}


