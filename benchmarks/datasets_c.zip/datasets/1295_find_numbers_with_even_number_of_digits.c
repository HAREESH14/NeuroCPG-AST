#include <stdio.h>
#include <stdlib.h>

int minPerimeter(int neededApples);

int minPerimeter(int neededApples)
{
  int layer = 0;
  int apples = 0;
  while (apples < neededApples)
  {
    layer++;
    apples += 12 * layer;
  }

  return 8 * layer;
}



int main()
{
  return 0;
}


