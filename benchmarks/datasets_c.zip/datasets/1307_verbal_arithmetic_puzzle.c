#include <stdio.h>
#include <stdlib.h>

int nthUglyNumber(int n, int a, int b, int c);
long gcd(long a, long b);

int nthUglyNumber(int n, int a, int b, int c)
{
  long ab = (a * b) / gcd(a, b);
  long ac = (a * c) / gcd(a, c);
  long bc = (b * c) / gcd(b, c);
  long abc = (a * ((b * c) / gcd(b, c))) / gcd(a, (b * c) / gcd(b, c));
  long left = 0;
  long right = 2000000000;
  while (left < right)
  {
    long mid = left + ((right - left) / 2);
    long cnt = ((((((mid / a) + (mid / b)) + (mid / c)) - (mid / ab)) - (mid / ac)) - (mid / bc)) + (mid / abc);
    if (cnt < n)
    {
      left = mid + 1;
    }
    else
    {
      right = mid;
    }
  }

  return (int) left;
}



long gcd(long a, long b)
{
  return (b == 0 ? a : gcd(b, a % b));
}



int main()
{
  return 0;
}


