#include <stdio.h>
#include <stdlib.h>

int waterPlants(int plants[], int plants_len, int capacity);

int waterPlants(int plants[], int plants_len, int capacity)
{
  int steps = 0;
  int waterLeft = 0;
  for (int i = 0; i < plants_len; ++i)
  {
    if (waterLeft < plants[i])
    {
      steps += (2 * i) + 1;
      waterLeft = capacity;
    }
    waterLeft -= plants[i];
    steps++;
  }

  return steps;
}



int main()
{
  return 0;
}


