#include <stdio.h>
#include <stdlib.h>

int noZeroIntegers(int n);

int noZeroIntegers(int n)
{
  for (int a = 1; a < n; ++a)
  {
    if ((a == 1) && ((n - a) == 1))
    {
      return a, n - a;
    }
  }

  return 0, 0;
}



int main()
{
  return 0;
}


