#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minCostToMoveChips(int position[]);

int minCostToMoveChips(int position[])
{
  int evenCount = 0;
  int oddCount = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(position) / sizeof(position[0])); _fi1++)
  {
    int i = position[_fi1];
    if ((i % 2) == 0)
    {
      evenCount++;
    }
    else
    {
      oddCount++;
    }
  }

  return fmin(evenCount, oddCount);
}



int main()
{
  return 0;
}


