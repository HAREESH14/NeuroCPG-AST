#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int minCut(char* s);

int minCut(char* s)
{
  int n = strlen(s);
  int dp[n + 1];
  int isPalindrome[n][n];
  for (int i = 0; i <= n; i++)
  {
    dp[i] = i - 1;
  }

  for (int j = 1; j < n; j++)
  {
    for (int i = j; i >= 0; i--)
    {
      if ((s[i] == s[j]) && (((j - i) < 2) || isPalindrome[i + 1][j - 1]))
      {
        isPalindrome[i][j] = 1;
        dp[j + 1] = fmin(dp[j + 1], dp[i] + 1);
      }
    }

  }

  return dp[n];
}



int main()
{
  return 0;
}


