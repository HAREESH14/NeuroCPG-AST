#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* -- HashMap simulation -- */
#define HASHMAP_SIZE 100
typedef struct { int keys[HASHMAP_SIZE]; int vals[HASHMAP_SIZE]; int count; } HashMap;
HashMap hashmap_create() { HashMap m; m.count=0; return m; }
void hashmap_put(HashMap *m,int k,int v){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k){m->vals[i]=v;return;}m->keys[m->count]=k;m->vals[m->count]=v;m->count++;}
int hashmap_get(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return m->vals[i];return -1;}
int hashmap_contains(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return 1;return 0;}
/* -------------------------*/


int longestSubsequence(int arr[], int difference);

int longestSubsequence(int arr[], int difference)
{
  HashMap dp = hashmap_create();
  int maxLength = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(arr) / sizeof(arr[0])); _fi1++)
  {
    int num = arr[_fi1];
    hashmap_put(&dp, num, getOrDefault(num - difference, 0) + 1);
    maxLength = fmax(maxLength, hashmap_get(&dp, num));
  }

  return maxLength;
}



int main()
{
  return 0;
}


