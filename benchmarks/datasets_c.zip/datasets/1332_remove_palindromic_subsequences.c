#include <stdio.h>
#include <stdlib.h>

int countStrings(int n);

int countStrings(int n)
{
  int mod = 1000000007;
  long a = 1;
  long b = 1;
  for (int i = 0; i < n; i++)
  {
    a = (a * 2) % mod;
    b = (b * 3) % mod;
  }

  return (int) (((b - a) + mod) % mod);
}



int main()
{
  return 0;
}


