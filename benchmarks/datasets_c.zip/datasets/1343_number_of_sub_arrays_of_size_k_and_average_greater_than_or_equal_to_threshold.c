#include <stdio.h>
#include <stdlib.h>

int dieSimulator(int n, int rollMax[]);

int dieSimulator(int n, int rollMax[])
{
  int MOD = ((int) 1e9) + 7;
  int dp[6][n + 1];
  int sum[n + 1];
  for (int i = 0; i < 6; i++)
  {
    dp[i][1] = 1;
  }

  sum[1] = 6;
  for (int j = 2; j <= n; j++)
  {
    int cur_sum = 0;
    for (int i = 0; i < 6; i++)
    {
      dp[i][j] = sum[j - 1];
      if (((j - rollMax[i]) - 1) >= 0)
      {
        dp[i][j] = (int) (((((long) dp[i][j]) - sum[(j - rollMax[i]) - 1]) + MOD) % MOD);
        if (((j - rollMax[i]) - 1) >= 1)
        {
          dp[i][j] = (dp[i][j] + dp[i][(j - rollMax[i]) - 1]) % MOD;
        }
      }
      cur_sum = (cur_sum + dp[i][j]) % MOD;
    }

    sum[j] = cur_sum;
  }

  return sum[n];
}



int main()
{
  return 0;
}


