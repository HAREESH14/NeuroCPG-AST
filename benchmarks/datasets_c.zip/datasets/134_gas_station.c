#include <stdio.h>
#include <stdlib.h>

int canCompleteCircuit(int gas[], int gas_len, int cost[]);

int canCompleteCircuit(int gas[], int gas_len, int cost[])
{
  int totalGas = 0;
  int totalCost = 0;
  int start = 0;
  int gasTank = 0;
  for (int i = 0; i < gas_len; i++)
  {
    totalGas += gas[i];
    totalCost += cost[i];
    gasTank += gas[i] - cost[i];
    if (gasTank < 0)
    {
      start = i + 1;
      gasTank = 0;
    }
  }

  return (totalGas < totalCost ? 1 : start);
}



int main()
{
  return 0;
}


