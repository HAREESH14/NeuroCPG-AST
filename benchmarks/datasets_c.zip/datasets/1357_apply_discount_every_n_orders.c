#include <stdio.h>
#include <stdlib.h>
/* -- HashMap simulation -- */
#define HASHMAP_SIZE 100
typedef struct { int keys[HASHMAP_SIZE]; int vals[HASHMAP_SIZE]; int count; } HashMap;
HashMap hashmap_create() { HashMap m; m.count=0; return m; }
void hashmap_put(HashMap *m,int k,int v){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k){m->vals[i]=v;return;}m->keys[m->count]=k;m->vals[m->count]=v;m->count++;}
int hashmap_get(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return m->vals[i];return -1;}
int hashmap_contains(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return 1;return 0;}
/* -------------------------*/


int n;
int discount;
int customerCount;
HashMap pricesMap;

double getBill(int product[], int product_len, int amount[]);

double getBill(int product[], int product_len, int amount[])
{
  customerCount++;
  double total = 0;
  for (int i = 0; i < product_len; i++)
  {
    total += hashmap_get(&pricesMap, product[i]) * amount[i];
  }

  if ((customerCount % n) == 0)
  {
    total *= (100 - discount) / 100.0;
  }
  return total;
}


