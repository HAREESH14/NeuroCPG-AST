#include <stdio.h>
#include <stdlib.h>
/* -- ArrayList simulation -- */
#define AL_INIT_CAP 16
typedef struct { int *data; int size; int capacity; } ArrayList;
ArrayList arraylist_create() { ArrayList a; a.data=(int*)malloc(AL_INIT_CAP*sizeof(int)); a.size=0; a.capacity=AL_INIT_CAP; return a; }
void arraylist_add(ArrayList *a,int v){if(a->size>=a->capacity){a->capacity*=2;a->data=(int*)realloc(a->data,a->capacity*sizeof(int));}a->data[a->size++]=v;}
int arraylist_get(ArrayList *a,int i){return a->data[i];}
void arraylist_free(ArrayList *a){free(a->data);a->data=NULL;a->size=0;}
/* ----------------------------*/


ArrayList circularPermutation(int n, int start);

ArrayList circularPermutation(int n, int start)
{
  ArrayList result = arraylist_create();
  for (int i = 0; i < (1 << n); ++i)
  {
    arraylist_add(&result, start ^ (i ^ (i >> 1)));
  }

  return result;
}



int main()
{
  return 0;
}


