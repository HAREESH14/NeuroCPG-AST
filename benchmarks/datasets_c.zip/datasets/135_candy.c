#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minCandies(int ratings[], int ratings_len);

int minCandies(int ratings[], int ratings_len)
{
  int n = ratings_len;
  int candies[n];
  for (int i = 0; i < n; i++)
  {
    candies[i] = 1;
  }

  for (int i = 1; i < n; i++)
  {
    if (ratings[i] > ratings[i - 1])
    {
      candies[i] = candies[i - 1] + 1;
    }
  }

  for (int i = n - 2; i >= 0; i--)
  {
    if (ratings[i] > ratings[i + 1])
    {
      candies[i] = fmax(candies[i], candies[i + 1] + 1);
    }
  }

  int sum = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(candies) / sizeof(candies[0])); _fi1++)
  {
    int candy = candies[_fi1];
    sum += candy;
  }

  return sum;
}



int main()
{
  return 0;
}


