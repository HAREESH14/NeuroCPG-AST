#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int findClosestDivisors(int num);

int findClosestDivisors(int num)
{
  for (int i = (int) sqrt(num + 2); i >= 1; i--)
  {
    if (((num + 1) % i) == 0)
    {
      return i, (num + 1) / i;
    }
    if (((num + 2) % i) == 0)
    {
      return i, (num + 2) / i;
    }
  }

  return 0;
}



int main()
{
  return 0;
}


