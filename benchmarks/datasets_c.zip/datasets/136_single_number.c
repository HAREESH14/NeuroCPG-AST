#include <stdio.h>
#include <stdlib.h>

int singleNumber(int nums[]);

int singleNumber(int nums[])
{
  int result = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    result ^= num;
  }

  return result;
}



int main()
{
  return 0;
}


