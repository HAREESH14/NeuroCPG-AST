#include <stdio.h>
#include <stdlib.h>

int numberOfSubarrays(int nums[], int nums_len, int k);

int numberOfSubarrays(int nums[], int nums_len, int k)
{
  int n = nums_len;
  int result = 0;
  int count = 0;
  int oddCount[n + 1];
  oddCount[0] = 1;
  for (int i = 0; i < n; i++)
  {
    count += nums[i] % 2;
    if (count >= k)
    {
      result += oddCount[count - k];
    }
    oddCount[count]++;
  }

  return result;
}



int main()
{
  return 0;
}


