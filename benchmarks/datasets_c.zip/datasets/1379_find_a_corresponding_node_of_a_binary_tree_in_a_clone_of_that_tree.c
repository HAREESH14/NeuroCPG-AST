#include <stdio.h>
#include <stdlib.h>

int reconstructMatrix(int upper, int lower, int colsum[], int colsum_len);

int reconstructMatrix(int upper, int lower, int colsum[], int colsum_len)
{
  int result[2][colsum_len];
  for (int i = 0; i < colsum_len; i++)
  {
    if (colsum[i] == 2)
    {
      result[0][i] = 1;
      result[1][i] = 1;
      upper--;
      lower--;
    }
    else
      if (colsum[i] == 1)
    {
      if (upper > lower)
      {
        result[0][i] = 1;
        upper--;
      }
      else
      {
        result[1][i] = 1;
        lower--;
      }
    }
    if ((upper < 0) || (lower < 0))
    {
      return ;
    }
  }

  if ((upper > 0) || (lower > 0))
  {
    return ;
  }
  return result;
}



int main()
{
  return 0;
}


