#include <stdio.h>
#include <stdlib.h>

int singleNumber(int nums[]);

int singleNumber(int nums[])
{
  int ones = 0;
  int twos = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int n = nums[_fi1];
    ones = (ones ^ n) & (~twos);
    twos = (twos ^ n) & (~ones);
  }

  return ones;
}



int main()
{
  return 0;
}


