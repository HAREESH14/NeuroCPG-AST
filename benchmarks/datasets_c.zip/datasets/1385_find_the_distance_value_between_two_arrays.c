#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int findTheDistanceValue(int arr1[], int arr2[], int d);

int findTheDistanceValue(int arr1[], int arr2[], int d)
{
  int distance = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(arr1) / sizeof(arr1[0])); _fi1++)
  {
    int a = arr1[_fi1];
    int found = 1;
    for (int _fi2 = 0; _fi2 < (sizeof(arr2) / sizeof(arr2[0])); _fi2++)
    {
      int b = arr2[_fi2];
      if (abs(a - b) <= d)
      {
        found = 0;
        break;
      }
    }

    if (found)
    {
      distance++;
    }
  }

  return distance;
}



int main()
{
  return 0;
}


