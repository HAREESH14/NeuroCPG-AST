#include <stdio.h>
#include <stdlib.h>

int sumOfFourDivisors(int nums[]);

int sumOfFourDivisors(int nums[])
{
  int sum = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    int count = 0;
    int div_sum = 0;
    for (int i = 1; (i * i) <= num; ++i)
    {
      if ((num % i) == 0)
      {
        count += ((i * i) == num ? 1 : 2);
        div_sum += i + (num / i);
        if (count > 4)
        {
          break;
        }
      }
    }

    if (count == 4)
    {
      sum += div_sum;
    }
  }

  return sum;
}



int main()
{
  return 0;
}


