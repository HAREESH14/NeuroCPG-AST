#include <stdio.h>
#include <stdlib.h>

int countLargestGroup(int n);

int countLargestGroup(int n)
{
  int groups[37];
  int largest_group_size = 0;
  int count_largest_groups = 0;
  for (int i = 1; i <= n; i++)
  {
    int sum = 0;
    int num = i;
    while (num > 0)
    {
      sum += num % 10;
      num /= 10;
    }

    groups[sum]++;
    if (groups[sum] > largest_group_size)
    {
      largest_group_size = groups[sum];
      count_largest_groups = 1;
    }
    else
      if (groups[sum] == largest_group_size)
    {
      count_largest_groups++;
    }
  }

  return count_largest_groups;
}



int main()
{
  return 0;
}


