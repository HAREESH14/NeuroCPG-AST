#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int checkOverlap(int radius, int xCenter, int yCenter, int x1, int y1, int x2, int y2);

int checkOverlap(int radius, int xCenter, int yCenter, int x1, int y1, int x2, int y2)
{
  int xClosest = fmax(x1, fmin(xCenter, x2));
  int yClosest = fmax(y1, fmin(yCenter, y2));
  return (((xCenter - xClosest) * (xCenter - xClosest)) + ((yCenter - yClosest) * (yCenter - yClosest))) <= (radius * radius);
}



int main()
{
  return 0;
}


