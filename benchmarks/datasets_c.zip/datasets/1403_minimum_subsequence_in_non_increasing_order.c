#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int minChangesToDivideString(char* s, int k);

int minChangesToDivideString(char* s, int k)
{
  int n = strlen(s);
  if ((n % k) != 0)
  {
    return 1;
  }
  int chunkCount = n / k;
  int res = 0;
  for (int i = 0; i < k; ++i)
  {
    int counts[26];
    for (int j = i; j < n; j += k)
    {
      ++counts[s[j] - 'a'];
    }

    int maxCount = stream(counts);
    res += chunkCount - maxCount;
  }

  return res;
}



int main()
{
  return 0;
}


