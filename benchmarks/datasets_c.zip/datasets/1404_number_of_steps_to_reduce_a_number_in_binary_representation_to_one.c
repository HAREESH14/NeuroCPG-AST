#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int numSteps(char* s);

int numSteps(char* s)
{
  int steps = 0;
  int carry = 0;
  for (int i = strlen(s) - 1; i > 0; --i)
  {
    int bit = s[i] - '0';
    if ((bit == 1) && (carry == 1))
    {
      carry = 1;
      steps += 2;
    }
    else
      if ((bit == 1) || (carry == 1))
    {
      carry ^= 1;
      steps += 2;
    }
    else
    {
      steps++;
    }
  }

  return steps + carry;
}



int main()
{
  return 0;
}


