#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int smallestDivisor(int nums[], int threshold);

int smallestDivisor(int nums[], int threshold)
{
  int left = 1;
  int right = 1000000;
  while (left < right)
  {
    int mid = (left + right) / 2;
    int sum = 0;
    for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
    {
      int n = nums[_fi1];
      sum += ceil((1.0 * n) / mid);
    }

    if (sum > threshold)
    {
      left = mid + 1;
    }
    else
    {
      right = mid;
    }
  }

  return left;
}



int main()
{
  return 0;
}


