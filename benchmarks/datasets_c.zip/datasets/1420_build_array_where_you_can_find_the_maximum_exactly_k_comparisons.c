#include <stdio.h>
#include <stdlib.h>

int waysToBuildArray(int n, int m, int k);

int waysToBuildArray(int n, int m, int k)
{
  const int mod = 1000000007;
  int dp[n + 1][k + 1];
  dp[0][0] = 1;
  for (int i = 1; i <= n; ++i)
  {
    for (int j = 0; j <= k; ++j)
    {
      for (int x = 1; x <= m; ++x)
      {
        if (j < (i * (x - 1)))
        {
          dp[i][j] = (dp[i][j] + dp[i - 1][j - ((i - 1) * (x - 1))]) % mod;
        }
      }

    }

  }

  return dp[n][k];
}



int main()
{
  return 0;
}


