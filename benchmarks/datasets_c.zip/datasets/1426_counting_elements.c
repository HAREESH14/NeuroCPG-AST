#include <stdio.h>
#include <stdlib.h>

int sumZero(int n);

int sumZero(int n)
{
  int res[n];
  for (int i = 1; i <= (n / 2); i++)
  {
    res[i - 1] = i;
    res[n - i] = -i;
  }

  return res;
}



int main()
{
  return 0;
}


