#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int minStepsToMakePalindrome(char* s);

int minStepsToMakePalindrome(char* s)
{
  int n = strlen(s);
  int dp[n][n];
  for (int i = n - 2; i >= 0; i--)
  {
    for (int j = i + 1; j < n; j++)
    {
      if (s[i] == s[j])
      {
        dp[i][j] = dp[i + 1][j - 1];
      }
      else
      {
        dp[i][j] = 1 + fmin(dp[i + 1][j], dp[i][j - 1]);
      }
    }

  }

  return dp[0][n - 1];
}



int main()
{
  return 0;
}


