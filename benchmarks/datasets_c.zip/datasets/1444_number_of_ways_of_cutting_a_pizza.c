#include <stdio.h>
#include <stdlib.h>

int numberOfSteps(int num);

int numberOfSteps(int num)
{
  int steps = 0;
  while (num != 0)
  {
    steps += ((num % 2) == 0 ? 1 : 2);
    num >>= 1;
  }

  return steps - 1;
}



int main()
{
  return 0;
}


