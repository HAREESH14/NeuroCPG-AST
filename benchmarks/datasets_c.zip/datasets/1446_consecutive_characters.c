#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double angleClock(int hour, int minutes);

double angleClock(int hour, int minutes)
{
  double minuteAngle = 6 * minutes;
  double hourAngle = (30 * hour) + (0.5 * minutes);
  double angle = abs(hourAngle - minuteAngle);
  return fmin(angle, 360 - angle);
}



int main()
{
  return 0;
}


