#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minJumps(int arr[], int arr_len);

int minJumps(int arr[], int arr_len)
{
  int n = arr_len;
  int maxReach = arr[0];
  int step = arr[0];
  int jumps = 1;
  if (n == 1)
  {
    return 0;
  }
  for (int i = 1; i < n; i++)
  {
    if (i == (n - 1))
    {
      return jumps;
    }
    maxReach = fmax(maxReach, i + arr[i]);
    step--;
    if (step == 0)
    {
      jumps++;
      step = maxReach - i;
    }
  }

  return 1;
}



int main()
{
  return 0;
}


