#include <stdio.h>
#include <stdlib.h>

char* largestNumber(int cost[], int target);

char* largestNumber(int cost[], int target)
{
  char* dp[target + 1];
  dp[0] = "";
  for (int i = 0; i < 9; ++i)
  {
    for (int j = cost[i]; j <= target; ++j)
    {
      if (((dp[j - cost[i]] != NULL) && (dp[j - cost[i]] < (j - cost[i]))) && ((dp[j] == NULL) || ((dp[j - cost[i]] + 1) > dp[j])))
      {
        dp[j] = dp[j - cost[i]] + ((char) ('1' + i));
      }
    }

  }

  return (dp[target] == NULL ? "0" : dp[target]);
}



int main()
{
  return 0;
}


