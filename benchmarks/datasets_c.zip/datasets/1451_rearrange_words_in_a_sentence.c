#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minTaps(int n, int ranges[]);

int minTaps(int n, int ranges[])
{
  int intervals[n + 1];
  for (int i = 0; i <= n; i++)
  {
    int left = fmax(0, i - ranges[i]);
    int right = fmin(n, i + ranges[i]);
    intervals[left] = fmax(intervals[left], right - left);
  }

  int position = 0;
  int total_taps = 0;
  int max_reach = 0;
  while (position < n)
  {
    max_reach = fmax(max_reach, position + intervals[position]);
    if (max_reach == position)
    {
      return 1;
    }
    position = max_reach;
    total_taps++;
  }

  return total_taps;
}



int main()
{
  return 0;
}


