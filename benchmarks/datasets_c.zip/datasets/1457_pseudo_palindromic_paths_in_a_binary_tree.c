#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minDifficulty(int jobDifficulty[], int jobDifficulty_len, int d);

int minDifficulty(int jobDifficulty[], int jobDifficulty_len, int d)
{
  int n = jobDifficulty_len;
  if (n < d)
  {
    return 1;
  }
  int dp[d][n];
  dp[0][0] = jobDifficulty[0];
  for (int i = 1; i < n; ++i)
  {
    dp[0][i] = fmax(dp[0][i - 1], jobDifficulty[i]);
  }

  for (int i = 1; i < d; ++i)
  {
    for (int j = i; j < n; ++j)
    {
      int maxD = jobDifficulty[j];
      for (int k = j; k >= i; --k)
      {
        maxD = fmax(maxD, jobDifficulty[k]);
        dp[i][j] = fmin(dp[i][j], dp[i - 1][k - 1] + maxD);
      }

    }

  }

  return dp[d - 1][n - 1];
}



int main()
{
  return 0;
}


