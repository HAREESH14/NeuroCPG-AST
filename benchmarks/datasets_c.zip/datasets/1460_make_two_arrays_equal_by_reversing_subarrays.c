#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int numberOfSubstrings(char* s);

int numberOfSubstrings(char* s)
{
  int res = 0;
  int left = 0;
  int count[3];
  for (int right = 0; right < strlen(s); right++)
  {
    count[s[right] - 'a']++;
    while (((count[0] > 0) && (count[1] > 0)) && (count[2] > 0))
    {
      count[s[left++] - 'a']--;
    }

    res += left;
  }

  return res;
}



int main()
{
  return 0;
}


