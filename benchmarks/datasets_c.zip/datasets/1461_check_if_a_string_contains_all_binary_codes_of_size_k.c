#include <stdio.h>
#include <stdlib.h>

int countOrders(int n);

int countOrders(int n)
{
  long MOD = 1000000007;
  long ans = 1;
  for (int i = 1; i <= n; ++i)
  {
    ans = ((ans * ((2 * i) - 1)) * i) % MOD;
  }

  return (int) ans;
}



int main()
{
  return 0;
}


