#include <stdio.h>
#include <stdlib.h>

int runningSum(int nums[], int nums_len);

int runningSum(int nums[], int nums_len)
{
  for (int i = 1; i < nums_len; i++)
  {
    nums[i] += nums[i - 1];
  }

  return nums;
}



int main()
{
  return 0;
}


