#include <stdio.h>
#include <stdlib.h>

int smallerNumbersThanCurrent(int nums[], int nums_len);

int smallerNumbersThanCurrent(int nums[], int nums_len)
{
  int result[nums_len];
  for (int i = 0; i < nums_len; i++)
  {
    for (int j = 0; j < nums_len; j++)
    {
      if (nums[j] < nums[i])
      {
        result[i]++;
      }
    }

  }

  return result;
}



int main()
{
  return 0;
}


