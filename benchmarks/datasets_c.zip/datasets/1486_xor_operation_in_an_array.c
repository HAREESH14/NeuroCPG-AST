#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int findTheDistanceValue(int arr1[], int arr1_len, int arr2[], int arr2_len, int d);

int findTheDistanceValue(int arr1[], int arr1_len, int arr2[], int arr2_len, int d)
{
  int count = 0;
  for (int i = 0; i < arr1_len; i++)
  {
    int valid = 1;
    for (int j = 0; j < arr2_len; j++)
    {
      if (abs(arr1[i] - arr2[j]) <= d)
      {
        valid = 0;
        break;
      }
    }

    if (valid)
    {
      count++;
    }
  }

  return count;
}



int main()
{
  return 0;
}


