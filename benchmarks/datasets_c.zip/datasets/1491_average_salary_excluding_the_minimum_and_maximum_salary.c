#include <stdio.h>
#include <stdlib.h>

int countPrefixAligned(int flips[], int flips_len);

int countPrefixAligned(int flips[], int flips_len)
{
  int count = 0;
  for (int i = 0; i < flips_len; i++)
  {
    if (flips[i] == (i + 1))
    {
      count++;
    }
  }

  return count;
}



int main()
{
  return 0;
}


