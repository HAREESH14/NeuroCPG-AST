#include <stdio.h>
#include <stdlib.h>

char* longestCommonPrefix(char* strs[], int strs_len);

char* longestCommonPrefix(char* strs[], int strs_len)
{
  if (strs_len == 0)
  {
    return "";
  }
  for (int i = 0; i < strs[0]; ++i)
  {
    char c = strs[0];
    for (int j = 1; j < strs_len; ++j)
    {
      if ((i == strs[j]) || (strs[j] != c))
      {
        return strs[0];
      }
    }

  }

  return strs[0];
}



int main()
{
  return 0;
}


