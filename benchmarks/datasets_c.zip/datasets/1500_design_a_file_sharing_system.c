#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int countLargestGroup(int n);

int countLargestGroup(int n)
{
  int freq[37];
  int maxGroupSize = 0;
  int maxGroupCount = 0;
  for (int i = 1; i <= n; i++)
  {
    int sum = 0;
    int num = i;
    while (num != 0)
    {
      sum += num % 10;
      num = num / 10;
    }

    freq[sum]++;
    maxGroupSize = fmax(maxGroupSize, freq[sum]);
  }

  for (int i = 0; i < 37; i++)
  {
    if (freq[i] == maxGroupSize)
    {
      maxGroupCount++;
    }
  }

  return maxGroupCount;
}



int main()
{
  return 0;
}


