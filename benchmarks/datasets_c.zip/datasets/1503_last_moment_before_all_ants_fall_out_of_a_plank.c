#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int maxSatisfaction(int satisfaction[]);

int maxSatisfaction(int satisfaction[])
{
  sort(satisfaction);
  int ans = 0;
  int total = 0;
  int sum = 0;
  for (int i = strlen(satisfaction) - 1; i >= 0; i--)
  {
    total += satisfaction[i];
    if (total > 0)
    {
      sum += total;
      ans = fmax(ans, sum);
    }
  }

  return ans;
}



int main()
{
  return 0;
}


