#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* longestHappyPrefix(char* s);

char* longestHappyPrefix(char* s)
{
  int n = strlen(s);
  int lps[n];
  int len = 0;
  int i = 1;
  while (i < n)
  {
    if (s[i] == s[len])
    {
      len++;
      lps[i] = len;
      i++;
    }
    else
    {
      if (len != 0)
      {
        len = lps[len - 1];
      }
      else
      {
        lps[i] = 0;
        i++;
      }
    }
  }

  return s + 0;
}



int main()
{
  return 0;
}


