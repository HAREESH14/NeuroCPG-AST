#include <stdio.h>
#include <stdlib.h>
#include <string.h>

const int MOD = 1000000007;

int countGoodStrings(char* s1, char* s2, char* evil);

int countGoodStrings(char* s1, char* s2, char* evil)
{
  int n = strlen(s1);
  int m = strlen(evil);
  int dp[n + 1][m];
  int lps[m];
  int len = 0;
  for (int i = 1; i < m;)
  {
    if (evil[i] == evil[len])
    {
      lps[i++] = ++len;
    }
    else
      if (len > 0)
    {
      len = lps[len - 1];
    }
    else
    {
      ++i;
    }
  }

  dp[0][0] = 1;
  for (int i = 0; i < n; ++i)
  {
    for (int j = 0; j < m; ++j)
    {
      for (int k = 0; k < 2; ++k)
      {
        for (char c = 'a'; c <= (k == 1 ? s2[i] : 'z'); ++c)
        {
          int e = j;
          while ((e > 0) && (c != evil[e]))
          {
            e = lps[e - 1];
          }

          if (c != evil[e])
          {
            e++;
          }
          if (e != m)
          {
            dp[i + 1][k | (c < s2[i] ? 1 : 0)] += dp[i][k];
            dp[i + 1][k | (c < s2[i] ? 1 : 0)] %= MOD;
          }
        }

      }

    }

  }

  return ((dp[n][1] - dp[n][0]) + MOD) % MOD;
}


