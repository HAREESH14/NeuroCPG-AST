#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minStartValue(int nums[]);

int minStartValue(int nums[])
{
  int min_sum = 0;
  int sum = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    sum += num;
    min_sum = fmin(min_sum, sum);
  }

  return 1 - min_sum;
}



int main()
{
  return 0;
}


