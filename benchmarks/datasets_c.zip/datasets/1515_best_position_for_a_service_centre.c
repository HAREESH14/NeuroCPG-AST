#include <stdio.h>
#include <stdlib.h>

int findMinFibonacciNumbers(int k);

int findMinFibonacciNumbers(int k)
{
  if (k == 0)
  {
    return 0;
  }
  int a = 0;
  int b = 1;
  while (b <= k)
  {
    int temp = a;
    a = b;
    b = temp + a;
  }

  return 1 + findMinFibonacciNumbers(k - a);
}



int main()
{
  return 0;
}


