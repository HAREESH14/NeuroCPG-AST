#include <stdio.h>
#include <stdlib.h>

int numWaterBottles(int numBottles, int numExchange);

int numWaterBottles(int numBottles, int numExchange)
{
  int totalBottles = numBottles;
  while (numBottles >= numExchange)
  {
    int newBottles = numBottles / numExchange;
    totalBottles += newBottles;
    numBottles = newBottles + (numBottles % numExchange);
  }

  return totalBottles;
}



int main()
{
  return 0;
}


