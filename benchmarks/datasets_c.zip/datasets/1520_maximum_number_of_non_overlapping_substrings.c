#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int numSteps(char* s);

int numSteps(char* s)
{
  int steps = 0;
  int carry = 0;
  for (int i = strlen(s) - 1; i > 0; --i)
  {
    int current = (s[i] - '0') + carry;
    if (current == 1)
    {
      steps += 2;
      carry = 1;
    }
    else
    {
      steps += carry;
      carry = current;
    }
  }

  return steps + carry;
}



int main()
{
  return 0;
}


