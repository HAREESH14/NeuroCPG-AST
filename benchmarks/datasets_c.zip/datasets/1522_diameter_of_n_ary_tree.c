#include <stdio.h>
#include <stdlib.h>
#include <math.h>

char* stoneGameIII(int stoneValue[], int stoneValue_len);

char* stoneGameIII(int stoneValue[], int stoneValue_len)
{
  int n = stoneValue_len;
  int dp[n + 1];
  dp[n - 1] = stoneValue[n - 1];
  for (int i = n - 2; i >= 0; --i)
  {
    dp[i] = stoneValue[i] - dp[i + 1];
    for (int j = 1; j < 3; ++j)
    {
      if ((i + j) < n)
      {
        dp[i] = fmax(dp[i], stoneValue[i + j] - dp[(i + j) + 1]);
      }
    }

  }

  if (dp[0] > 0)
  {
    return "Alice";
  }
  if (dp[0] < 0)
  {
    return "Bob";
  }
  return "Tie";
}



int main()
{
  return 0;
}


