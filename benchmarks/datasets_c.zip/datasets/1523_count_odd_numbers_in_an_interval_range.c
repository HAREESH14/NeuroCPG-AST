#include <stdio.h>
#include <stdlib.h>

int countOdds(int low, int high);

int countOdds(int low, int high)
{
  return ((high - low) / 2) + (((low % 2) == 1) || ((high % 2) == 1) ? 1 : 0);
}



int main()
{
  return 0;
}


