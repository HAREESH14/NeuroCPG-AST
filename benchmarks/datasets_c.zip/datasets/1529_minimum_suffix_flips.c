#include <stdio.h>
#include <stdlib.h>

int maxDifference(int num);

int maxDifference(int num)
{
  int a = (num + 9) - (num % 10);
  int b = num - (((num / 1000) % 10) * 111);
  return a - b;
}



int main()
{
  return 0;
}


