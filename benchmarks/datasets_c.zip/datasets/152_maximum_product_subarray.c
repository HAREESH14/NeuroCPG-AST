#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxProduct(int nums[], int nums_len);

int maxProduct(int nums[], int nums_len)
{
  int max_so_far = nums[0];
  int min_so_far = nums[0];
  int result = nums[0];
  for (int i = 1; i < nums_len; i++)
  {
    if (nums[i] < 0)
    {
      int temp = max_so_far;
      max_so_far = min_so_far;
      min_so_far = temp;
    }
    max_so_far = fmax(nums[i], max_so_far * nums[i]);
    min_so_far = fmin(nums[i], min_so_far * nums[i]);
    result = fmax(result, max_so_far);
  }

  return result;
}



int main()
{
  return 0;
}


