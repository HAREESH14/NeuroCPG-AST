#include <stdio.h>
#include <stdlib.h>

int findMin(int nums[], int nums_len);

int findMin(int nums[], int nums_len)
{
  int left = 0;
  int right = nums_len - 1;
  while (left < right)
  {
    int mid = left + ((right - left) / 2);
    if (nums[mid] > nums[right])
    {
      left = mid + 1;
    }
    else
    {
      right = mid;
    }
  }

  return nums[left];
}



int main()
{
  return 0;
}


