#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int canConvertString(char* s, char* t, int k);

int canConvertString(char* s, char* t, int k)
{
  if (strlen(s) != strlen(t))
  {
    return 0;
  }
  int count[26];
  for (int i = 0; i < strlen(s); i++)
  {
    int diff = ((t[i] - s[i]) + 26) % 26;
    if (diff > 0)
    {
      count[diff]++;
    }
  }

  for (int i = 1; i < 26; i++)
  {
    if (count[i] > 0)
    {
      if ((((count[i] * 26) - 26) + i) > k)
      {
        return 0;
      }
    }
  }

  return 1;
}



int main()
{
  return 0;
}


