#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int minInsertions(char* s);

int minInsertions(char* s)
{
  int left = 0;
  int res = 0;
  int n = strlen(s);
  for (int i = 0; i < n; i++)
  {
    if (s[i] == '(')
    {
      left++;
    }
    else
    {
      if (left == 0)
      {
        res++;
      }
      else
      {
        left--;
      }
      if ((i == (n - 1)) || (s[i + 1] != ')'))
      {
        res++;
        i++;
      }
    }
  }

  return res + (left * 2);
}



int main()
{
  return 0;
}


