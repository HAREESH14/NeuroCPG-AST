#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int maxPower(char* s);

int maxPower(char* s)
{
  int maxPower = 0;
  int currentPower = 1;
  for (int i = 1; i < strlen(s); i++)
  {
    if (s[i] == s[i - 1])
    {
      currentPower++;
    }
    else
    {
      maxPower = fmax(maxPower, currentPower);
      currentPower = 1;
    }
  }

  return fmax(maxPower, currentPower);
}



int main()
{
  return 0;
}


