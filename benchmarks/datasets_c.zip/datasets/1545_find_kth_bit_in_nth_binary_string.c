#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* largestNumber(int cost[], int target);

char* largestNumber(int cost[], int target)
{
  char* dp[target + 1];
  dp[0] = "";
  for (int t = 1; t <= target; ++t)
  {
    for (int i = 1; i <= 9; ++i)
    {
      if ((t >= cost[i - 1]) && (dp[t - cost[i - 1]] != NULL))
      {
        char* temp = dp[t - cost[i - 1]] + i;
        if ((dp[t] == NULL) || (dp[t] <= strlen(temp)))
        {
          dp[t] = temp;
        }
      }
    }

  }

  return (dp[target] == NULL ? "0" : dp[target]);
}



int main()
{
  return 0;
}


