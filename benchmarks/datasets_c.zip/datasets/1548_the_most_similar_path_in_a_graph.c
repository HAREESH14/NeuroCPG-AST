#include <stdio.h>
#include <stdlib.h>

int kLengthApart(int nums[], int nums_len, int k);

int kLengthApart(int nums[], int nums_len, int k)
{
  int last_one = 1;
  for (int i = 0; i < nums_len; i++)
  {
    if (nums[i] == 1)
    {
      if ((last_one != 1) && ((i - last_one) <= k))
      {
        return 0;
      }
      last_one = i;
    }
  }

  return 1;
}



int main()
{
  return 0;
}


