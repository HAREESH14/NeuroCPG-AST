#include <stdio.h>
#include <stdlib.h>

int findMin(int nums[], int nums_len);

int findMin(int nums[], int nums_len)
{
  int low = 0;
  int high = nums_len - 1;
  while (low < high)
  {
    int mid = low + ((high - low) / 2);
    if (nums[mid] > nums[high])
    {
      low = mid + 1;
    }
    else
      if (nums[mid] < nums[high])
    {
      high = mid;
    }
    else
    {
      high--;
    }
  }

  return nums[low];
}



int main()
{
  return 0;
}


