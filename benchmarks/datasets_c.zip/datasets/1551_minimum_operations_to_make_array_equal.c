#include <stdio.h>
#include <stdlib.h>

int minOperations(int n);

int minOperations(int n)
{
  return (n * n) / 4;
}



int main()
{
  return 0;
}


