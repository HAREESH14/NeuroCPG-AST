#include <stdio.h>
#include <stdlib.h>

int countTriplets(int arr[], int arr_len);

int countTriplets(int arr[], int arr_len)
{
  int n = arr_len;
  int XOR[n + 1];
  for (int i = 0; i < n; i++)
  {
    XOR[i + 1] = XOR[i] ^ arr[i];
  }

  int count = 0;
  for (int i = 0; i < n; i++)
  {
    for (int k = i + 1; k < n; k++)
    {
      if (XOR[i] == XOR[k + 1])
      {
        count += k - i;
      }
    }

  }

  return count;
}



int main()
{
  return 0;
}


