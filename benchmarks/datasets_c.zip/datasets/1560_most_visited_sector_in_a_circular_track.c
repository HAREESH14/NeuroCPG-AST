#include <stdio.h>
#include <stdlib.h>

int busyStudent(int startTime[], int startTime_len, int endTime[], int queryTime);

int busyStudent(int startTime[], int startTime_len, int endTime[], int queryTime)
{
  int count = 0;
  for (int i = 0; i < startTime_len; i++)
  {
    if ((startTime[i] <= queryTime) && (endTime[i] >= queryTime))
    {
      count++;
    }
  }

  return count;
}



int main()
{
  return 0;
}


