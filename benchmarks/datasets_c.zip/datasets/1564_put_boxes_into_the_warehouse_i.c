#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxBoxesInWarehouse(int boxes[], int boxes_len, int warehouse[], int warehouse_len);

int maxBoxesInWarehouse(int boxes[], int boxes_len, int warehouse[], int warehouse_len)
{
  int n = warehouse_len;
  for (int i = 1; i < n; i++)
  {
    warehouse[i] = fmin(warehouse[i], warehouse[i - 1]);
  }

  sort(boxes);
  int boxIndex = boxes_len - 1;
  int boxesCount = 0;
  for (int i = 0; (i < n) && (boxIndex >= 0); i++)
  {
    if (boxes[boxIndex] <= warehouse[i])
    {
      boxesCount++;
      boxIndex--;
    }
  }

  return boxesCount;
}



int main()
{
  return 0;
}


