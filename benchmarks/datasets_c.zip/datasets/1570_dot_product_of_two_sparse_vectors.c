#include <stdio.h>
#include <stdlib.h>

int finalPrices(int prices[], int prices_len);

int finalPrices(int prices[], int prices_len)
{
  for (int i = 0; i < prices_len; i++)
  {
    for (int j = i + 1; j < prices_len; j++)
    {
      if (prices[j] <= prices[i])
      {
        prices[i] -= prices[j];
        break;
      }
    }

  }

  return prices;
}



int main()
{
  return 0;
}


