#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int minTime(char* colors, int neededTime[]);

int minTime(char* colors, int neededTime[])
{
  int res = 0;
  int prev = 1;
  for (int i = 0; i < (strlen(colors) - 1); i++)
  {
    if (colors[i] == colors[i + 1])
    {
      if ((prev == 1) || (neededTime[i] < neededTime[prev]))
      {
        prev = i;
      }
      if (neededTime[i + 1] < neededTime[prev])
      {
        prev = i + 1;
      }
      res += neededTime[prev];
      neededTime[prev] = 1000000;
      prev = 1;
    }
  }

  return res;
}



int main()
{
  return 0;
}


