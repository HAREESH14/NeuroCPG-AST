#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int shuffle(int nums[], int n);

int shuffle(int nums[], int n)
{
  int shuffled[strlen(nums)];
  for (int i = 0; i < n; i++)
  {
    shuffled[2 * i] = nums[i];
    shuffled[(2 * i) + 1] = nums[i + n];
  }

  return shuffled;
}



int main()
{
  return 0;
}


