#include <stdio.h>
#include <stdlib.h>

double average(int salary[], int salary_len);

double average(int salary[], int salary_len)
{
  double sum = 0;
  int minSalary = stream(salary);
  int maxSalary = stream(salary);
  for (int _fi1 = 0; _fi1 < (sizeof(salary) / sizeof(salary[0])); _fi1++)
  {
    int s = salary[_fi1];
    sum += s;
  }

  sum -= minSalary + maxSalary;
  return sum / (salary_len - 2);
}



int main()
{
  return 0;
}


