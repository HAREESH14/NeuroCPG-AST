#include <stdio.h>
#include <stdlib.h>

int kthFactor(int n, int k);

int kthFactor(int n, int k)
{
  for (int i = 1; i <= n; ++i)
  {
    if ((n % i) == 0)
    {
      --k;
      if (k == 0)
      {
        return i;
      }
    }
  }

  return 1;
}



int main()
{
  return 0;
}


