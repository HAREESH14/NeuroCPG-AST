#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* -- HashMap simulation -- */
#define HASHMAP_SIZE 100
typedef struct { int keys[HASHMAP_SIZE]; int vals[HASHMAP_SIZE]; int count; } HashMap;
HashMap hashmap_create() { HashMap m; m.count=0; return m; }
void hashmap_put(HashMap *m,int k,int v){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k){m->vals[i]=v;return;}m->keys[m->count]=k;m->vals[m->count]=v;m->count++;}
int hashmap_get(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return m->vals[i];return -1;}
int hashmap_contains(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return 1;return 0;}
/* -------------------------*/


int findMaxLength(int nums[], int nums_len);

int findMaxLength(int nums[], int nums_len)
{
  int max_length = 0;
  int zeroes = 0;
  int ones = 0;
  HashMap count_map = hashmap_create();
  hashmap_put(&count_map, 0, 1);
  for (int i = 0; i < nums_len; ++i)
  {
    if (nums[i] == 0)
    {
      zeroes++;
    }
    else
    {
      ones++;
    }
    if (hashmap_contains(&count_map, zeroes - ones))
    {
      hashmap_put(&count_map, zeroes - ones, i);
    }
    else
    {
      max_length = fmax(max_length, i - hashmap_get(&count_map, zeroes - ones));
    }
  }

  return max_length;
}



int main()
{
  return 0;
}


