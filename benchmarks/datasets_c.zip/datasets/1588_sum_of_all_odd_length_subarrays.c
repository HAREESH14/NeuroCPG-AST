#include <stdio.h>
#include <stdlib.h>

int sumOddLengthSubarrays(int arr[], int arr_len);

int sumOddLengthSubarrays(int arr[], int arr_len)
{
  int sum = 0;
  int n = arr_len;
  for (int i = 0; i < n; i++)
  {
    int oddSubarrays = (((i + 1) * (n - i)) + 1) / 2;
    sum += arr[i] * oddSubarrays;
  }

  return sum;
}



int main()
{
  return 0;
}


