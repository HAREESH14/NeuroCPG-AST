#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* -- HashMap simulation -- */
#define HASHMAP_SIZE 100
typedef struct { int keys[HASHMAP_SIZE]; int vals[HASHMAP_SIZE]; int count; } HashMap;
HashMap hashmap_create() { HashMap m; m.count=0; return m; }
void hashmap_put(HashMap *m,int k,int v){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k){m->vals[i]=v;return;}m->keys[m->count]=k;m->vals[m->count]=v;m->count++;}
int hashmap_get(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return m->vals[i];return -1;}
int hashmap_contains(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return 1;return 0;}
/* -------------------------*/


int minSubarray(int nums[], int nums_len, int p);

int minSubarray(int nums[], int nums_len, int p)
{
  int n = nums_len;
  int res = n;
  int need = 0;
  int cur = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    need = (need + num) % p;
  }

  if (need == 0)
  {
    return 0;
  }
  HashMap last_seen = hashmap_create();
  hashmap_put(&last_seen, 0, 1);
  for (int i = 0; i < n; i++)
  {
    cur = (cur + nums[i]) % p;
    hashmap_put(&last_seen, cur, i);
    res = fmin(res, i - getOrDefault(((cur - need) + p) % p, -n));
  }

  return (res < n ? res : 1);
}



int main()
{
  return 0;
}


