#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int minOperations(char* logs[]);

int minOperations(char* logs[])
{
  int depth = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(logs) / sizeof(logs[0])); _fi1++)
  {
    char* log = logs[_fi1];
    if (strcmp(log, "../") == 0)
    {
      depth = fmax(0, depth - 1);
    }
    else
      if (strcmp(log, "./") == 0)
    {
      depth += 1;
    }
  }

  return depth;
}



int main()
{
  return 0;
}


