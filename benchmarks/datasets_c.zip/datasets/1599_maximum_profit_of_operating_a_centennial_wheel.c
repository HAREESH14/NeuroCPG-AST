#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minOperationsMaxProfit(int customers[], int customers_len, int boardingCost, int runningCost);

int minOperationsMaxProfit(int customers[], int customers_len, int boardingCost, int runningCost)
{
  int waiting = 0;
  int profit = 0;
  int max_profit = 0;
  int rotations = 0;
  int result = 1;
  for (int i = 0; (i < customers_len) || (waiting > 0); ++i)
  {
    if (i < customers_len)
    {
      waiting += customers[i];
    }
    int boarding = fmin(waiting, 4);
    waiting -= boarding;
    profit += (boarding * boardingCost) - runningCost;
    if (profit > max_profit)
    {
      max_profit = profit;
      result = rotations + 1;
    }
    rotations++;
  }

  return result;
}



int main()
{
  return 0;
}


