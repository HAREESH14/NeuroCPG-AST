#include <stdio.h>
#include <stdlib.h>

int minDays(int bloomDay[], int m, int k);

int minDays(int bloomDay[], int m, int k)
{
  int left = stream(bloomDay);
  int right = stream(bloomDay);
  while (left < right)
  {
    int mid = left + ((right - left) / 2);
    int bouquets = 0;
    int flowers = 0;
    for (int _fi1 = 0; _fi1 < (sizeof(bloomDay) / sizeof(bloomDay[0])); _fi1++)
    {
      int day = bloomDay[_fi1];
      if (day > mid)
      {
        flowers = 0;
      }
      else
      {
        flowers++;
        if (flowers == k)
        {
          bouquets++;
          flowers = 0;
        }
      }
    }

    if (bouquets >= m)
    {
      right = mid;
    }
    else
    {
      left = mid + 1;
    }
  }

  return (m == 0 ? 1 : left);
}



int main()
{
  return 0;
}


