#include <stdio.h>
#include <stdlib.h>

int specialArray(int nums[]);

int specialArray(int nums[])
{
  int max_val = stream(nums);
  for (int x = 1; x <= max_val; ++x)
  {
    int count = 0;
    for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
    {
      int num = nums[_fi1];
      if (num >= x)
      {
        count++;
      }
    }

    if (count == x)
    {
      return x;
    }
  }

  return 1;
}



int main()
{
  return 0;
}


