#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minDifference(int nums[], int nums_len);

int minDifference(int nums[], int nums_len)
{
  int size = nums_len;
  if (size < 5)
  {
    return 0;
  }
  sort(nums);
  return fmin(fmin(nums[size - 1] - nums[3], nums[size - 2] - nums[2]), fmin(nums[size - 3] - nums[1], nums[size - 4] - nums[0]));
}



int main()
{
  return 0;
}


