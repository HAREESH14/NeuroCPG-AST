#include <stdio.h>
#include <stdlib.h>

int winnerSquareGame(int n);

int winnerSquareGame(int n)
{
  int dp[n + 1];
  for (int i = 1; i <= n; i++)
  {
    for (int j = 1; (j * j) <= i; j++)
    {
      if (!dp[i - (j * j)])
      {
        dp[i] = 1;
        break;
      }
    }

  }

  return dp[n];
}



int main()
{
  return 0;
}


