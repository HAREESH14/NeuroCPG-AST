#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int isOneEditDistance(char* s, char* t);

int isOneEditDistance(char* s, char* t)
{
  int m = strlen(s);
  int n = strlen(t);
  if (m > n)
  {
    return isOneEditDistance(t, s);
  }
  if ((n - m) > 1)
  {
    return 0;
  }
  for (int i = 0; i < m; ++i)
  {
    if (s[i] != t[i])
    {
      if (m < n)
      {
        return s + i;
      }
      else
      {
        return s + (i + 1);
      }
    }
  }

  return (m + 1) == n;
}



int main()
{
  return 0;
}


