#include <stdio.h>
#include <stdlib.h>

int numSubseq(int nums[], int nums_len, int target);

int numSubseq(int nums[], int nums_len, int target)
{
  int n = nums_len;
  int mod = 1000000007;
  sort(nums);
  long power[n];
  power[0] = 1;
  for (int i = 1; i < n; ++i)
  {
    power[i] = (power[i - 1] * 2) % mod;
  }

  int ans = 0;
  int r = n;
  for (int l = 0; l < n; ++l)
  {
    while ((r > l) && ((nums[l] + nums[r - 1]) > target))
    {
      --r;
    }

    ans = (ans + ((int) power[r - l])) % mod;
  }

  return ans;
}


