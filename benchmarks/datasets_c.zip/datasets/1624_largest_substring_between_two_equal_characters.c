#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
/* -- HashMap simulation -- */
#define HASHMAP_SIZE 100
typedef struct { int keys[HASHMAP_SIZE]; int vals[HASHMAP_SIZE]; int count; } HashMap;
HashMap hashmap_create() { HashMap m; m.count=0; return m; }
void hashmap_put(HashMap *m,int k,int v){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k){m->vals[i]=v;return;}m->keys[m->count]=k;m->vals[m->count]=v;m->count++;}
int hashmap_get(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return m->vals[i];return -1;}
int hashmap_contains(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return 1;return 0;}
/* -------------------------*/


int maxLengthBetweenEqualCharacters(char* s);

int maxLengthBetweenEqualCharacters(char* s)
{
  int result = 1;
  HashMap char_map = hashmap_create();
  for (int i = 0; i < strlen(s); ++i)
  {
    if (hashmap_contains(&char_map, s[i]))
    {
      hashmap_put(&char_map, s[i], i);
    }
    else
    {
      result = fmax(result, (i - hashmap_get(&char_map, s[i])) - 1);
    }
  }

  return result;
}



int main()
{
  return 0;
}


