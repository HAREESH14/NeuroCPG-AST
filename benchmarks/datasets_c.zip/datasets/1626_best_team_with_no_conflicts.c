#include <stdio.h>
#include <stdlib.h>

int canMakeArithmeticProgression(int arr[], int arr_len);

int canMakeArithmeticProgression(int arr[], int arr_len)
{
  sort(arr);
  int difference = arr[1] - arr[0];
  for (int i = 2; i < arr_len; i++)
  {
    if ((arr[i] - arr[i - 1]) != difference)
    {
      return 0;
    }
  }

  return 1;
}



int main()
{
  return 0;
}


