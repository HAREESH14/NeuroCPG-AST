#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int lastMoment(int n, int left[], int right[]);

int lastMoment(int n, int left[], int right[])
{
  int max_left = 0;
  int min_right = n;
  for (int _fi1 = 0; _fi1 < (sizeof(left) / sizeof(left[0])); _fi1++)
  {
    int position = left[_fi1];
    max_left = fmax(max_left, position);
  }

  for (int _fi2 = 0; _fi2 < (sizeof(right) / sizeof(right[0])); _fi2++)
  {
    int position = right[_fi2];
    min_right = fmin(min_right, position);
  }

  return fmax(max_left, n - min_right);
}



int main()
{
  return 0;
}


