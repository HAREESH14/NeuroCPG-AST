#include <stdio.h>
#include <stdlib.h>

int findPeakElement(int nums[], int nums_len);

int findPeakElement(int nums[], int nums_len)
{
  int left = 0;
  int right = nums_len - 1;
  while (left < right)
  {
    int mid = left + ((right - left) / 2);
    if (nums[mid] < nums[mid + 1])
    {
      left = mid + 1;
    }
    else
    {
      right = mid;
    }
  }

  return left;
}



int main()
{
  return 0;
}


