#include <stdio.h>
#include <stdlib.h>

int countOdds(int low, int high);

int countOdds(int low, int high)
{
  return ((high + 1) / 2) - (low / 2);
}



int main()
{
  return 0;
}


