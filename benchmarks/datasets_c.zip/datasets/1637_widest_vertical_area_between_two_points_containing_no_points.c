#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int min_length_encoded(char* s, int k);

int min_length_encoded(char* s, int k)
{
  int n = strlen(s);
  int dp[n + 1][k + 1];
  for (int i = 1; i <= n; ++i)
  {
    for (int j = 0; j <= k; ++j)
    {
      int cnt = 1;
      dp[i][j] = i - j;
      for (int l = i - 2; (l >= 0) && (((i - 2) - l) <= j); --l)
      {
        if (s[l] == s[i - 1])
        {
          cnt++;
        }
        else
        {
          cnt = 1;
        }
        int used = (i - 2) - l;
        int new_aposition = (((i - 1) - cnt) - used) + 1;
        if (cnt >= 100)
        {
          new_aposition += 4;
        }
        else
          if (cnt >= 10)
        {
          new_aposition += 3;
        }
        else
          if (cnt >= 2)
        {
          new_aposition += 2;
        }
        else
        {
          new_aposition++;
        }
        dp[i][j] = fmin(dp[i][j], new_aposition + dp[l][j - used]);
      }

    }

  }

  return dp[n][k];
}



int main()
{
  return 0;
}


