#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int numWays(char* words[], int words_len, char* target);

int numWays(char* words[], int words_len, char* target)
{
  int n = words_len;
  int m = strlen(target);
  int count[n][26];
  int dp[m][n];
  const int mod = 1000000007;
  for (int i = 0; i < n; i++)
  {
    for (int _fi1 = 0; _fi1 < (sizeof(words[i]) / sizeof(words[i][0])); _fi1++)
    {
      char c = words[i][_fi1];
      count[i][c - 'a']++;
    }

  }

  for (int i = 0; i < n; i++)
  {
    dp[0][i] = count[i][target[0] - 'a'];
  }

  for (int i = 1; i < m; i++)
  {
    for (int j = 0; j < n; j++)
    {
      for (int k = 0; k < n; k++)
      {
        dp[i][j] = (dp[i][j] + ((int) ((((long) dp[i - 1][k]) * count[j][target[i] - 'a']) % mod))) % mod;
      }

    }

  }

  int res = 0;
  for (int i = 0; i < n; i++)
  {
    res = (res + dp[m - 1][i]) % mod;
  }

  return res;
}



int main()
{
  return 0;
}


