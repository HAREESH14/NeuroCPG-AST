#include <stdio.h>
#include <stdlib.h>

int countVowelStrings(int n);

int countVowelStrings(int n)
{
  int dp[] = {1, 1, 1, 1, 1};
  for (int i = 2; i <= n; i++)
  {
    for (int j = 3; j >= 0; j--)
    {
      dp[j] = dp[j] + dp[j + 1];
    }

  }

  return stream(dp);
}



int main()
{
  return 0;
}


