#include <stdio.h>
#include <stdlib.h>

int maxWaterBottles(int numBottles, int numExchange);

int maxWaterBottles(int numBottles, int numExchange)
{
  int total = numBottles;
  while (numBottles >= numExchange)
  {
    int newBottles = numBottles / numExchange;
    total += newBottles;
    numBottles = newBottles + (numBottles % numExchange);
  }

  return total;
}



int main()
{
  return 0;
}


