#include <stdio.h>
#include <stdlib.h>

int findKthPositive(int arr[], int arr_len, int k);

int findKthPositive(int arr[], int arr_len, int k)
{
  int i = 0;
  int num = 1;
  while (k > 0)
  {
    if ((i < arr_len) && (arr[i] == num))
    {
      i++;
    }
    else
    {
      k--;
    }
    num++;
  }

  return num - 1;
}



int main()
{
  return 0;
}


