#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int canConvert(char* s, char* t, int k);

int canConvert(char* s, char* t, int k)
{
  int diff = 0;
  for (int i = 0; i < strlen(s); i++)
  {
    int curr_diff = ((t[i] - s[i]) + 26) % 26;
    if (curr_diff > 0)
    {
      diff += curr_diff;
      k -= curr_diff;
    }
  }

  return ((k >= 0) && (k >= (diff - strlen(s)))) && ((k % 26) == 0);
}



int main()
{
  return 0;
}


