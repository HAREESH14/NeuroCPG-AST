#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int countGoodTriplets(int arr[], int arr_len, int a, int b, int c);

int countGoodTriplets(int arr[], int arr_len, int a, int b, int c)
{
  int count = 0;
  for (int i = 0; i < arr_len; i++)
  {
    for (int j = i + 1; j < arr_len; j++)
    {
      if (abs(arr[i] - arr[j]) <= a)
      {
        for (int k = j + 1; k < arr_len; k++)
        {
          if ((abs(arr[j] - arr[k]) <= b) && (abs(arr[i] - arr[k]) <= c))
          {
            count++;
          }
        }

      }
    }

  }

  return count;
}



int main()
{
  return 0;
}


