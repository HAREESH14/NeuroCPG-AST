#include <stdio.h>
#include <stdlib.h>

int getWinner(int arr[], int arr_len, int k);

int getWinner(int arr[], int arr_len, int k)
{
  int winner = arr[0];
  int consecutiveWins = 0;
  for (int i = 1; i < arr_len; i++)
  {
    if (arr[i] > winner)
    {
      winner = arr[i];
      consecutiveWins = 0;
    }
    if ((++consecutiveWins) == k)
    {
      break;
    }
  }

  return winner;
}



int main()
{
  return 0;
}


