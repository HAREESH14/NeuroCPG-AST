#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int compareVersion(char* version1, char* version2);

int compareVersion(char* version1, char* version2)
{
  int i = 0;
  int j = 0;
  while ((i < strlen(version1)) || (j < strlen(version2)))
  {
    int num1 = 0;
    int num2 = 0;
    while ((i < strlen(version1)) && (version1[i] != '.'))
    {
      num1 = (num1 * 10) + (version1[i++] - '0');
    }

    while ((j < strlen(version2)) && (version2[j] != '.'))
    {
      num2 = (num2 * 10) + (version2[j++] - '0');
    }

    if (num1 < num2)
    {
      return 1;
    }
    if (num1 > num2)
    {
      return 1;
    }
    i++;
    j++;
  }

  return 0;
}



int main()
{
  return 0;
}


