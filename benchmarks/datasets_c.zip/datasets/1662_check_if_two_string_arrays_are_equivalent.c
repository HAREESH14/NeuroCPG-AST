#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minNumOperations(int nums[]);

int minNumOperations(int nums[])
{
  int result = 0;
  int highestBit[32];
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    for (int j = 0; j < 32; j++)
    {
      if ((num & (1 << j)) != 0)
      {
        highestBit[j]++;
      }
    }

  }

  for (int _fi2 = 0; _fi2 < (sizeof(highestBit) / sizeof(highestBit[0])); _fi2++)
  {
    int count = highestBit[_fi2];
    result = fmax(result, count);
  }

  return result + 31;
}



int main()
{
  return 0;
}


