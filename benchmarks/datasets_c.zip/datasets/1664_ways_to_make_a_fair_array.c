#include <stdio.h>
#include <stdlib.h>

int numberOfFairs(int nums[], int nums_len);

int numberOfFairs(int nums[], int nums_len)
{
  int even_sum = 0;
  int odd_sum = 0;
  int l_even = 0;
  int l_odd = 0;
  int count = 0;
  for (int i = 0; i < nums_len; ++i)
  {
    if ((i % 2) == 0)
    {
      even_sum += nums[i];
    }
    else
    {
      odd_sum += nums[i];
    }
  }

  for (int i = 0; i < nums_len; ++i)
  {
    if ((i % 2) == 0)
    {
      even_sum -= nums[i];
      if ((l_even + odd_sum) == (l_odd + even_sum))
      {
        ++count;
      }
      l_even += nums[i];
    }
    else
    {
      odd_sum -= nums[i];
      if ((l_even + odd_sum) == (l_odd + even_sum))
      {
        ++count;
      }
      l_odd += nums[i];
    }
  }

  return count;
}



int main()
{
  return 0;
}


