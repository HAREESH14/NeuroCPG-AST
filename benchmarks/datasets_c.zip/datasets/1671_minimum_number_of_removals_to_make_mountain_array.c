#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minimumMountainRemovals(int nums[], int nums_len);

int minimumMountainRemovals(int nums[], int nums_len)
{
  int n = nums_len;
  int left[n];
  int right[n];
  for (int i = 1; i < n; ++i)
  {
    left[i] = left[i - 1] + (nums[i] > nums[i - 1] ? 1 : 0);
    right[(n - i) - 1] = right[n - i] + (nums[(n - i) - 1] > nums[n - i] ? 1 : 0);
  }

  int ans = n - 3;
  for (int i = 1; i < (n - 1); ++i)
  {
    ans = fmin(ans, ((n - 1) - left[i]) - right[i]);
  }

  return ans;
}



int main()
{
  return 0;
}


