#include <stdio.h>
#include <stdlib.h>

int minOperations(int n);

int minOperations(int n)
{
  return (n * (n - 1)) / 2;
}



int main()
{
  return 0;
}


