#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int findLengthOfShortestSubarray(int arr[], int arr_len);

int findLengthOfShortestSubarray(int arr[], int arr_len)
{
  int n = arr_len;
  int left = 0;
  int right = n - 1;
  while ((left < (n - 1)) && (arr[left] <= arr[left + 1]))
  {
    left++;
  }

  if (left == (n - 1))
  {
    return 0;
  }
  while ((right > 0) && (arr[right] >= arr[right - 1]))
  {
    right--;
  }

  int result = fmin(right, (n - left) - 1);
  int i = 0;
  int j = right;
  while ((i <= left) && (j < n))
  {
    if (arr[i] <= arr[j])
    {
      result = fmin(result, (j - i) - 1);
      i++;
    }
    else
    {
      j++;
    }
  }

  return result;
}



int main()
{
  return 0;
}


