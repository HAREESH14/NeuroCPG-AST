#include <stdio.h>
#include <stdlib.h>

int twoSum(int numbers[], int numbers_len, int target);

int twoSum(int numbers[], int numbers_len, int target)
{
  int left = 0;
  int right = numbers_len - 1;
  while (left < right)
  {
    int current_sum = numbers[left] + numbers[right];
    if (current_sum == target)
    {
      return left + 1, right + 1;
    }
    else
      if (current_sum < target)
    {
      left++;
    }
    else
    {
      right--;
    }
  }

  return ;
}



int main()
{
  return 0;
}


