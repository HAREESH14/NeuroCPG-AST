#include <stdio.h>
#include <stdlib.h>

int findLatestStep(int arr[], int arr_len, int m);

int findLatestStep(int arr[], int arr_len, int m)
{
  int n = arr_len;
  int lengthLeft[n + 2];
  int lengthRight[n + 2];
  int count = 0;
  int result = 1;
  for (int i = 0; i < n; ++i)
  {
    int pos = arr[i];
    int leftLength = lengthRight[pos - 1];
    int rightLength = lengthLeft[pos + 1];
    int newLength = (leftLength + rightLength) + 1;
    if ((leftLength == m) || (rightLength == m))
    {
      count--;
    }
    if (newLength == m)
    {
      count++;
    }
    if (newLength > 0)
    {
      lengthLeft[pos - leftLength] = newLength;
      lengthRight[pos + rightLength] = newLength;
      result = i + 1;
    }
  }

  return (count > 0 ? result : 1);
}



int main()
{
  return 0;
}


