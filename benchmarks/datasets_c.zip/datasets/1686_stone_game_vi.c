#include <stdio.h>
#include <stdlib.h>

int stoneGameVI(int aliceValues[], int aliceValues_len, int bobValues[]);

int stoneGameVI(int aliceValues[], int aliceValues_len, int bobValues[])
{
  int n = aliceValues_len;
  int indices[n];
  for (int i = 0; i < n; i++)
  {
    indices[i] = i;
  }

  // sort(indices); // Needs manual sort implementation
  int aliceSum = 0;
  int bobSum = 0;
  for (int i = n - 1; i >= 0; i--)
  {
    if ((((n - 1) - i) % 2) == 0)
    {
      aliceSum += aliceValues[indices[i]];
    }
    else
    {
      bobSum += bobValues[indices[i]];
    }
  }

  return compare(aliceSum, bobSum);
}



int main()
{
  return 0;
}


