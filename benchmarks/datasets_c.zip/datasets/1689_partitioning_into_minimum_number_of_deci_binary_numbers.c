#include <stdio.h>
#include <stdlib.h>

int containsPattern(int arr[], int arr_len, int m, int k);

int containsPattern(int arr[], int arr_len, int m, int k)
{
  int n = arr_len;
  if ((m * k) > n)
  {
    return 0;
  }
  for (int i = 0; (i + (m * k)) <= n; i++)
  {
    int patternFound = 1;
    for (int j = 0; j < m; j++)
    {
      for (int l = 1; l < k; l++)
      {
        if (arr[i + j] != arr[(i + j) + (l * m)])
        {
          patternFound = 0;
          break;
        }
      }

      if (!patternFound)
      {
        break;
      }
    }

    if (patternFound)
    {
      return 1;
    }
  }

  return 0;
}



int main()
{
  return 0;
}


