#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int getMaxLen(int nums[]);

int getMaxLen(int nums[])
{
  int maxLength = 0;
  int currentLen = 0;
  int currentNegLen = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    if (num > 0)
    {
      ++currentLen;
      if (currentNegLen > 0)
      {
        ++currentNegLen;
      }
    }
    else
      if (num < 0)
    {
      int tmp = currentLen;
      currentLen = currentNegLen;
      currentNegLen = tmp + 1;
    }
    else
    {
      currentLen = 0;
      currentNegLen = 0;
    }
    maxLength = fmax(maxLength, currentLen);
  }

  return maxLength;
}



int main()
{
  return 0;
}


