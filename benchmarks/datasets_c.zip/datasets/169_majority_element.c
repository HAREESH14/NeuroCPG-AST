#include <stdio.h>
#include <stdlib.h>

int majorityElement(int nums[]);

int majorityElement(int nums[])
{
  int count = 0;
  int candidate = NULL;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    if (count == 0)
    {
      candidate = num;
    }
    count += (num == candidate ? 1 : 1);
  }

  return candidate;
}



int main()
{
  return 0;
}


