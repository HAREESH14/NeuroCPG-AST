#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int threeSumClosest(int nums[], int nums_len, int target);

int threeSumClosest(int nums[], int nums_len, int target)
{
  sort(nums);
  int closest = (nums[0] + nums[1]) + nums[2];
  for (int i = 0; i < (nums_len - 2); ++i)
  {
    int left = i + 1;
    int right = nums_len - 1;
    while (left < right)
    {
      int sum = (nums[i] + nums[left]) + nums[right];
      if (sum == target)
      {
        return sum;
      }
      if (abs(target - sum) < abs(target - closest))
      {
        closest = sum;
      }
      if (sum < target)
      {
        left++;
      }
      else
      {
        right--;
      }
    }

  }

  return closest;
}



int main()
{
  return 0;
}


