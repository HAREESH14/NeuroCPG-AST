#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int min_time_to_remove_balloons(char* colors, int neededTime[]);

int min_time_to_remove_balloons(char* colors, int neededTime[])
{
  int n = strlen(colors);
  int dp[n][26];
  const int INF = (int) 1e9;
  for (int i = 0; i < n; i++)
  {
    for (int j = 0; j < 26; j++)
    {
      dp[i][j] = INF;
    }

  }

  for (int color = 0; color < 26; color++)
  {
    if (colors[0] != ('A' + color))
    {
      dp[0][color] = neededTime[0];
    }
  }

  for (int i = 1; i < n; i++)
  {
    for (int color1 = 0; color1 < 26; color1++)
    {
      for (int color2 = 0; color2 < 26; color2++)
      {
        if ((color1 != color2) && (colors[i] != ('A' + color1)))
        {
          dp[i][color1] = fmin(dp[i][color1], dp[i - 1][color2] + neededTime[i]);
        }
      }

    }

  }

  int ans = INF;
  for (int color = 0; color < 26; color++)
  {
    ans = fmin(ans, dp[n - 1][color]);
  }

  return ans;
}



int main()
{
  return 0;
}


