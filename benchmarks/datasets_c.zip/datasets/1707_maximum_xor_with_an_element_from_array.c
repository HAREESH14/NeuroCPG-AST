#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int canTransform(char* s, char* t);

int canTransform(char* s, char* t)
{
  int i = 0;
  int j = 0;
  while ((i < strlen(s)) && (j < strlen(t)))
  {
    if (s[i] == t[j])
    {
      i++;
      j++;
    }
    else
    {
      i++;
    }
  }

  return j == strlen(t);
}



int main()
{
  return 0;
}


