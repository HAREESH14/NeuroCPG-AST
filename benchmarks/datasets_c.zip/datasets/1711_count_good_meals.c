#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int restoreMatrix(int rowSum[], int rowSum_len, int colSum[], int colSum_len);

int restoreMatrix(int rowSum[], int rowSum_len, int colSum[], int colSum_len)
{
  int m = rowSum_len;
  int n = colSum_len;
  int result[m][n];
  for (int i = 0; i < m; i++)
  {
    for (int j = 0; j < n; j++)
    {
      int value = fmin(rowSum[i], colSum[j]);
      result[i][j] = value;
      rowSum[i] -= value;
      colSum[j] -= value;
    }

  }

  return result;
}



int main()
{
  return 0;
}


