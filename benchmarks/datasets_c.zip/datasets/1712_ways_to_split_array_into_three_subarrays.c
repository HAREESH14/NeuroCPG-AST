#include <stdio.h>
#include <stdlib.h>

int waysToSplit(int nums[], int nums_len);

int waysToSplit(int nums[], int nums_len)
{
  int MOD = 1000000007;
  int n = nums_len;
  long prefixSum[n + 1];
  for (int i = 0; i < n; i++)
  {
    prefixSum[i + 1] = prefixSum[i] + nums[i];
  }

  int ans = 0;
  int left = 0;
  int right = 0;
  for (int mid = 1; mid < (n - 1); mid++)
  {
    while (((left + 1) < mid) && ((prefixSum[left + 1] * 2) <= prefixSum[mid]))
    {
      left++;
    }

    while ((right < mid) || (((right + 1) < n) && ((prefixSum[right + 1] - prefixSum[mid]) <= (prefixSum[n] - prefixSum[right + 1]))))
    {
      right++;
    }

    if ((right >= mid) && ((prefixSum[mid] - prefixSum[left]) <= (prefixSum[right] - prefixSum[mid])))
    {
      ans = (int) ((((ans + right) - mid) + 1) % MOD);
    }
  }

  return ans;
}



int main()
{
  return 0;
}


