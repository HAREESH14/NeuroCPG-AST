#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minOperationsMaxProfit(int customers[], int customers_len, int boardingCost, int runningCost);

int minOperationsMaxProfit(int customers[], int customers_len, int boardingCost, int runningCost)
{
  int rotations = 0;
  int waiting = 0;
  int onBoard;
  int profit = 0;
  int maxProfit = 0;
  int maxRotations = 0;
  int idx = 0;
  while ((idx < customers_len) || (waiting > 0))
  {
    if (idx < customers_len)
    {
      waiting += customers[idx];
      idx++;
    }
    onBoard = fmin(waiting, 4);
    waiting -= onBoard;
    profit += (onBoard * boardingCost) - runningCost;
    rotations++;
    if (profit > maxProfit)
    {
      maxProfit = profit;
      maxRotations = rotations;
    }
  }

  return (maxProfit > 0 ? maxRotations : 1);
}



int main()
{
  return 0;
}


