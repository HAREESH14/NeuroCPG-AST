#include <stdio.h>
#include <stdlib.h>
/* -- HashMap simulation -- */
#define HASHMAP_SIZE 100
typedef struct { int keys[HASHMAP_SIZE]; int vals[HASHMAP_SIZE]; int count; } HashMap;
HashMap hashmap_create() { HashMap m; m.count=0; return m; }
void hashmap_put(HashMap *m,int k,int v){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k){m->vals[i]=v;return;}m->keys[m->count]=k;m->vals[m->count]=v;m->count++;}
int hashmap_get(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return m->vals[i];return -1;}
int hashmap_contains(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return 1;return 0;}
/* -------------------------*/

/* -- ArrayList simulation -- */
#define AL_INIT_CAP 16
typedef struct { int *data; int size; int capacity; } ArrayList;
ArrayList arraylist_create() { ArrayList a; a.data=(int*)malloc(AL_INIT_CAP*sizeof(int)); a.size=0; a.capacity=AL_INIT_CAP; return a; }
void arraylist_add(ArrayList *a,int v){if(a->size>=a->capacity){a->capacity*=2;a->data=(int*)realloc(a->data,a->capacity*sizeof(int));}a->data[a->size++]=v;}
int arraylist_get(ArrayList *a,int i){return a->data[i];}
void arraylist_free(ArrayList *a){free(a->data);a->data=NULL;a->size=0;}
/* ----------------------------*/


ArrayList sequence;

void append(int val);
void addAll(int inc);
void multAll(int m);
int getIndex(int idx);

void append(int val)
{
  arraylist_add(&sequence, val);
}



void addAll(int inc)
{
  for (int i = 0; i < sequence.size; i++)
  {
    set(i, hashmap_get(&sequence, i) + inc);
  }

}



void multAll(int m)
{
  for (int i = 0; i < sequence.size; i++)
  {
    set(i, hashmap_get(&sequence, i) * m);
  }

}



int getIndex(int idx)
{
  if (idx >= sequence.size)
  {
    return 1;
  }
  return hashmap_get(&sequence, idx);
}


