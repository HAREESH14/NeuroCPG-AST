#include <stdio.h>
#include <stdlib.h>

int trailingZeroes(int n);

int trailingZeroes(int n)
{
  int count = 0;
  while (n > 0)
  {
    n = n / 5;
    count += n;
  }

  return count;
}



int main()
{
  return 0;
}


