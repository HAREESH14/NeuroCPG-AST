#include <stdio.h>
#include <stdlib.h>

int findSpecialInteger(int nums[], int nums_len);

int findSpecialInteger(int nums[], int nums_len)
{
  for (int x = 1; x <= nums_len; ++x)
  {
    int count = 0;
    for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
    {
      int num = nums[_fi1];
      if (num >= x)
      {
        ++count;
      }
    }

    if (count == x)
    {
      return x;
    }
  }

  return 1;
}



int main()
{
  return 0;
}


