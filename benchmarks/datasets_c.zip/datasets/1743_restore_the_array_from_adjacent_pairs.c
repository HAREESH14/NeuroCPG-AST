#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int countSubstringsWithOneDifference(char* s, char* t);

int countSubstringsWithOneDifference(char* s, char* t)
{
  int count = 0;
  for (int i = 0; i < strlen(s); i++)
  {
    for (int j = 0; j < strlen(t); j++)
    {
      int differences = 0;
      for (int k = 0; ((i + k) < strlen(s)) && ((j + k) < strlen(t)); k++)
      {
        if (s[i + k] != t[j + k])
        {
          differences++;
        }
        if (differences == 2)
        {
          break;
        }
        if (differences == 1)
        {
          count++;
        }
      }

    }

  }

  return count;
}



int main()
{
  return 0;
}


