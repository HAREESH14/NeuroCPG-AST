#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int isPalindrome(char* s, int start, int end);
int checkPartitioning(char* s);

int isPalindrome(char* s, int start, int end)
{
  while (start < end)
  {
    if (s[start] != s[end])
    {
      return 0;
    }
    start++;
    end--;
  }

  return 1;
}



int checkPartitioning(char* s)
{
  int n = strlen(s);
  for (int i = 0; i < (n - 2); ++i)
  {
    if (isPalindrome(s, 0, i))
    {
      for (int j = i + 1; j < (n - 1); ++j)
      {
        if (isPalindrome(s, i + 1, j) && isPalindrome(s, j + 1, n - 1))
        {
          return 1;
        }
      }

    }
  }

  return 0;
}


