#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int bestTeamScore(int scores[], int scores_len, int ages[]);

int bestTeamScore(int scores[], int scores_len, int ages[])
{
  int n = scores_len;
  int indices[n];
  for (int i = 0; i < n; i++)
  {
    indices[i] = i;
  }

  // sort(indices); // Needs manual sort implementation
  int dp[n];
  int best_score = 0;
  for (int i = 0; i < n; i++)
  {
    dp[i] = scores[indices[i]];
    for (int j = 0; j < i; j++)
    {
      if (scores[indices[i]] >= scores[indices[j]])
      {
        dp[i] = fmax(dp[i], dp[j] + scores[indices[i]]);
      }
    }

    best_score = fmax(best_score, dp[i]);
  }

  return best_score;
}


