#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxAbsoluteSum(int nums[]);

int maxAbsoluteSum(int nums[])
{
  int max_sum = 0;
  int min_sum = 0;
  int max_end = 0;
  int min_end = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    max_end = fmax(max_end + num, num);
    min_end = fmin(min_end + num, num);
    max_sum = fmax(max_sum, max_end);
    min_sum = fmin(min_sum, min_end);
  }

  return fmax(max_sum, -min_sum);
}



int main()
{
  return 0;
}


