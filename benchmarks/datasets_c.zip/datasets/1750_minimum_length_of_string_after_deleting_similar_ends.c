#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int minimumLength(char* s);

int minimumLength(char* s)
{
  if (strlen(s) == 0)
  {
    return 0;
  }
  int i = 0;
  int j = strlen(s) - 1;
  while (i < j)
  {
    if (s[i] != s[j])
    {
      break;
    }
    char remove_char = s[i];
    while ((i < strlen(s)) && (s[i] == remove_char))
    {
      i++;
    }

    while ((j >= 0) && (s[j] == remove_char))
    {
      j--;
    }

  }

  return fmax(0, (j - i) + 1);
}



int main()
{
  return 0;
}


