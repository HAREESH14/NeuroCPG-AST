#include <stdio.h>
#include <stdlib.h>

int canDistribute(int nums[], int quantity[], int quantity_len);
int dfs(int quantity[], int counts[], int idx);

int canDistribute(int nums[], int quantity[], int quantity_len)
{
  int counts[51];
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    counts[num]++;
  }

  sort(quantity);
  int m = quantity_len;
  return dfs(quantity, counts, m - 1);
}



int dfs(int quantity[], int counts[], int idx)
{
  if (idx == 1)
  {
    return 1;
  }
  for (int i = 1; i <= 50; ++i)
  {
    if (counts[i] >= quantity[idx])
    {
      counts[i] -= quantity[idx];
      if (dfs(quantity, counts, idx - 1))
      {
        return 1;
      }
      counts[i] += quantity[idx];
    }
  }

  return 0;
}



int main()
{
  return 0;
}


