#include <stdio.h>
#include <stdlib.h>

int countVowelStrings(int n);

int countVowelStrings(int n)
{
  int dp[] = {1, 1, 1, 1, 1};
  for (int i = 1; i < n; i++)
  {
    for (int j = 3; j >= 0; j--)
    {
      dp[j] += dp[j + 1];
    }

  }

  return (((dp[0] + dp[1]) + dp[2]) + dp[3]) + dp[4];
}



int main()
{
  return 0;
}


