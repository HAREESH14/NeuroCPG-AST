#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* longestNiceSubstring(char* s);

char* longestNiceSubstring(char* s)
{
  int n = strlen(s);
  char* result = "";
  for (int i = 0; i < n; i++)
  {
    for (int j = i + 1; j < n; ++j)
    {
      int isNice = 1;
      for (char ch = 'A'; ch <= 'Z'; ++ch)
      {
        int upper = 0;
        int lower = 0;
        for (int k = i; k <= j; ++k)
        {
          if (s[k] == ch)
          {
            upper = 1;
          }
          if (s[k] == (ch + 32))
          {
            lower = 1;
          }
        }

        if ((upper && (!lower)) || ((!upper) && lower))
        {
          isNice = 0;
          break;
        }
      }

      if (isNice && (((j - i) + 1) > strlen(result)))
      {
        result = s + i;
      }
    }

  }

  return result;
}



int main()
{
  return 0;
}


