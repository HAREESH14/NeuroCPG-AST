#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minimumMountainRemovals(int nums[], int nums_len);

int minimumMountainRemovals(int nums[], int nums_len)
{
  int n = nums_len;
  int left[n];
  int right[n];
  for (int i = 0; i < n; ++i)
  {
    left[i] = lowerBound(copyOfRange(left, 0, i), nums[i]);
    right[(n - 1) - i] = lowerBound(reverse(copyOfRange(right, (n - 1) - i, n)), nums[(n - 1) - i]);
  }

  int result = n;
  for (int i = 1; i < (n - 1); ++i)
  {
    result = fmin(result, (n - (left[i] + 1)) - (right[i] + 1));
  }

  return result;
}



int main()
{
  return 0;
}


