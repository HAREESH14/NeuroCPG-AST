#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maximumGenerated(int n);

int maximumGenerated(int n)
{
  if (n == 0)
  {
    return 0;
  }
  int nums[n + 1];
  nums[1] = 1;
  int maxVal = 1;
  for (int i = 2; i <= n; i++)
  {
    nums[i] = ((i % 2) == 0 ? nums[i / 2] : nums[i / 2] + nums[(i / 2) + 1]);
    maxVal = fmax(maxVal, nums[i]);
  }

  return maxVal;
}



int main()
{
  return 0;
}


