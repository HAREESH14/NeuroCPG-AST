#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minOperations(int nums[], int nums_len, int x);

int minOperations(int nums[], int nums_len, int x)
{
  int total = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    total += num;
  }

  int target = total - x;
  if (target < 0)
  {
    return 1;
  }
  int maxLength = 1;
  int left = 0;
  int sum = 0;
  for (int right = 0; right < nums_len; ++right)
  {
    sum += nums[right];
    while (sum > target)
    {
      sum -= nums[left++];
    }

    if (sum == target)
    {
      maxLength = fmax(maxLength, (right - left) + 1);
    }
  }

  return (maxLength == 1 ? 1 : nums_len - maxLength);
}



int main()
{
  return 0;
}


