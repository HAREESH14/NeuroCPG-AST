#include <stdio.h>
#include <stdlib.h>

int checkPowersOfThree(int n);

int checkPowersOfThree(int n)
{
  while (n > 0)
  {
    if ((n % 3) == 2)
    {
      return 0;
    }
    n /= 3;
  }

  return 1;
}



int main()
{
  return 0;
}


