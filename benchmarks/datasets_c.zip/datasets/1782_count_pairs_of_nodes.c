#include <stdio.h>
#include <stdlib.h>
#include <math.h>

char* getSmallestString(int n, int k);

char* getSmallestString(int n, int k)
{
  char result[n];
  k -= n;
  for (int i = n - 1; i >= 0; --i)
  {
    int value = fmin(k, 25);
    result[i] = (char) ('a' + value);
    k -= value;
    if (k == 0)
    {
      break;
    }
  }

  return String();
}


