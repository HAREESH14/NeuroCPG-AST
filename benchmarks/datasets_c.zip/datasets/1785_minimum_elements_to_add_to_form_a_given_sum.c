#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minElements(int nums[], int limit, int goal);

int minElements(int nums[], int limit, int goal)
{
  long sum = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    sum += num;
  }

  long diff = abs(goal - sum);
  return (int) (((diff + limit) - 1) / limit);
}



int main()
{
  return 0;
}


