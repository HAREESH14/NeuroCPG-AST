#include <stdio.h>
#include <stdlib.h>

int stoneGameVI(int aliceValues[], int aliceValues_len, int bobValues[]);

int stoneGameVI(int aliceValues[], int aliceValues_len, int bobValues[])
{
  int n = aliceValues_len;
  int indexes[n];
  for (int i = 0; i < n; ++i)
  {
    indexes[i] = i;
  }

  // sort(indexes); // Needs manual sort implementation
  int aliceScore = 0;
  int bobScore = 0;
  for (int i = 0; i < n; ++i)
  {
    if ((i % 2) == 0)
    {
      aliceScore += aliceValues[indexes[i]];
    }
    else
    {
      bobScore += bobValues[indexes[i]];
    }
  }

  return compare(aliceScore, bobScore);
}



int main()
{
  return 0;
}


