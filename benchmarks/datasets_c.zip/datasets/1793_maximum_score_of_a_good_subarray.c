#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minMoves(int nums[], int nums_len, int limit);

int minMoves(int nums[], int nums_len, int limit)
{
  int n = nums_len;
  int delta[(2 * limit) + 2];
  for (int i = 0; i < (n / 2); i++)
  {
    int lo = fmin(nums[i], nums[(n - 1) - i]) + 1;
    int hi = fmax(nums[i], nums[(n - 1) - i]) + limit;
    delta[lo]--;
    delta[nums[i] + nums[(n - 1) - i]]--;
    delta[hi + 1]++;
  }

  int moves = n;
  int current = n;
  for (int i = 2; i <= (2 * limit); i++)
  {
    current += delta[i];
    moves = fmin(moves, current);
  }

  return moves;
}



int main()
{
  return 0;
}


