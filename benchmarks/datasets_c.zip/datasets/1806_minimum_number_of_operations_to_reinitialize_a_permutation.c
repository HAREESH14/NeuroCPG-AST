#include <stdio.h>
#include <stdlib.h>

int numberOfMatches(int n);

int numberOfMatches(int n)
{
  return n - 1;
}



int main()
{
  return 0;
}


