#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int stoneGame(int stones[], int stones_len);

int stoneGame(int stones[], int stones_len)
{
  int n = stones_len;
  int dp[n][n];
  for (int i = n - 1; i >= 0; i--)
  {
    for (int j = i + 1; j < n; j++)
    {
      dp[i][j] = fmax(stones[j] - dp[i][j - 1], stones[i] - dp[i + 1][j]);
    }

  }

  return dp[0][n - 1];
}



int main()
{
  return 0;
}


