#include <stdio.h>
#include <stdlib.h>

int totalMoney(int n);

int totalMoney(int n)
{
  int weeks = n / 7;
  int days_remaining = n % 7;
  return (((28 * weeks) + (((7 * weeks) * (weeks - 1)) / 2)) + ((weeks + 1) * days_remaining)) + ((days_remaining * (days_remaining - 1)) / 2);
}



int main()
{
  return 0;
}


