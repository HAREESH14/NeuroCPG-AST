#include <stdio.h>
#include <stdlib.h>

int signFunc(int x);
int arraySign(int nums[], int nums_len);

int signFunc(int x)
{
  if (x > 0)
  {
    return 1;
  }
  if (x < 0)
  {
    return 1;
  }
  return 0;
}



int arraySign(int nums[], int nums_len)
{
  int product = 1;
  for (int i = 0; i < nums_len; i++)
  {
    product *= signFunc(nums[i]);
  }

  return product;
}



int main()
{
  return 0;
}


