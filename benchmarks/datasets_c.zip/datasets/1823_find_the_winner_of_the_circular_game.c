#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int halvesAreAlike(char* s);

int halvesAreAlike(char* s)
{
  int halfLength = strlen(s) / 2;
  int countA = 0;
  int countB = 0;
  for (int i = 0; i < halfLength; i++)
  {
    if ("aeiouAEIOU")
    {
      countA++;
    }
  }

  for (int i = halfLength; i < strlen(s); i++)
  {
    if ("aeiouAEIOU")
    {
      countB++;
    }
  }

  return countA == countB;
}



int main()
{
  return 0;
}


