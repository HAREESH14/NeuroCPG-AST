#include <stdio.h>
#include <stdlib.h>

int minimumWorkingTime(int jobs[], int k);

int minimumWorkingTime(int jobs[], int k)
{
  int max_job = stream(jobs);
  int sum_jobs = stream(jobs);
  int left = max_job;
  int right = sum_jobs;
  while (left < right)
  {
    int mid = left + ((right - left) / 2);
    int count = 1;
    int current_sum = 0;
    for (int _fi1 = 0; _fi1 < (sizeof(jobs) / sizeof(jobs[0])); _fi1++)
    {
      int job = jobs[_fi1];
      if ((current_sum + job) > mid)
      {
        count++;
        current_sum = 0;
      }
      current_sum += job;
    }

    if (count <= k)
    {
      right = mid;
    }
    else
    {
      left = mid + 1;
    }
  }

  return left;
}



int main()
{
  return 0;
}


