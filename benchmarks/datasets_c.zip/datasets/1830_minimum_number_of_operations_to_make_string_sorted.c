#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* -- HashMap simulation -- */
#define HASHMAP_SIZE 100
typedef struct { int keys[HASHMAP_SIZE]; int vals[HASHMAP_SIZE]; int count; } HashMap;
HashMap hashmap_create() { HashMap m; m.count=0; return m; }
void hashmap_put(HashMap *m,int k,int v){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k){m->vals[i]=v;return;}m->keys[m->count]=k;m->vals[m->count]=v;m->count++;}
int hashmap_get(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return m->vals[i];return -1;}
int hashmap_contains(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return 1;return 0;}
/* -------------------------*/


int countPairs(int deliciousness[]);

int countPairs(int deliciousness[])
{
  const int MOD = (int) (1e9 + 7);
  HashMap hashMap = hashmap_create();
  int maxVal = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(deliciousness) / sizeof(deliciousness[0])); _fi1++)
  {
    int val = deliciousness[_fi1];
    maxVal = fmax(maxVal, val);
  }

  int maxSum = maxVal * 2;
  int count = 0;
  for (int _fi2 = 0; _fi2 < (sizeof(deliciousness) / sizeof(deliciousness[0])); _fi2++)
  {
    int val = deliciousness[_fi2];
    for (int sum = 1; sum <= maxSum; sum <<= 1)
    {
      count = (count + getOrDefault(sum - val, 0)) % MOD;
    }

    hashmap_put(&hashMap, val, getOrDefault(val, 0) + 1);
  }

  return count;
}



int main()
{
  return 0;
}


