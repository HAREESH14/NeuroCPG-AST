#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int largestAltitude(int gain[], int gain_len);

int largestAltitude(int gain[], int gain_len)
{
  int max_altitude = 0;
  int current_altitude = 0;
  for (int i = 0; i < gain_len; i++)
  {
    current_altitude += gain[i];
    max_altitude = fmax(max_altitude, current_altitude);
  }

  return max_altitude;
}



int main()
{
  return 0;
}


