#include <stdio.h>
#include <stdlib.h>

int decode(int encoded[], int encoded_len);

int decode(int encoded[], int encoded_len)
{
  int n = encoded_len + 1;
  int total_xor = 0;
  for (int i = 1; i <= n; ++i)
  {
    total_xor ^= i;
  }

  int encoded_xor = 0;
  for (int i = 1; i < (n - 1); i += 2)
  {
    encoded_xor ^= encoded[i];
  }

  int perm[n];
  perm[0] = total_xor ^ encoded_xor;
  for (int i = 1; i < n; ++i)
  {
    perm[i] = perm[i - 1] ^ encoded[i - 1];
  }

  return perm;
}



int main()
{
  return 0;
}


