#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxFrequency(int nums[], int nums_len, int k);

int maxFrequency(int nums[], int nums_len, int k)
{
  sort(nums);
  int n = nums_len;
  int i = 0;
  long sum = 0;
  int max_freq = 0;
  for (int j = 0; j < n; j++)
  {
    sum += nums[j];
    while ((sum + k) < (((long) nums[j]) * ((j - i) + 1)))
    {
      sum -= nums[i++];
    }

    max_freq = fmax(max_freq, (j - i) + 1);
  }

  return max_freq;
}



int main()
{
  return 0;
}


