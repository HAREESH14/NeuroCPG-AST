#include <stdio.h>
#include <stdlib.h>

int decode(int encoded[], int encoded_len, int first);

int decode(int encoded[], int encoded_len, int first)
{
  int arr[encoded_len + 1];
  arr[0] = first;
  for (int i = 0; i < encoded_len; i++)
  {
    arr[i + 1] = arr[i] ^ encoded[i];
  }

  return arr;
}



int main()
{
  return 0;
}


