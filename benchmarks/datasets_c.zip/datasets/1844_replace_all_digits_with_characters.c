#include <stdio.h>
#include <stdlib.h>

int countBalls(int lowLimit, int highLimit);

int countBalls(int lowLimit, int highLimit)
{
  int boxCounts[46];
  for (int i = lowLimit; i <= highLimit; i++)
  {
    int boxNumber = 0;
    int num = i;
    while (num != 0)
    {
      boxNumber += num % 10;
      num /= 10;
    }

    boxCounts[boxNumber]++;
  }

  return stream(boxCounts);
}



int main()
{
  return 0;
}


