#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maximumElementAfterDecrementingAndRearranging(int arr[], int arr_len);

int maximumElementAfterDecrementingAndRearranging(int arr[], int arr_len)
{
  sort(arr);
  arr[0] = 1;
  for (int i = 1; i < arr_len; i++)
  {
    arr[i] = fmin(arr[i], arr[i - 1] + 1);
  }

  return arr[arr_len - 1];
}



int main()
{
  return 0;
}


