#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxAbsoluteSum(int nums[]);

int maxAbsoluteSum(int nums[])
{
  int maxSum = 0;
  int minSum = 0;
  int maxSoFar = 0;
  int minSoFar = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    maxSoFar = fmax(num, maxSoFar + num);
    maxSum = fmax(maxSum, maxSoFar);
    minSoFar = fmin(num, minSoFar + num);
    minSum = fmin(minSum, minSoFar);
  }

  return fmax(maxSum, abs(minSum));
}



int main()
{
  return 0;
}


