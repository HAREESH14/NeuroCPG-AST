#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int minLengthAfterOperations(char* s);

int minLengthAfterOperations(char* s)
{
  int aCount = strlen(s) - replace("a", "");
  int bCount = strlen(s) - replace("b", "");
  int cCount = strlen(s) - replace("c", "");
  if (((aCount % 2) == (bCount % 2)) && ((bCount % 2) == (cCount % 2)))
  {
    return strlen(s) % 2;
  }
  return (strlen(s) + 1) % 2;
}



int main()
{
  return 0;
}


