#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int minOperationsToSatisfyConditions(char* a, char* b);

int minOperationsToSatisfyConditions(char* a, char* b)
{
  int same = 0;
  int less = 0;
  int greater = 0;
  for (int i = 0; i < strlen(a); i++)
  {
    if (a[i] == b[i])
    {
      same++;
    }
    else
      if (a[i] < b[i])
    {
      less++;
    }
    else
    {
      greater++;
    }
  }

  return fmin(same + fmax(less, greater), fmin(less, greater));
}



int main()
{
  return 0;
}


