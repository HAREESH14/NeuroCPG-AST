#include <stdio.h>
#include <stdlib.h>

int minBoxesTouchingFloor(int n);

int minBoxesTouchingFloor(int n)
{
  return (n + 1) / 2;
}



int main()
{
  return 0;
}


