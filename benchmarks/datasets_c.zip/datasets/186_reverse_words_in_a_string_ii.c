#include <stdio.h>
#include <stdlib.h>

void reverseWords(char s[], int s_len);
void reverse(char s[], int start, int end);

void reverseWords(char s[], int s_len)
{
  reverse(s, 0, s_len - 1);
  int start = 0;
  for (int i = 0; i <= s_len; i++)
  {
    if ((i == s_len) || (s[i] == ' '))
    {
      reverse(s, start, i - 1);
      start = i + 1;
    }
  }

}



void reverse(char s[], int start, int end)
{
  while (start < end)
  {
    char temp = s[start];
    s[start++] = s[end];
    s[end--] = temp;
  }

}



int main()
{
  return 0;
}


