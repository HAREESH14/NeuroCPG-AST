#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int isPalindrome(char* s, int l, int r);
int checkPartitioning(char* s);

int isPalindrome(char* s, int l, int r)
{
  while (l < r)
  {
    if (s[l++] != s[r--])
    {
      return 0;
    }
  }

  return 1;
}



int checkPartitioning(char* s)
{
  int n = strlen(s);
  for (int i = 0; i < (n - 2); i++)
  {
    if (isPalindrome(s, 0, i))
    {
      for (int j = i + 1; j < (n - 1); j++)
      {
        if (isPalindrome(s, i + 1, j) && isPalindrome(s, j + 1, n - 1))
        {
          return 1;
        }
      }

    }
  }

  return 0;
}



int main()
{
  return 0;
}


