#include <stdio.h>
#include <stdlib.h>

int check(int nums[], int nums_len);

int check(int nums[], int nums_len)
{
  int count = 0;
  for (int i = 1; i < nums_len; ++i)
  {
    if (nums[i] < nums[i - 1])
    {
      ++count;
    }
    if (count > 1)
    {
      return 0;
    }
  }

  return (count == 1) || (nums[0] >= nums[nums_len - 1]);
}



int main()
{
  return 0;
}


