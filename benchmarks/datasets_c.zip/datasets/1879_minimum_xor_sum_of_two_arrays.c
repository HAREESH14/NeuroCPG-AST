#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxScore(int a, int b, int c);

int maxScore(int a, int b, int c)
{
  return (((a + b) + c) - fmax(a, fmax(b, c))) / 2;
}



int main()
{
  return 0;
}


