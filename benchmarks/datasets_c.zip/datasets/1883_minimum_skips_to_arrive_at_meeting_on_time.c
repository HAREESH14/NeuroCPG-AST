#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minSkips(int dist[], int dist_len, int speed, int hoursBefore);

int minSkips(int dist[], int dist_len, int speed, int hoursBefore)
{
  int n = dist_len;
  double dp[n + 1][n + 1];
  for (int i = 0; i <= n; i++)
  {
    for (int j = 0; j <= n; j++)
    {
      dp[i][j] = 1e9;
    }

  }

  dp[0][0] = 0;
  for (int i = 0; i < n; i++)
  {
    for (int j = 1; j < i; j++)
    {
      double t = (dist[i] / ((double) speed)) + (j != 1 ? 1 : 0);
      dp[i + 1][j + 1] = fmin(dp[i + 1][j + 1], dp[i][j] + t);
      double skipped_t = ceil(dp[i][j] + (dist[i] / ((double) speed))) - dp[i][j];
      dp[i + 1][j] = fmin(dp[i + 1][j], dp[i][j] + skipped_t);
    }

  }

  for (int i = 0; i <= n; i++)
  {
    if (dp[n][i] <= hoursBefore)
    {
      return i;
    }
  }

  return 1;
}



int main()
{
  return 0;
}


