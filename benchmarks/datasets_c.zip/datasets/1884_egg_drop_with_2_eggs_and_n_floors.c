#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int minOperationsToAlternate(char* s);

int minOperationsToAlternate(char* s)
{
  int countA = 0;
  int countB = 0;
  for (int i = 0; i < strlen(s); i++)
  {
    if ((i % 2) == 0)
    {
      if (s[i] == '0')
      {
        countA++;
      }
      else
      {
        countB++;
      }
    }
    else
    {
      if (s[i] == '0')
      {
        countB++;
      }
      else
      {
        countA++;
      }
    }
  }

  return fmin(countA, countB);
}



int main()
{
  return 0;
}


