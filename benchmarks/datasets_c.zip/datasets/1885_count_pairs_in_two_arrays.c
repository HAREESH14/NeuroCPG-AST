#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int countHomogenous(char* s);

int countHomogenous(char* s)
{
  int res = 0;
  int count = 1;
  int mod = 1000000007;
  for (int i = 1; i < strlen(s); ++i)
  {
    count = (s[i] == s[i - 1] ? count + 1 : 1);
    res = (res + count) % mod;
  }

  return res;
}



int main()
{
  return 0;
}


