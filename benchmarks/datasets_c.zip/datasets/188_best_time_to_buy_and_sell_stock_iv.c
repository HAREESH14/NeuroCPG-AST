#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxProfit(int k, int prices[], int prices_len);

int maxProfit(int k, int prices[], int prices_len)
{
  int n = prices_len;
  if (k > (n / 2))
  {
    int maxProfit = 0;
    for (int i = 1; i < n; ++i)
    {
      maxProfit += fmax(prices[i] - prices[i - 1], 0);
    }

    return maxProfit;
  }
  int dp[k + 1][n];
  for (int i = 1; i <= k; ++i)
  {
    int maxDiff = -prices[0];
    for (int j = 1; j < n; ++j)
    {
      dp[i][j] = fmax(dp[i][j - 1], prices[j] + maxDiff);
      maxDiff = fmax(maxDiff, dp[i - 1][j] - prices[j]);
    }

  }

  return dp[k][n - 1];
}



int main()
{
  return 0;
}


