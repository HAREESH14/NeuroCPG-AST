#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int minOperations(char* boxes);

int minOperations(char* boxes)
{
  int result[strlen(boxes)];
  int count = 0;
  int total = 0;
  for (int i = 0; i < strlen(boxes); i++)
  {
    total += count;
    result[i] = total;
    if (boxes[i] == '1')
    {
      count++;
    }
  }

  count = 0;
  total = 0;
  for (int i = strlen(boxes) - 1; i >= 0; i--)
  {
    total += count;
    result[i] += total;
    if (boxes[i] == '1')
    {
      count++;
    }
  }

  return result;
}



int main()
{
  return 0;
}


