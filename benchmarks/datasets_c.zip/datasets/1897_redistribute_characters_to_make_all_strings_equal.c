#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int longestPalindromeSubseq(char* word1, char* word2);

int longestPalindromeSubseq(char* word1, char* word2)
{
  int n = strlen(word1);
  int m = strlen(word2);
  int dp[1001][1001];
  for (int i = 0; i < n; i++)
  {
    for (int j = 0; j < m; j++)
    {
      if (word1[i] == word2[j])
      {
        dp[i + 1][j + 1] = dp[i][j] + 1;
      }
      else
      {
        dp[i + 1][j + 1] = fmax(dp[i][j + 1], dp[i + 1][j]);
      }
    }

  }

  return dp[n][m];
}



int main()
{
  return 0;
}


