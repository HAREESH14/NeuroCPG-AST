#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* largestOddNumber(char* num);

char* largestOddNumber(char* num)
{
  for (int i = strlen(num) - 1; i >= 0; i--)
  {
    if (((num[i] - '0') % 2) != 0)
    {
      return num + 0;
    }
  }

  return "";
}



int main()
{
  return 0;
}


