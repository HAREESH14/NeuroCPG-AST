#include <stdio.h>
#include <stdlib.h>

int aliceWins(int piles[]);

int aliceWins(int piles[])
{
  int xorSum = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(piles) / sizeof(piles[0])); _fi1++)
  {
    int pile = piles[_fi1];
    xorSum ^= pile;
  }

  return xorSum != 0;
}



int main()
{
  return 0;
}


