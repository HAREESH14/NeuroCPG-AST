#include <stdio.h>
#include <stdlib.h>

int canBeIncreasing(int nums[], int nums_len);

int canBeIncreasing(int nums[], int nums_len)
{
  int count = 0;
  for (int i = 1; i < nums_len; ++i)
  {
    if (nums[i - 1] >= nums[i])
    {
      count++;
      if (count > 1)
      {
        return 0;
      }
      if ((((i > 1) && (nums[i - 2] >= nums[i])) && (i < (nums_len - 1))) && (nums[i - 1] >= nums[i + 1]))
      {
        return 0;
      }
    }
  }

  return 1;
}



int main()
{
  return 0;
}


