#include <stdio.h>
#include <stdlib.h>

int reverseBits(int n);

int reverseBits(int n)
{
  int res = 0;
  for (int i = 0; i < 32; ++i)
  {
    res <<= 1;
    res |= n & 1;
    n >>= 1;
  }

  return res;
}



int main()
{
  return 0;
}


