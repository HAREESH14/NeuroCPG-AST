#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int checkOnesSegment(char* s);

int checkOnesSegment(char* s)
{
  int count = 0;
  for (int i = 0; i < strlen(s); i++)
  {
    if (s[i] == '1')
    {
      if ((i > 0) && (s[i - 1] == '0'))
      {
        count++;
      }
    }
  }

  return count <= 1;
}



int main()
{
  return 0;
}


