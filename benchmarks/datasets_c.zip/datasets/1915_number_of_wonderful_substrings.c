#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int areAlmostEqual(char* s1, char* s2);

int areAlmostEqual(char* s1, char* s2)
{
  int diffCount = 0;
  int firstDiff = 1;
  int secondDiff = 1;
  for (int i = 0; i < strlen(s1); i++)
  {
    if (s1[i] != s2[i])
    {
      diffCount++;
      if (diffCount == 1)
      {
        firstDiff = i;
      }
      else
        if (diffCount == 2)
      {
        secondDiff = i;
      }
      else
      {
        return 0;
      }
    }
  }

  return (diffCount == 0) || (((diffCount == 2) && (s1[firstDiff] == s2[secondDiff])) && (s1[secondDiff] == s2[firstDiff]));
}



int main()
{
  return 0;
}


