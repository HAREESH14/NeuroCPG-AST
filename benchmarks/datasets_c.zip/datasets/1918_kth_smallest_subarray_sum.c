#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxScore(int nums[], int nums_len, int k);

int maxScore(int nums[], int nums_len, int k)
{
  int n = nums_len;
  int result = 0;
  for (int i = k; i >= 0; i--)
  {
    for (int j = k; j < n; j++)
    {
      int minVal = nums[i];
      for (int x = i; x <= j; x++)
      {
        minVal = fmin(minVal, nums[x]);
      }

      result = fmax(result, minVal * ((j - i) + 1));
    }

  }

  return result;
}



int main()
{
  return 0;
}


