#include <stdio.h>
#include <stdlib.h>

int squareIsWhite(char* coordinates);

int squareIsWhite(char* coordinates)
{
  return ((((coordinates[0] - 'a') + coordinates[1]) - '1') % 2) == 0;
}



int main()
{
  return 0;
}


