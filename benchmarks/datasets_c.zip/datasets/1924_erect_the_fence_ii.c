#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxHappyGroups(int batchSize, int groups[]);

int maxHappyGroups(int batchSize, int groups[])
{
  int remainders[batchSize];
  for (int _fi1 = 0; _fi1 < (sizeof(groups) / sizeof(groups[0])); _fi1++)
  {
    int g = groups[_fi1];
    remainders[g % batchSize]++;
  }

  int result = remainders[0];
  int i = 1;
  int j = batchSize - 1;
  while (i < j)
  {
    result += fmin(remainders[i], remainders[j]);
    i++;
    j--;
  }

  if (i == j)
  {
    result += remainders[i] / 2;
  }
  return result;
}



int main()
{
  return 0;
}


