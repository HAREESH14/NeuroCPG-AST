#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxAscendingSum(int nums[], int nums_len);

int maxAscendingSum(int nums[], int nums_len)
{
  int maxSum = 0;
  int currentSum = nums[0];
  for (int i = 1; i < nums_len; ++i)
  {
    if (nums[i] > nums[i - 1])
    {
      currentSum += nums[i];
    }
    else
    {
      maxSum = fmax(maxSum, currentSum);
      currentSum = nums[i];
    }
  }

  return fmax(maxSum, currentSum);
}



int main()
{
  return 0;
}


