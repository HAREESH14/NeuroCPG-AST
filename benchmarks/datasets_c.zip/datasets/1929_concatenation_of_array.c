#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxValue(int n, int index, int maxSum);

int maxValue(int n, int index, int maxSum)
{
  maxSum -= n;
  int left = 0;
  int right = maxSum;
  int ans = 0;
  while (left <= right)
  {
    int mid = left + ((right - left) / 2);
    long sum = ((((long) fmin(mid, index)) * (fmin(mid, index) + 1)) / 2) + ((((long) fmin(mid, (n - index) - 1)) * (fmin(mid, n - index) + 1)) / 2);
    if (mid > index)
    {
      sum += (((long) ((mid - index) - 1)) * (mid - index)) / 2;
    }
    if (mid > (n - index))
    {
      sum += (((long) ((mid - n) + index)) * (((mid - n) + index) + 1)) / 2;
    }
    if (sum <= maxSum)
    {
      ans = mid;
      left = mid + 1;
    }
    else
    {
      right = mid - 1;
    }
  }

  return ans + 1;
}



int main()
{
  return 0;
}


