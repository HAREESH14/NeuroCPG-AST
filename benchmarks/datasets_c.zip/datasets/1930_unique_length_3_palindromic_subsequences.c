#include <stdio.h>
#include <stdlib.h>

int maxConsecutiveValues(int coins[]);

int maxConsecutiveValues(int coins[])
{
  sort(coins);
  int maxValue = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(coins) / sizeof(coins[0])); _fi1++)
  {
    int coin = coins[_fi1];
    if (coin <= (maxValue + 1))
    {
      maxValue += coin;
    }
    else
    {
      break;
    }
  }

  return maxValue + 1;
}



int main()
{
  return 0;
}


