#include <stdio.h>
#include <stdlib.h>

int numOfWays(int m, int n);

int numOfWays(int m, int n)
{
  long mod = 1000000007;
  long a = 6;
  long b = 6;
  long c = 3;
  long d = 3;
  while ((--n) > 0)
  {
    long temp_a = a;
    long temp_c = c;
    a = ((a * 3) + (b * 2)) % mod;
    b = ((temp_a * 2) + (b * 2)) % mod;
    c = ((c * 3) + (d * 2)) % mod;
    d = ((temp_c * 2) + (d * 2)) % mod;
  }

  return (int) (m == 1 ? b : (a + c) % mod);
}



int main()
{
  return 0;
}


