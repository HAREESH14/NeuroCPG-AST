#include <stdio.h>
#include <stdlib.h>

int min_operations(int n);

int min_operations(int n)
{
  int count = 1;
  int temp = 1;
  while ((temp % n) != 0)
  {
    temp = (temp * 2) % n;
    count++;
  }

  return count;
}



int main()
{
  return 0;
}


