#include <stdio.h>
#include <stdlib.h>

int numberOfNiceDivisors(int primeFactors);

int numberOfNiceDivisors(int primeFactors)
{
  int MOD = 1000000007;
  long result = 1;
  for (int p = 2; p <= primeFactors; ++p)
  {
    if ((primeFactors % p) == 0)
    {
      int count = 0;
      while ((primeFactors % p) == 0)
      {
        primeFactors /= p;
        ++count;
      }

      result = (result * ((count * 2) + 1)) % MOD;
    }
  }

  return (int) result;
}



int main()
{
  return 0;
}


