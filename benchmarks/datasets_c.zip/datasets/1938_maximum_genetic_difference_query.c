#include <stdio.h>
#include <stdlib.h>

int minOperations(int nums[], int nums_len);

int minOperations(int nums[], int nums_len)
{
  int operations = 0;
  for (int i = 1; i < nums_len; ++i)
  {
    if (nums[i] <= nums[i - 1])
    {
      operations += (nums[i - 1] - nums[i]) + 1;
      nums[i] = nums[i - 1] + 1;
    }
  }

  return operations;
}



int main()
{
  return 0;
}


