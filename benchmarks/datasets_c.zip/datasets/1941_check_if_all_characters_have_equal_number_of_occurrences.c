#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int makeStringSorted(char* s);

int makeStringSorted(char* s)
{
  const int mod = 1000000007;
  int n = strlen(s);
  int fact[n + 1];
  int inv[n + 1];
  fact[0] = (inv[0] = 1);
  for (int i = 1; i <= n; ++i)
  {
    fact[i] = (int) (((1 * fact[i - 1]) * i) % mod);
    inv[i] = (int) (((1 * inv[i - 1]) * (mod - (mod / i))) % mod);
  }

  int ans = 0;
  for (int i = 0; i < n; ++i)
  {
    int less_than = 0;
    for (int j = i + 1; j < n; ++j)
    {
      if (s[j] < s[i])
      {
        ++less_than;
      }
    }

    ans = (int) ((ans + ((1 * less_than) * fact[(n - i) - 1])) % mod);
  }

  return ans;
}



int main()
{
  return 0;
}


