#include <stdio.h>
#include <stdlib.h>

int countDifferentSubsequenceGCDs(int nums[]);

int countDifferentSubsequenceGCDs(int nums[])
{
  int maximum = stream(nums);
  int gcdCount[maximum + 1];
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    for (int i = 1; (i * i) <= num; i++)
    {
      if ((num % i) == 0)
      {
        gcdCount[i]++;
        if ((i * i) != num)
        {
          gcdCount[num / i]++;
        }
      }
    }

  }

  int differentGCDs = 0;
  for (int i = 1; i <= maximum; i++)
  {
    if (gcdCount[i] > 0)
    {
      differentGCDs++;
    }
  }

  return differentGCDs;
}



int main()
{
  return 0;
}


