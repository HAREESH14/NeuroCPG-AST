#include <stdio.h>
#include <stdlib.h>

int signFunc(int x);
int arraySign(int nums[]);

int signFunc(int x)
{
  if (x > 0)
  {
    return 1;
  }
  if (x < 0)
  {
    return 1;
  }
  return 0;
}



int arraySign(int nums[])
{
  int product = 1;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int x = nums[_fi1];
    product *= x;
  }

  return signFunc(product);
}



int main()
{
  return 0;
}


