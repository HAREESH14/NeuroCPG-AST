#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minSideJumps(int obstacles[], int obstacles_len);

int minSideJumps(int obstacles[], int obstacles_len)
{
  int n = obstacles_len;
  int dp[n][3];
  dp[0][1] = 0;
  dp[0][0] = 1;
  dp[0][2] = 1;
  for (int i = 1; i < n; i++)
  {
    if (obstacles[i] != 1)
    {
      dp[i][0] = fmin(dp[i - 1][0], fmin(dp[i - 1][1] + 1, dp[i - 1][2] + 1));
    }
    if (obstacles[i] != 2)
    {
      dp[i][1] = fmin(dp[i - 1][1], fmin(dp[i - 1][0] + 1, dp[i - 1][2] + 1));
    }
    if (obstacles[i] != 3)
    {
      dp[i][2] = fmin(dp[i - 1][2], fmin(dp[i - 1][0] + 1, dp[i - 1][1] + 1));
    }
  }

  return fmin(dp[n - 1][0], fmin(dp[n - 1][1], dp[n - 1][2]));
}



int main()
{
  return 0;
}


