#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxElement(int arr[], int arr_len);

int maxElement(int arr[], int arr_len)
{
  int max_val = 0;
  for (int i = 0; i < arr_len; i++)
  {
    max_val = fmax(max_val, arr[i]);
  }

  return max_val / 2;
}



int main()
{
  return 0;
}


