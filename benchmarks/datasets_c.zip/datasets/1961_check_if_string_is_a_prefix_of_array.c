#include <stdio.h>
#include <stdlib.h>

int maxIceCream(int costs[], int coins);

int maxIceCream(int costs[], int coins)
{
  sort(costs);
  int count = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(costs) / sizeof(costs[0])); _fi1++)
  {
    int cost = costs[_fi1];
    if (coins >= cost)
    {
      coins -= cost;
      count++;
    }
    else
    {
      break;
    }
  }

  return count;
}



int main()
{
  return 0;
}


