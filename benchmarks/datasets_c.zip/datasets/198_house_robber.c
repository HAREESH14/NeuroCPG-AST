#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int rob(int nums[]);

int rob(int nums[])
{
  int prev1 = 0;
  int prev2 = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    int temp = prev1;
    prev1 = fmax(prev2 + num, prev1);
    prev2 = temp;
  }

  return prev1;
}



int main()
{
  return 0;
}


