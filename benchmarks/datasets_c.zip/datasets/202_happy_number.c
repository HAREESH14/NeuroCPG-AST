#include <stdio.h>
#include <stdlib.h>

int getNext(int n);
int isHappy(int n);

int getNext(int n)
{
  int sum = 0;
  while (n > 0)
  {
    int digit = n % 10;
    sum += digit * digit;
    n /= 10;
  }

  return sum;
}



int isHappy(int n)
{
  int slow = n;
  int fast = getNext(n);
  while ((fast != 1) && (slow != fast))
  {
    slow = getNext(slow);
    fast = getNext(getNext(fast));
  }

  return fast == 1;
}



int main()
{
  return 0;
}


