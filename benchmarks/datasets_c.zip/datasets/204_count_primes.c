#include <stdio.h>
#include <stdlib.h>

int countPrimes(int n);

int countPrimes(int n)
{
  if (n <= 2)
  {
    return 0;
  }
  int isPrime[n];
  fill(isPrime, 1);
  isPrime[0] = (isPrime[1] = 0);
  for (int i = 2; (i * i) < n; i++)
  {
    if (isPrime[i])
    {
      for (int j = i * i; j < n; j += i)
      {
        isPrime[j] = 0;
      }

    }
  }

  int count = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(isPrime) / sizeof(isPrime[0])); _fi1++)
  {
    int prime = isPrime[_fi1];
    if (prime)
    {
      count++;
    }
  }

  return count;
}



int main()
{
  return 0;
}


