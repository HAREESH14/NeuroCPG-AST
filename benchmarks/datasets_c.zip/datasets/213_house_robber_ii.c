#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int rob(int nums[], int nums_len);

int rob(int nums[], int nums_len)
{
  if (nums_len == 1)
  {
    return nums[0];
  }
  int prev = 0;
  int curr = 0;
  for (int i = 0; i < (nums_len - 1); i++)
  {
    int temp = fmax(curr, prev + nums[i]);
    prev = curr;
    curr = temp;
  }

  int res = curr;
  prev = 0;
  curr = 0;
  for (int i = 1; i < nums_len; i++)
  {
    int temp = fmax(curr, prev + nums[i]);
    prev = curr;
    curr = temp;
  }

  return fmax(res, curr);
}



int main()
{
  return 0;
}


