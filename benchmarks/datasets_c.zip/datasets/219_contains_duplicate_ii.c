#include <stdio.h>
#include <stdlib.h>
/* -- HashMap simulation -- */
#define HASHMAP_SIZE 100
typedef struct { int keys[HASHMAP_SIZE]; int vals[HASHMAP_SIZE]; int count; } HashMap;
HashMap hashmap_create() { HashMap m; m.count=0; return m; }
void hashmap_put(HashMap *m,int k,int v){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k){m->vals[i]=v;return;}m->keys[m->count]=k;m->vals[m->count]=v;m->count++;}
int hashmap_get(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return m->vals[i];return -1;}
int hashmap_contains(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return 1;return 0;}
/* -------------------------*/


int containsNearbyDuplicate(int nums[], int nums_len, int k);

int containsNearbyDuplicate(int nums[], int nums_len, int k)
{
  HashMap valueIndexMap = hashmap_create();
  for (int i = 0; i < nums_len; i++)
  {
    if (hashmap_contains(&valueIndexMap, nums[i]) && ((i - hashmap_get(&valueIndexMap, nums[i])) <= k))
    {
      return 1;
    }
    hashmap_put(&valueIndexMap, nums[i], i);
  }

  return 0;
}



int main()
{
  return 0;
}


