#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int totalArea(int ax1, int ay1, int ax2, int ay2, int bx1, int by1, int bx2, int by2);

int totalArea(int ax1, int ay1, int ax2, int ay2, int bx1, int by1, int bx2, int by2)
{
  int area1 = (ax2 - ax1) * (ay2 - ay1);
  int area2 = (bx2 - bx1) * (by2 - by1);
  int overlapWidth = fmin(ax2, bx2) - fmax(ax1, bx1);
  int overlapHeight = fmin(ay2, by2) - fmax(ay1, by1);
  int overlapArea = fmax(overlapWidth, 0) * fmax(overlapHeight, 0);
  return (area1 + area2) - overlapArea;
}



int main()
{
  return 0;
}


