#include <stdio.h>
#include <stdlib.h>

int isPowerOfTwo(int n);

int isPowerOfTwo(int n)
{
  if (n <= 0)
  {
    return 0;
  }
  return (n & (n - 1)) == 0;
}



int main()
{
  return 0;
}


