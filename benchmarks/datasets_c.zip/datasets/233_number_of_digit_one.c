#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int countDigitOne(int n);

int countDigitOne(int n)
{
  int count = 0;
  for (long i = 1; i <= n; i *= 10)
  {
    long divider = i * 10;
    count += ((n / divider) * i) + fmin(fmax(((n % divider) - i) + 1, 0), i);
  }

  return count;
}



int main()
{
  return 0;
}


