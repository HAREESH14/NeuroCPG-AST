#include <stdio.h>
#include <stdlib.h>

int productExceptSelf(int nums[], int nums_len);

int productExceptSelf(int nums[], int nums_len)
{
  int n = nums_len;
  int answer[n];
  fill(answer, 1);
  int left = 1;
  for (int i = 0; i < n; i++)
  {
    answer[i] *= left;
    left *= nums[i];
  }

  int right = 1;
  for (int i = n - 1; i >= 0; i--)
  {
    answer[i] *= right;
    right *= nums[i];
  }

  return answer;
}



int main()
{
  return 0;
}


