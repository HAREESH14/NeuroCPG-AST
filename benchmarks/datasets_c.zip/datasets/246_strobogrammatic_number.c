#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* -- HashMap simulation -- */
#define HASHMAP_SIZE 100
typedef struct { int keys[HASHMAP_SIZE]; int vals[HASHMAP_SIZE]; int count; } HashMap;
HashMap hashmap_create() { HashMap m; m.count=0; return m; }
void hashmap_put(HashMap *m,int k,int v){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k){m->vals[i]=v;return;}m->keys[m->count]=k;m->vals[m->count]=v;m->count++;}
int hashmap_get(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return m->vals[i];return -1;}
int hashmap_contains(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return 1;return 0;}
/* -------------------------*/


int isStrobogrammatic(char* num);

int isStrobogrammatic(char* num)
{
  HashMap lookup = hashmap_create();
  int left = 0;
  int right = strlen(num) - 1;
  while (left <= right)
  {
    if (hashmap_contains(&lookup, num[left]) || (hashmap_get(&lookup, num[left]) != num[right]))
    {
      return 0;
    }
    left++;
    right--;
  }

  return 1;
}



int main()
{
  return 0;
}


