#include <stdio.h>
#include <stdlib.h>

int addDigits(int num);

int addDigits(int num)
{
  return 1 + ((num - 1) % 9);
}



int main()
{
  return 0;
}


