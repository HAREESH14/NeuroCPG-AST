#include <stdio.h>
#include <stdlib.h>

int threeSumSmaller(int nums[], int nums_len, int target);

int threeSumSmaller(int nums[], int nums_len, int target)
{
  int count = 0;
  sort(nums);
  for (int i = 0; i < nums_len; ++i)
  {
    int j = i + 1;
    int k = nums_len - 1;
    while (j < k)
    {
      if (((nums[i] + nums[j]) + nums[k]) < target)
      {
        count += k - j;
        ++j;
      }
      else
      {
        --k;
      }
    }

  }

  return count;
}



int main()
{
  return 0;
}


