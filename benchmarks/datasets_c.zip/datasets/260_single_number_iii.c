#include <stdio.h>
#include <stdlib.h>

int singleNumber(int nums[]);

int singleNumber(int nums[])
{
  int xor_all = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    xor_all ^= num;
  }

  int bit = xor_all & (-xor_all);
  int n1 = 0;
  int n2 = 0;
  for (int _fi2 = 0; _fi2 < (sizeof(nums) / sizeof(nums[0])); _fi2++)
  {
    int num = nums[_fi2];
    if ((num & bit) != 0)
    {
      n1 ^= num;
    }
    else
    {
      n2 ^= num;
    }
  }

  return n1, n2;
}



int main()
{
  return 0;
}


