#include <stdio.h>
#include <stdlib.h>

int isUgly(int n);

int isUgly(int n)
{
  if (n <= 0)
  {
    return 0;
  }
  while ((n % 2) == 0)
  {
    n /= 2;
  }

  while ((n % 3) == 0)
  {
    n /= 3;
  }

  while ((n % 5) == 0)
  {
    n /= 5;
  }

  return n == 1;
}



int main()
{
  return 0;
}


