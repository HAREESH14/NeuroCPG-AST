#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int nthUglyNumber(int n);

int nthUglyNumber(int n)
{
  int uglyNumbers[n];
  uglyNumbers[0] = 1;
  int i2 = 0;
  int i3 = 0;
  int i5 = 0;
  for (int i = 1; i < n; i++)
  {
    uglyNumbers[i] = fmin(fmin(uglyNumbers[i2] * 2, uglyNumbers[i3] * 3), uglyNumbers[i5] * 5);
    if (uglyNumbers[i] == (uglyNumbers[i2] * 2))
    {
      i2++;
    }
    if (uglyNumbers[i] == (uglyNumbers[i3] * 3))
    {
      i3++;
    }
    if (uglyNumbers[i] == (uglyNumbers[i5] * 5))
    {
      i5++;
    }
  }

  return uglyNumbers[n - 1];
}



int main()
{
  return 0;
}


