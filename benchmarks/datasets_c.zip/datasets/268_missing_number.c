#include <stdio.h>
#include <stdlib.h>

int missingNumber(int nums[], int nums_len);

int missingNumber(int nums[], int nums_len)
{
  int n = nums_len;
  int expectedSum = (n * (n + 1)) / 2;
  int actualSum = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    actualSum += num;
  }

  return expectedSum - actualSum;
}



int main()
{
  return 0;
}


