#include <stdio.h>
#include <stdlib.h>

int removeDuplicates(int nums[], int nums_len);

int removeDuplicates(int nums[], int nums_len)
{
  if (nums_len == 0)
  {
    return 0;
  }
  int i = 0;
  for (int j = 1; j < nums_len; j++)
  {
    if (nums[j] != nums[i])
    {
      i++;
      nums[i] = nums[j];
    }
  }

  return i + 1;
}



int main()
{
  return 0;
}


