#include <stdio.h>
#include <stdlib.h>

int hIndex(int citations[], int citations_len);

int hIndex(int citations[], int citations_len)
{
  sort(citations);
  int h = 0;
  for (int i = citations_len - 1; i >= 0; i--)
  {
    int rank = citations_len - i;
    if (citations[i] >= rank)
    {
      h = rank;
    }
    else
    {
      break;
    }
  }

  return h;
}



int main()
{
  return 0;
}


