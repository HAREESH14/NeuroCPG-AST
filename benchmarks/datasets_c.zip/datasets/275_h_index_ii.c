#include <stdio.h>
#include <stdlib.h>

int hIndex(int citations[], int citations_len);

int hIndex(int citations[], int citations_len)
{
  int n = citations_len;
  int left = 0;
  int right = n - 1;
  while (left <= right)
  {
    int mid = left + ((right - left) / 2);
    if (citations[mid] == (n - mid))
    {
      return n - mid;
    }
    else
      if (citations[mid] < (n - mid))
    {
      left = mid + 1;
    }
    else
    {
      right = mid - 1;
    }
  }

  return n - left;
}



int main()
{
  return 0;
}


