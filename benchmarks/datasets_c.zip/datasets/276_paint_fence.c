#include <stdio.h>
#include <stdlib.h>

int numWays(int n, int k);

int numWays(int n, int k)
{
  if (n == 0)
  {
    return 0;
  }
  if (n == 1)
  {
    return k;
  }
  int same = k;
  int different = k * (k - 1);
  for (int i = 2; i < n; ++i)
  {
    int temp = different;
    different = (same + different) * (k - 1);
    same = temp;
  }

  return same + different;
}



int main()
{
  return 0;
}


