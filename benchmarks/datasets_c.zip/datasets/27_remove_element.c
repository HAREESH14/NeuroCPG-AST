#include <stdio.h>
#include <stdlib.h>

int removeElement(int nums[], int nums_len, int val);

int removeElement(int nums[], int nums_len, int val)
{
  int i = 0;
  for (int j = 0; j < nums_len; j++)
  {
    if (nums[j] != val)
    {
      nums[i] = nums[j];
      i++;
    }
  }

  return i;
}



int main()
{
  return 0;
}


