#include <stdio.h>
#include <stdlib.h>

void wiggleSort(int nums[], int nums_len);

void wiggleSort(int nums[], int nums_len)
{
  for (int i = 1; i < nums_len; i++)
  {
    if ((((i % 2) == 0) && (nums[i] > nums[i - 1])) || (((i % 2) == 1) && (nums[i] < nums[i - 1])))
    {
      int temp = nums[i];
      nums[i] = nums[i - 1];
      nums[i - 1] = temp;
    }
  }

}



int main()
{
  return 0;
}


