#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int strStr(char* haystack, char* needle);

int strStr(char* haystack, char* needle)
{
  if (strlen(needle) == 0)
  {
    return 0;
  }
  int index = strstr(haystack, needle);
  return index;
}



int main()
{
  return 0;
}


