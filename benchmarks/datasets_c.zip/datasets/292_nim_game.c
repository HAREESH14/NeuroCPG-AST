#include <stdio.h>
#include <stdlib.h>

int canWinNim(int n);

int canWinNim(int n)
{
  return (n % 4) != 0;
}



int main()
{
  return 0;
}


