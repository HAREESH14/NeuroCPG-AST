#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int lengthOfLIS(int nums[], int nums_len);

int lengthOfLIS(int nums[], int nums_len)
{
  int dp[nums_len];
  int max_length = 1;
  fill(dp, 1);
  for (int i = 1; i < nums_len; i++)
  {
    for (int j = 0; j < i; j++)
    {
      if (nums[i] > nums[j])
      {
        dp[i] = fmax(dp[i], dp[j] + 1);
      }
    }

    max_length = fmax(max_length, dp[i]);
  }

  return max_length;
}



int main()
{
  return 0;
}


