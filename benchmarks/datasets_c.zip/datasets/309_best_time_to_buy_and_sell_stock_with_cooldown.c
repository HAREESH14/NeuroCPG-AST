#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxProfit(int prices[], int prices_len);

int maxProfit(int prices[], int prices_len)
{
  int profit = 0;
  for (int i = 1; i < prices_len; i++)
  {
    profit += fmax(prices[i] - prices[i - 1], 0);
  }

  return profit;
}



int main()
{
  return 0;
}


