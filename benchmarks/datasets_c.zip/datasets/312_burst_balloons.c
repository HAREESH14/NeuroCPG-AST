#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxCoins(int nums[], int nums_len);

int maxCoins(int nums[], int nums_len)
{
  int n = nums_len;
  int newNums[n + 2];
  newNums[0] = 1;
  newNums[n + 1] = 1;
  for (int i = 1; i <= n; i++)
  {
    newNums[i] = nums[i - 1];
  }

  int dp[n + 2][n + 2];
  for (int len = 1; len <= n; len++)
  {
    for (int left = 1; left <= ((n - len) + 1); left++)
    {
      int right = (left + len) - 1;
      for (int i = left; i <= right; i++)
      {
        dp[left][right] = fmax(dp[left][right], (((newNums[left - 1] * newNums[i]) * newNums[right + 1]) + dp[left][i - 1]) + dp[i + 1][right]);
      }

    }

  }

  return dp[1][n];
}



int main()
{
  return 0;
}


