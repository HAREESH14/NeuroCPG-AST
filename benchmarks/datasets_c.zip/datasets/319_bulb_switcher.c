#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int bulbSwitch(int n);

int bulbSwitch(int n)
{
  return (int) sqrt(n);
}



int main()
{
  return 0;
}


