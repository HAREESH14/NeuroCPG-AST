#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int coinChange(int coins[], int amount);

int coinChange(int coins[], int amount)
{
  int dp[amount + 1];
  fill(dp, amount + 1);
  dp[0] = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(coins) / sizeof(coins[0])); _fi1++)
  {
    int coin = coins[_fi1];
    for (int i = coin; i <= amount; i++)
    {
      dp[i] = fmin(dp[i], dp[i - coin] + 1);
    }

  }

  return (dp[amount] <= amount ? dp[amount] : 1);
}



int main()
{
  return 0;
}


