#include <stdio.h>
#include <stdlib.h>

void wiggleSort(int nums[], int nums_len);

void wiggleSort(int nums[], int nums_len)
{
  sort(nums);
  for (int i = 1; i < (nums_len - 1); i += 2)
  {
    int temp = nums[i];
    nums[i] = nums[i + 1];
    nums[i + 1] = temp;
  }

}



int main()
{
  return 0;
}


