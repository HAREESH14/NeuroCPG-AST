#include <stdio.h>
#include <stdlib.h>

int countRangeSum(int nums[], int nums_len, int lower, int upper);
int countWhileMergeSort(long sums[], int lower, int upper, int start, int end);

int countRangeSum(int nums[], int nums_len, int lower, int upper)
{
  long sums[nums_len + 1];
  for (int i = 0; i < nums_len; ++i)
  {
    sums[i + 1] = sums[i] + nums[i];
  }

  return countWhileMergeSort(sums, lower, upper, 0, nums_len);
}



int countWhileMergeSort(long sums[], int lower, int upper, int start, int end)
{
  if (start >= end)
  {
    return 0;
  }
  int mid = start + ((end - start) / 2);
  int count = countWhileMergeSort(sums, lower, upper, start, mid) + countWhileMergeSort(sums, lower, upper, mid + 1, end);
  int j = mid + 1;
  int k = mid + 1;
  for (int i = start; i <= mid; ++i)
  {
    while ((j <= end) && ((sums[j] - sums[i]) < lower))
    {
      ++j;
    }

    while ((k <= end) && ((sums[k] - sums[i]) <= upper))
    {
      ++k;
    }

    count += k - j;
  }

  sort(sums, start, end + 1);
  return count;
}



int main()
{
  return 0;
}


