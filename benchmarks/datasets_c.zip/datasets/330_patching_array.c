#include <stdio.h>
#include <stdlib.h>

int minPatches(int nums[], int nums_len, int n);

int minPatches(int nums[], int nums_len, int n)
{
  long maxSum = 0;
  int patches = 0;
  int i = 0;
  while (maxSum < n)
  {
    if ((i < nums_len) && (nums[i] <= (maxSum + 1)))
    {
      maxSum += nums[i];
      i++;
    }
    else
    {
      maxSum += maxSum + 1;
      patches++;
    }
  }

  return patches;
}



int main()
{
  return 0;
}


