#include <stdio.h>
#include <stdlib.h>

int countBits(int n);

int countBits(int n)
{
  int ans[n + 1];
  for (int i = 1; i <= n; ++i)
  {
    ans[i] = ans[i & (i - 1)] + 1;
  }

  return ans;
}



int main()
{
  return 0;
}


