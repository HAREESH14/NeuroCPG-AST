#include <stdio.h>
#include <stdlib.h>

int isPowerOfFour(int n);

int isPowerOfFour(int n)
{
  if (n <= 0)
  {
    return 0;
  }
  while ((n % 4) == 0)
  {
    n /= 4;
  }

  return n == 1;
}



int main()
{
  return 0;
}


