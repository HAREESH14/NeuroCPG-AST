#include <stdio.h>
#include <stdlib.h>

int integerBreak(int n);

int integerBreak(int n)
{
  if (n <= 3)
  {
    return n - 1;
  }
  int product = 1;
  while (n > 4)
  {
    product *= 3;
    n -= 3;
  }

  return product * n;
}



int main()
{
  return 0;
}


