#include <stdio.h>
#include <stdlib.h>

void reverseString(char s[], int s_len);

void reverseString(char s[], int s_len)
{
  int left = 0;
  int right = s_len - 1;
  while (left < right)
  {
    char temp = s[left];
    s[left++] = s[right];
    s[right--] = temp;
  }

}



int main()
{
  return 0;
}


