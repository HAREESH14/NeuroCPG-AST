#include <stdio.h>
#include <stdlib.h>

int searchRange(int nums[], int nums_len, int target);

int searchRange(int nums[], int nums_len, int target)
{
  int start = 1;
  int end = 1;
  int left = 0;
  int right = nums_len - 1;
  while (left <= right)
  {
    int mid = left + ((right - left) / 2);
    if (nums[mid] < target)
    {
      left = mid + 1;
    }
    else
    {
      right = mid - 1;
      if (nums[mid] == target)
      {
        start = mid;
      }
    }
  }

  left = 0;
  right = nums_len - 1;
  while (left <= right)
  {
    int mid = left + ((right - left) / 2);
    if (nums[mid] > target)
    {
      right = mid - 1;
    }
    else
    {
      left = mid + 1;
      if (nums[mid] == target)
      {
        end = mid;
      }
    }
  }

  return start, end;
}



int main()
{
  return 0;
}


