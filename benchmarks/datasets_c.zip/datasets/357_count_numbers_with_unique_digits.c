#include <stdio.h>
#include <stdlib.h>

int countNumbersWithUniqueDigits(int n);

int countNumbersWithUniqueDigits(int n)
{
  if (n == 0)
  {
    return 1;
  }
  int total = 10;
  int uniqueDigits = 9;
  int currentAvailableDigits = 9;
  while (((n--) > 1) && (currentAvailableDigits > 0))
  {
    uniqueDigits *= currentAvailableDigits;
    total += uniqueDigits;
    currentAvailableDigits--;
  }

  return total;
}



int main()
{
  return 0;
}


