#include <stdio.h>
#include <stdlib.h>

int searchInsert(int nums[], int nums_len, int target);

int searchInsert(int nums[], int nums_len, int target)
{
  int left = 0;
  int right = nums_len - 1;
  while (left <= right)
  {
    int mid = left + ((right - left) / 2);
    if (nums[mid] == target)
    {
      return mid;
    }
    if (nums[mid] < target)
    {
      left = mid + 1;
    }
    else
    {
      right = mid - 1;
    }
  }

  return left;
}



int main()
{
  return 0;
}


