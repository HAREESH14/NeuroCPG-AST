#include <stdio.h>
#include <stdlib.h>

int sortTransformedArray(int nums[], int nums_len, int a, int b, int c);

int sortTransformedArray(int nums[], int nums_len, int a, int b, int c)
{
  int result[nums_len];
  int i = 0;
  int j = nums_len - 1;
  int index = (a >= 0 ? nums_len - 1 : 0);
  while (i <= j)
  {
    int left = (((nums[i] * nums[i]) * a) + (nums[i] * b)) + c;
    int right = (((nums[j] * nums[j]) * a) + (nums[j] * b)) + c;
    if (a >= 0)
    {
      if (left >= right)
      {
        result[index--] = left;
        i++;
      }
      else
      {
        result[index--] = right;
        j--;
      }
    }
    else
    {
      if (left <= right)
      {
        result[index++] = left;
        i++;
      }
      else
      {
        result[index++] = right;
        j--;
      }
    }
  }

  return result;
}



int main()
{
  return 0;
}


