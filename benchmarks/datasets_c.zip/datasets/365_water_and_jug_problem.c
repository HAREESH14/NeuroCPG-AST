#include <stdio.h>
#include <stdlib.h>

int canMeasureWater(int jug1Capacity, int jug2Capacity, int targetCapacity);
int gcd(int a, int b);

int canMeasureWater(int jug1Capacity, int jug2Capacity, int targetCapacity)
{
  if (targetCapacity > (jug1Capacity + jug2Capacity))
  {
    return 0;
  }
  if (((jug1Capacity == targetCapacity) || (jug2Capacity == targetCapacity)) || ((jug1Capacity + jug2Capacity) == targetCapacity))
  {
    return 1;
  }
  return (targetCapacity % gcd(jug1Capacity, jug2Capacity)) == 0;
}



int gcd(int a, int b)
{
  while (b != 0)
  {
    int tmp = a % b;
    a = b;
    b = tmp;
  }

  return a;
}



int main()
{
  return 0;
}


