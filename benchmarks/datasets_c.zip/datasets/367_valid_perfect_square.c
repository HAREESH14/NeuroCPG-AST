#include <stdio.h>
#include <stdlib.h>

int isPerfectSquare(int num);

int isPerfectSquare(int num)
{
  if (num < 2)
  {
    return 1;
  }
  long left = 2;
  long right = num / 2;
  long mid;
  long square;
  while (left <= right)
  {
    mid = left + ((right - left) / 2);
    square = mid * mid;
    if (square == num)
    {
      return 1;
    }
    if (square > num)
    {
      right = mid - 1;
    }
    else
    {
      left = mid + 1;
    }
  }

  return 0;
}



int main()
{
  return 0;
}


