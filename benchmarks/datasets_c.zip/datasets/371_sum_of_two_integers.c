#include <stdio.h>
#include <stdlib.h>

int add(int a, int b);

int add(int a, int b)
{
  while (b != 0)
  {
    int carry = a & b;
    a = a ^ b;
    b = carry << 1;
  }

  return a;
}



int main()
{
  return 0;
}


