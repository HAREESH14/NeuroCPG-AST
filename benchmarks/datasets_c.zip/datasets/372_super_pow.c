#include <stdio.h>
#include <stdlib.h>

int powmod(int a, int b);
int superPow(int a, int b[]);

int powmod(int a, int b)
{
  if (b == 0)
  {
    return 1;
  }
  int res = powmod(a, b / 2);
  if ((b % 2) == 0)
  {
    return (res * res) % 1337;
  }
  return (((res * res) % 1337) * a) % 1337;
}



int superPow(int a, int b[])
{
  int n = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(b) / sizeof(b[0])); _fi1++)
  {
    int bi = b[_fi1];
    n = ((n * 10) + bi) % 1140;
  }

  return powmod(a % 1337, n + 1140);
}



int main()
{
  return 0;
}


