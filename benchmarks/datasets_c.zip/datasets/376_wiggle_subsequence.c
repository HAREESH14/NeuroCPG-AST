#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int wiggleMaxLength(int nums[], int nums_len);

int wiggleMaxLength(int nums[], int nums_len)
{
  int len = nums_len;
  if (len < 2)
  {
    return len;
  }
  int up = 1;
  int down = 1;
  for (int i = 1; i < len; ++i)
  {
    if (nums[i] > nums[i - 1])
    {
      up = down + 1;
    }
    else
      if (nums[i] < nums[i - 1])
    {
      down = up + 1;
    }
  }

  return fmax(up, down);
}



int main()
{
  return 0;
}


