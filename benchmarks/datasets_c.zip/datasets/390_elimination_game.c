#include <stdio.h>
#include <stdlib.h>

int lastRemaining(int n);

int lastRemaining(int n)
{
  int direction = 1;
  int head = 1;
  int remaining = n;
  int step = 1;
  while (remaining > 1)
  {
    if (direction || ((remaining % 2) == 1))
    {
      head += step;
    }
    remaining /= 2;
    step *= 2;
    direction = !direction;
  }

  return head;
}



int main()
{
  return 0;
}


