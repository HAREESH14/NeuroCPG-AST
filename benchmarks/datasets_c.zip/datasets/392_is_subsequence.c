#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int isSubsequence(char* s, char* t);

int isSubsequence(char* s, char* t)
{
  int si = 0;
  int ti = 0;
  while ((si < strlen(s)) && (ti < strlen(t)))
  {
    if (s[si] == t[ti])
    {
      si++;
    }
    ti++;
  }

  return si == strlen(s);
}



int main()
{
  return 0;
}


