#include <stdio.h>
#include <stdlib.h>

int validUtf8(int data[]);

int validUtf8(int data[])
{
  int count = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(data) / sizeof(data[0])); _fi1++)
  {
    int byteValue = data[_fi1];
    if (count == 0)
    {
      if ((byteValue >> 5) == 0b110)
      {
        count = 1;
      }
      else
        if ((byteValue >> 4) == 0b1110)
      {
        count = 2;
      }
      else
        if ((byteValue >> 3) == 0b11110)
      {
        count = 3;
      }
      else
        if ((byteValue >> 7) == 1)
      {
        return 0;
      }
    }
    else
    {
      if ((byteValue >> 6) != 0b10)
      {
        return 0;
      }
      count--;
    }
  }

  return count == 0;
}



int main()
{
  return 0;
}


