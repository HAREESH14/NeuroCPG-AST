#include <stdio.h>
#include <stdlib.h>

int minOperations(int n);

int minOperations(int n)
{
  int steps = 0;
  while (n > 1)
  {
    n = ((n % 2) == 0 ? n / 2 : n - 1);
    steps++;
  }

  return steps;
}



int main()
{
  return 0;
}


