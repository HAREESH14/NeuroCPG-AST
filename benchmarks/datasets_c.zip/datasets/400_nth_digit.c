#include <stdio.h>
#include <stdlib.h>

int findNthDigit(int n);

int findNthDigit(int n)
{
  int size = 1;
  long length = 9;
  int start = 1;
  while (n > (length * size))
  {
    n -= length * size;
    size++;
    length *= 10;
    start *= 10;
  }

  start += (n - 1) / size;
  char* s = start;
  return getNumericValue(s[(n - 1) % size]);
}



int main()
{
  return 0;
}


