#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int validWordAbbreviation(char* word, char* abbr);

int validWordAbbreviation(char* word, char* abbr)
{
  int i = 0;
  int j = 0;
  while ((i < strlen(word)) && (j < strlen(abbr)))
  {
    if (isDigit(abbr[j]))
    {
      if (abbr[j] == '0')
      {
        return 0;
      }
      int num = 0;
      while ((j < strlen(abbr)) && isDigit(abbr[j]))
      {
        num = (num * 10) + (abbr[j++] - '0');
      }

      i += num;
    }
    else
    {
      if (word[i++] != abbr[j++])
      {
        return 0;
      }
    }
  }

  return (i == strlen(word)) && (j == strlen(abbr));
}



int main()
{
  return 0;
}


