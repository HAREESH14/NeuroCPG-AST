#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int splitArray(int nums[], int m);

int splitArray(int nums[], int m)
{
  long left = 0;
  long right = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    left = fmax(left, num);
    right += num;
  }

  while (left < right)
  {
    long mid = (left + right) / 2;
    int count = 1;
    long curSum = 0;
    for (int _fi2 = 0; _fi2 < (sizeof(nums) / sizeof(nums[0])); _fi2++)
    {
      int num = nums[_fi2];
      curSum += num;
      if (curSum > mid)
      {
        curSum = num;
        count++;
      }
    }

    if (count > m)
    {
      left = mid + 1;
    }
    else
    {
      right = mid;
    }
  }

  return (int) left;
}



int main()
{
  return 0;
}


