#include <stdio.h>
#include <stdlib.h>
/* -- ArrayList simulation -- */
#define AL_INIT_CAP 16
typedef struct { int *data; int size; int capacity; } ArrayList;
ArrayList arraylist_create() { ArrayList a; a.data=(int*)malloc(AL_INIT_CAP*sizeof(int)); a.size=0; a.capacity=AL_INIT_CAP; return a; }
void arraylist_add(ArrayList *a,int v){if(a->size>=a->capacity){a->capacity*=2;a->data=(int*)realloc(a->data,a->capacity*sizeof(int));}a->data[a->size++]=v;}
int arraylist_get(ArrayList *a,int i){return a->data[i];}
void arraylist_free(ArrayList *a){free(a->data);a->data=NULL;a->size=0;}
/* ----------------------------*/


ArrayList fizzBuzz(int n);

ArrayList fizzBuzz(int n)
{
  ArrayList result = arraylist_create();
  for (int i = 1; i <= n; i++)
  {
    if ((i % 15) == 0)
    {
      arraylist_add(&result, "FizzBuzz");
    }
    else
      if ((i % 3) == 0)
    {
      arraylist_add(&result, "Fizz");
    }
    else
      if ((i % 5) == 0)
    {
      arraylist_add(&result, "Buzz");
    }
    else
    {
      arraylist_add(&result, i);
    }
  }

  return result;
}



int main()
{
  return 0;
}


