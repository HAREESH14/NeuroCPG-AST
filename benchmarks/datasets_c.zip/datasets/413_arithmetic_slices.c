#include <stdio.h>
#include <stdlib.h>

int numberOfArithmeticSlices(int nums[], int nums_len);

int numberOfArithmeticSlices(int nums[], int nums_len)
{
  int n = nums_len;
  int count = 0;
  int cur = 0;
  for (int i = 2; i < n; ++i)
  {
    if ((nums[i] - nums[i - 1]) == (nums[i - 1] - nums[i - 2]))
    {
      cur++;
      count += cur;
    }
    else
    {
      cur = 0;
    }
  }

  return count;
}



int main()
{
  return 0;
}


