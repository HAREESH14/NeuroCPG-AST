#include <stdio.h>
#include <stdlib.h>

int canPartition(int nums[]);

int canPartition(int nums[])
{
  int sum = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    sum += num;
  }

  if ((sum % 2) != 0)
  {
    return 0;
  }
  int target = sum / 2;
  int dp[target + 1];
  dp[0] = 1;
  for (int _fi2 = 0; _fi2 < (sizeof(nums) / sizeof(nums[0])); _fi2++)
  {
    int num = nums[_fi2];
    for (int i = target; i >= num; i--)
    {
      dp[i] = dp[i] || dp[i - num];
    }

  }

  return dp[target];
}



int main()
{
  return 0;
}


