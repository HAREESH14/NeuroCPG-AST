#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int wordsTyping(char* sentence[], int rows, int cols);

int wordsTyping(char* sentence[], int rows, int cols)
{
  int totalChars = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(sentence) / sizeof(sentence[0])); _fi1++)
  {
    char* word = sentence[_fi1];
    totalChars += strlen(word) + 1;
  }

  int result = 0;
  int index = 0;
  for (int r = 0; r < rows; ++r)
  {
    int remainingCols = cols;
    while (1)
    {
      int wordLen = sentence[index];
      if (remainingCols >= wordLen)
      {
        remainingCols -= wordLen + 1;
        index = (index + 1) % strlen(sentence);
        if (index == 0)
        {
          result++;
        }
      }
      else
      {
        break;
      }
    }

  }

  return result;
}



int main()
{
  return 0;
}


