#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int characterReplacement(char* s, int k);

int characterReplacement(char* s, int k)
{
  int n = strlen(s);
  int left = 0;
  int right = 0;
  int maxFreq = 0;
  int result = 0;
  int freq[26];
  for (right = 0; right < n; right++)
  {
    freq[s[right] - 'A']++;
    maxFreq = fmax(maxFreq, freq[s[right] - 'A']);
    if ((((right - left) + 1) - maxFreq) > k)
    {
      freq[s[left] - 'A']--;
      left++;
    }
    result = fmax(result, (right - left) + 1);
  }

  return result;
}



int main()
{
  return 0;
}


