#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int trap(int height[], int height_len);

int trap(int height[], int height_len)
{
  int n = height_len;
  int left = 0;
  int right = n - 1;
  int maxLeft = 0;
  int maxRight = 0;
  int water = 0;
  while (left < right)
  {
    if (height[left] <= height[right])
    {
      maxLeft = fmax(maxLeft, height[left]);
      water += maxLeft - height[left];
      left++;
    }
    else
    {
      maxRight = fmax(maxRight, height[right]);
      water += maxRight - height[right];
      right--;
    }
  }

  return water;
}



int main()
{
  return 0;
}


