#include <stdio.h>
#include <stdlib.h>

int arrangeCoins(int n);

int arrangeCoins(int n)
{
  int k = 0;
  while (n > k)
  {
    k++;
    n -= k;
  }

  return k;
}



int main()
{
  return 0;
}


