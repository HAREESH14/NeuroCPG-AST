#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int isMatch(char* s, char* p);

int isMatch(char* s, char* p)
{
  int m = strlen(s);
  int n = strlen(p);
  int i = 0;
  int j = 0;
  int asterisk = 1;
  int match = 0;
  while (i < m)
  {
    if ((j < n) && ((s[i] == p[j]) || (p[j] == '?')))
    {
      i++;
      j++;
    }
    else
      if ((j < n) && (p[j] == '*'))
    {
      match = i;
      asterisk = j++;
    }
    else
      if (asterisk != 1)
    {
      i = ++match;
      j = asterisk + 1;
    }
    else
    {
      return 0;
    }
  }

  while ((j < n) && (p[j] == '*'))
  {
    j++;
  }

  return j == n;
}



int main()
{
  return 0;
}


