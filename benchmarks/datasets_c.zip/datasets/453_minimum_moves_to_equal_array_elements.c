#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minMoves(int nums[]);

int minMoves(int nums[])
{
  int min_element = nums[0];
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    min_element = fmin(min_element, num);
  }

  int moves = 0;
  for (int _fi2 = 0; _fi2 < (sizeof(nums) / sizeof(nums[0])); _fi2++)
  {
    int num = nums[_fi2];
    moves += num - min_element;
  }

  return moves;
}



int main()
{
  return 0;
}


