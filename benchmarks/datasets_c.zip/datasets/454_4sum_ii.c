#include <stdio.h>
#include <stdlib.h>
/* -- HashMap simulation -- */
#define HASHMAP_SIZE 100
typedef struct { int keys[HASHMAP_SIZE]; int vals[HASHMAP_SIZE]; int count; } HashMap;
HashMap hashmap_create() { HashMap m; m.count=0; return m; }
void hashmap_put(HashMap *m,int k,int v){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k){m->vals[i]=v;return;}m->keys[m->count]=k;m->vals[m->count]=v;m->count++;}
int hashmap_get(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return m->vals[i];return -1;}
int hashmap_contains(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return 1;return 0;}
/* -------------------------*/


int fourSumCount(int nums1[], int nums2[], int nums3[], int nums4[]);

int fourSumCount(int nums1[], int nums2[], int nums3[], int nums4[])
{
  HashMap hashMap = hashmap_create();
  int count = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums1) / sizeof(nums1[0])); _fi1++)
  {
    int i = nums1[_fi1];
    for (int _fi2 = 0; _fi2 < (sizeof(nums2) / sizeof(nums2[0])); _fi2++)
    {
      int j = nums2[_fi2];
      hashmap_put(&hashMap, i + j, getOrDefault(i + j, 0) + 1);
    }

  }

  for (int _fi3 = 0; _fi3 < (sizeof(nums3) / sizeof(nums3[0])); _fi3++)
  {
    int k = nums3[_fi3];
    for (int _fi4 = 0; _fi4 < (sizeof(nums4) / sizeof(nums4[0])); _fi4++)
    {
      int l = nums4[_fi4];
      count += getOrDefault(k + l, 0);
    }

  }

  return count;
}



int main()
{
  return 0;
}


