#include <stdio.h>
#include <stdlib.h>

int findContentChildren(int g[], int g_len, int s[], int s_len);

int findContentChildren(int g[], int g_len, int s[], int s_len)
{
  sort(g);
  sort(s);
  int i = 0;
  int j = 0;
  while ((i < g_len) && (j < s_len))
  {
    if (s[j] >= g[i])
    {
      i++;
    }
    j++;
  }

  return i;
}



int main()
{
  return 0;
}


