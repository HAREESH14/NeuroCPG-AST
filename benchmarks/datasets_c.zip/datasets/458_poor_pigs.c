#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int poorPigs(int buckets, int minutesToDie, int minutesToTest);

int poorPigs(int buckets, int minutesToDie, int minutesToTest)
{
  int pigs = 0;
  while (pow((minutesToTest / minutesToDie) + 1, pigs) < buckets)
  {
    pigs++;
  }

  return pigs;
}



int main()
{
  return 0;
}


