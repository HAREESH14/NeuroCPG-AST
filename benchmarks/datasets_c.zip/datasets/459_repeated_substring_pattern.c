#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int canConstruct(char* s);

int canConstruct(char* s)
{
  int n = strlen(s);
  for (int i = n / 2; i > 0; --i)
  {
    if ((n % i) == 0)
    {
      char* substr = s + 0;
      int flag = 1;
      for (int j = i; j < n; j += i)
      {
        if (s + j)
        {
          flag = 0;
          break;
        }
      }

      if (flag)
      {
        return 1;
      }
    }
  }

  return 0;
}



int main()
{
  return 0;
}


