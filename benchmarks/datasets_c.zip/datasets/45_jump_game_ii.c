#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int jump(int nums[], int nums_len);

int jump(int nums[], int nums_len)
{
  int jumps = 0;
  int currentEnd = 0;
  int currentFarthest = 0;
  for (int i = 0; i < (nums_len - 1); i++)
  {
    currentFarthest = fmax(currentFarthest, i + nums[i]);
    if (i == currentEnd)
    {
      jumps++;
      currentEnd = currentFarthest;
    }
  }

  return jumps;
}



int main()
{
  return 0;
}


