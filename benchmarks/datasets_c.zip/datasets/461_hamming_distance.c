#include <stdio.h>
#include <stdlib.h>

int hammingDistance(int x, int y);

int hammingDistance(int x, int y)
{
  int dist = 0;
  int xorResult = x ^ y;
  while (xorResult != 0)
  {
    dist += xorResult & 1;
    xorResult >>= 1;
  }

  return dist;
}



int main()
{
  return 0;
}


