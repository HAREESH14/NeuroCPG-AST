#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int minMoves2(int nums[]);

int minMoves2(int nums[])
{
  sort(nums);
  int mid = nums[strlen(nums) / 2];
  int moves = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    moves += abs(num - mid);
  }

  return moves;
}



int main()
{
  return 0;
}


