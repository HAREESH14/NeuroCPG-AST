#include <stdio.h>
#include <stdlib.h>
/* -- HashMap simulation -- */
#define HASHMAP_SIZE 100
typedef struct { int keys[HASHMAP_SIZE]; int vals[HASHMAP_SIZE]; int count; } HashMap;
HashMap hashmap_create() { HashMap m; m.count=0; return m; }
void hashmap_put(HashMap *m,int k,int v){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k){m->vals[i]=v;return;}m->keys[m->count]=k;m->vals[m->count]=v;m->count++;}
int hashmap_get(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return m->vals[i];return -1;}
int hashmap_contains(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return 1;return 0;}
/* -------------------------*/


int canIWin(int maxChoosableInteger, int desiredTotal);
int canWin(int maxChoosableInteger, int desiredTotal, int state, HashMap memo);

int canIWin(int maxChoosableInteger, int desiredTotal)
{
  if (maxChoosableInteger >= desiredTotal)
  {
    return 1;
  }
  if (((maxChoosableInteger * (maxChoosableInteger + 1)) / 2) < desiredTotal)
  {
    return 0;
  }
  HashMap memo = hashmap_create();
  int state = 0;
  return canWin(maxChoosableInteger, desiredTotal, state, memo);
}



int canWin(int maxChoosableInteger, int desiredTotal, int state, HashMap memo)
{
  if (desiredTotal <= 0)
  {
    return 0;
  }
  if (hashmap_contains(&memo, state))
  {
    return hashmap_get(&memo, state);
  }
  for (int i = 1; i <= maxChoosableInteger; i++)
  {
    int bitCheck = 1 << i;
    if ((state & bitCheck) == 0)
    {
      if (canWin(maxChoosableInteger, desiredTotal - i, state | bitCheck, memo))
      {
        hashmap_put(&memo, state, 1);
        return 1;
      }
    }
  }

  hashmap_put(&memo, state, 0);
  return 0;
}


