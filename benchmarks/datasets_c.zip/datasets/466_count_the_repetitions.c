#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int getMaxRepetitions(char* s1, int n1, char* s2, int n2);

int getMaxRepetitions(char* s1, int n1, char* s2, int n2)
{
  int count1 = 0;
  int count2 = 0;
  int i = 0;
  int j = 0;
  while (count1 < n1)
  {
    if (s1[i] == s2[j])
    {
      j++;
      if (j == strlen(s2))
      {
        j = 0;
        count2++;
      }
    }
    i++;
    if (i == strlen(s1))
    {
      i = 0;
      count1++;
    }
  }

  return count2 / n2;
}



int main()
{
  return 0;
}


