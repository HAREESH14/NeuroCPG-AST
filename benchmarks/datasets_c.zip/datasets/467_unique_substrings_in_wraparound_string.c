#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int findSubstringInWraproundString(char* p);

int findSubstringInWraproundString(char* p)
{
  int cnt[26];
  int length = 0;
  for (int i = 0; i < strlen(p); i++)
  {
    if ((i > 0) && ((p[i] == (p[i - 1] + 1)) || ((p[i - 1] - p[i]) == 25)))
    {
      length++;
    }
    else
    {
      length = 1;
    }
    cnt[p[i] - 'a'] = fmax(cnt[p[i] - 'a'], length);
  }

  int sum = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(cnt) / sizeof(cnt[0])); _fi1++)
  {
    int v = cnt[_fi1];
    sum += v;
  }

  return sum;
}



int main()
{
  return 0;
}


