#include <stdio.h>
#include <stdlib.h>

int rand7();
int rand10();

int rand7()
{
}



int rand10()
{
  int result;
  do
  {
    result = ((rand7() - 1) * 7) + rand7();
  }
  while (result > 40);
  return (result % 10) + 1;
}



int main()
{
  return 0;
}


