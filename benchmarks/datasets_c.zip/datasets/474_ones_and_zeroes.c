#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int findMaxForm(char* strs[], int m, int n);

int findMaxForm(char* strs[], int m, int n)
{
  int dp[m + 1][n + 1];
  for (int _fi1 = 0; _fi1 < (sizeof(strs) / sizeof(strs[0])); _fi1++)
  {
    char* str = strs[_fi1];
    int ones = (int) chars();
    int zeros = strlen(str) - ones;
    for (int i = m; i >= zeros; --i)
    {
      for (int j = n; j >= ones; --j)
      {
        dp[i][j] = fmax(dp[i][j], dp[i - zeros][j - ones] + 1);
      }

    }

  }

  return dp[m][n];
}



int main()
{
  return 0;
}


