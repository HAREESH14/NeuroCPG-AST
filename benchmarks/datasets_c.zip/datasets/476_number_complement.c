#include <stdio.h>
#include <stdlib.h>

int findComplement(int num);

int findComplement(int num)
{
  int bitLength = 0;
  int mask = num;
  while (mask > 0)
  {
    mask >>= 1;
    bitLength++;
  }

  int allOnes = (1 << bitLength) - 1;
  return num ^ allOnes;
}



int main()
{
  return 0;
}


