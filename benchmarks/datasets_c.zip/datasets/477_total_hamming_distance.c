#include <stdio.h>
#include <stdlib.h>

int totalHammingDistance(int nums[], int nums_len);

int totalHammingDistance(int nums[], int nums_len)
{
  int totalDistance = 0;
  int n = nums_len;
  for (int i = 0; i < 32; ++i)
  {
    int bitCount = 0;
    for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
    {
      int num = nums[_fi1];
      bitCount += (num >> i) & 1;
    }

    totalDistance += bitCount * (n - bitCount);
  }

  return totalDistance;
}



int main()
{
  return 0;
}


