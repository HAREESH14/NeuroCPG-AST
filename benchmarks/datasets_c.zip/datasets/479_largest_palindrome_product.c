#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int largestPalindrome(int n);

int largestPalindrome(int n)
{
  if (n == 1)
  {
    return 9;
  }
  int upper_limit = ((int) pow(10, n)) - 1;
  int lower_limit = upper_limit / 10;
  for (int i = upper_limit; i > lower_limit; --i)
  {
    long temp = i;
    long reverse = 0;
    while (temp != 0)
    {
      reverse = (reverse * 10) + (temp % 10);
      temp /= 10;
    }

    long palindrome = (i * ((long) pow(10, n))) + reverse;
    for (long j = upper_limit; j > lower_limit; --j)
    {
      long product = palindrome / j;
      if (((palindrome % j) == 0) && (product <= upper_limit))
      {
        return (int) (palindrome % 1337);
      }
    }

  }

  return 1;
}



int main()
{
  return 0;
}


