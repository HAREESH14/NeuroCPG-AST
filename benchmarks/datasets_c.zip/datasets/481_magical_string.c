#include <stdio.h>
#include <stdlib.h>

int magicalString(int n);

int magicalString(int n)
{
  if (n == 0)
  {
    return 0;
  }
  if (n <= 3)
  {
    return 1;
  }
  int magic[n + 1];
  magic[0] = 1;
  magic[1] = 2;
  magic[2] = 2;
  int count_ones = 1;
  int index = 2;
  int value = 1;
  while (index < n)
  {
    for (int i = 0; (i < magic[index]) && (index < n); i++)
    {
      magic[++index] = value;
      if (value == 1)
      {
        count_ones++;
      }
    }

    value = 3 - value;
  }

  return count_ones;
}



int main()
{
  return 0;
}


