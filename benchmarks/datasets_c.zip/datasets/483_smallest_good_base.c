#include <stdio.h>
#include <stdlib.h>
#include <math.h>

char* smallestGoodBase(char* n);

char* smallestGoodBase(char* n)
{
  long num_n = atol(n);
  for (int m = ((int) (log(num_n) / log(2))) + 1; m >= 1; m--)
  {
    long k = (long) pow((double) num_n, 1.0 / m);
    long sum = 0;
    for (int i = 0; i <= m; i++)
    {
      sum = (sum * k) + 1;
    }

    if (sum == num_n)
    {
      return k;
    }
  }

  return "-1";
}


