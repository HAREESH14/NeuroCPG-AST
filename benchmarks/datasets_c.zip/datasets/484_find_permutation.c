#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int findPermutation(char* s);

int findPermutation(char* s)
{
  int perm[strlen(s) + 1];
  int left = 1;
  for (int i = 0; i < strlen(s); i++)
  {
    if (s[i] == 'I')
    {
      perm[i] = left++;
      while (((i + 1) < strlen(s)) && (s[i + 1] == 'D'))
      {
        i++;
      }

    }
  }

  perm[strlen(s)] = left++;
  for (int i = strlen(s) - 1; i >= 0; i--)
  {
    if (s[i] == 'D')
    {
      perm[i] = left++;
    }
  }

  return perm;
}


