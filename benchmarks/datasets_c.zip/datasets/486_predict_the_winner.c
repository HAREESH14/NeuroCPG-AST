#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int canWin(int nums[], int nums_len);

int canWin(int nums[], int nums_len)
{
  int n = nums_len;
  int dp[n][n];
  for (int i = 0; i < n; i++)
  {
    dp[i][i] = nums[i];
  }

  for (int len = 1; len < n; len++)
  {
    for (int i = 0; i < (n - len); i++)
    {
      int j = i + len;
      dp[i][j] = fmax(nums[i] - dp[i + 1][j], nums[j] - dp[i][j - 1]);
    }

  }

  return dp[0][n - 1] >= 0;
}



int main()
{
  return 0;
}


