#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int findMaxConsecutiveOnes(int nums[], int nums_len);

int findMaxConsecutiveOnes(int nums[], int nums_len)
{
  int maxCount = 0;
  int countZeros = 0;
  int left = 0;
  for (int right = 0; right < nums_len; ++right)
  {
    if (nums[right] == 0)
    {
      countZeros++;
    }
    while (countZeros > 1)
    {
      if (nums[left++] == 0)
      {
        countZeros--;
      }
    }

    maxCount = fmax(maxCount, (right - left) + 1);
  }

  return maxCount;
}



int main()
{
  return 0;
}


