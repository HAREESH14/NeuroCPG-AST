#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int constructRectangle(int area);

int constructRectangle(int area)
{
  int width = (int) sqrt(area);
  while ((area % width) != 0)
  {
    width--;
  }

  int length = area / width;
  return length, width;
}



int main()
{
  return 0;
}


