#include <stdio.h>
#include <stdlib.h>

int reversePairs(int nums[], int nums_len);
int mergeSort(int nums[], int left, int right, int temp[]);
int merge(int nums[], int left, int mid, int right, int temp[]);

int reversePairs(int nums[], int nums_len)
{
  return mergeSort(nums, 0, nums_len - 1, nums_len);
}



int mergeSort(int nums[], int left, int right, int temp[])
{
  if (left >= right)
  {
    return 0;
  }
  int mid = left + ((right - left) / 2);
  int count = mergeSort(nums, left, mid, temp) + mergeSort(nums, mid + 1, right, temp);
  count += merge(nums, left, mid, right, temp);
  return count;
}



int merge(int nums[], int left, int mid, int right, int temp[])
{
  int count = 0;
  arraycopy(nums, left, temp, left, (right - left) + 1);
  int j = mid + 1;
  for (int i = left; i <= mid; i++)
  {
    while ((j <= right) && (((long) nums[i]) > (2 * nums[j])))
    {
      j++;
    }

    count += j - (mid + 1);
  }

  int i = left;
  j = mid + 1;
  int k = left;
  while ((i <= mid) && (j <= right))
  {
    if (temp[i] <= temp[j])
    {
      nums[k++] = temp[i++];
    }
    else
    {
      nums[k++] = temp[j++];
    }
  }

  while (i <= mid)
  {
    nums[k++] = temp[i++];
  }

  while (j <= right)
  {
    nums[k++] = temp[j++];
  }

  return count;
}



int main()
{
  return 0;
}


