#include <stdio.h>
#include <stdlib.h>

int findTargetSumWays(int nums[], int target);

int findTargetSumWays(int nums[], int target)
{
  int sum = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    sum += num;
  }

  if ((sum < target) || (((sum + target) % 2) != 0))
  {
    return 0;
  }
  int target_sum = (sum + target) / 2;
  int dp[target_sum + 1];
  dp[0] = 1;
  for (int _fi2 = 0; _fi2 < (sizeof(nums) / sizeof(nums[0])); _fi2++)
  {
    int num = nums[_fi2];
    for (int j = target_sum; j >= num; j--)
    {
      dp[j] += dp[j - num];
    }

  }

  return dp[target_sum];
}



int main()
{
  return 0;
}


