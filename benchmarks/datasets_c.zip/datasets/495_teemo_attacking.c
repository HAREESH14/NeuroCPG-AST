#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int findPoisonedDuration(int timeSeries[], int timeSeries_len, int duration);

int findPoisonedDuration(int timeSeries[], int timeSeries_len, int duration)
{
  if (timeSeries_len == 0)
  {
    return 0;
  }
  int total = 0;
  for (int i = 1; i < timeSeries_len; ++i)
  {
    total += fmin(timeSeries[i] - timeSeries[i - 1], duration);
  }

  return total + duration;
}



int main()
{
  return 0;
}


