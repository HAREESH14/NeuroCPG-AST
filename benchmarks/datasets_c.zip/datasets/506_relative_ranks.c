#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int findRelativeRanks(int score[], int score_len);

int findRelativeRanks(int score[], int score_len)
{
  int rank_sort[score_len];
  for (int i = 0; i < score_len; ++i)
  {
    rank_sort[i] = i;
  }

  // sort(rank_sort); // Needs manual sort implementation
  int result[score_len];
  for (int i = 0; i < strlen(rank_sort); ++i)
  {
    result[rank_sort[i]] = i + 1;
  }

  return result;
}



int main()
{
  return 0;
}


