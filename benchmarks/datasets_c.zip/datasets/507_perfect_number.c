#include <stdio.h>
#include <stdlib.h>

int checkPerfectNumber(int num);

int checkPerfectNumber(int num)
{
  if (num <= 1)
  {
    return 0;
  }
  int sum = 1;
  for (int i = 2; (i * i) <= num; i++)
  {
    if ((num % i) == 0)
    {
      sum += i;
      if ((i * i) != num)
      {
        sum += num / i;
      }
    }
  }

  return sum == num;
}



int main()
{
  return 0;
}


