#include <stdio.h>
#include <stdlib.h>

int fib(int n);

int fib(int n)
{
  if (n < 2)
  {
    return n;
  }
  int a = 0;
  int b = 1;
  int c;
  for (int i = 2; i <= n; i++)
  {
    c = a + b;
    a = b;
    b = c;
  }

  return b;
}



int main()
{
  return 0;
}


