#include <stdio.h>
#include <stdlib.h>

double myPow(double x, int n);

double myPow(double x, int n)
{
  if (n == 0)
  {
    return 1;
  }
  if (n < 0)
  {
    x = 1 / x;
    n = -n;
  }
  double result = 1;
  double currentProduct = x;
  for (long i = n; i > 0; i /= 2)
  {
    if ((i % 2) == 1)
    {
      result *= currentProduct;
    }
    currentProduct *= currentProduct;
  }

  return result;
}



int main()
{
  return 0;
}


