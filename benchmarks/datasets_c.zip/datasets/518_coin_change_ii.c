#include <stdio.h>
#include <stdlib.h>

int change(int amount, int coins[]);

int change(int amount, int coins[])
{
  int dp[amount + 1];
  dp[0] = 1;
  for (int _fi1 = 0; _fi1 < (sizeof(coins) / sizeof(coins[0])); _fi1++)
  {
    int coin = coins[_fi1];
    for (int i = coin; i <= amount; i++)
    {
      dp[i] += dp[i - coin];
    }

  }

  return dp[amount];
}



int main()
{
  return 0;
}


