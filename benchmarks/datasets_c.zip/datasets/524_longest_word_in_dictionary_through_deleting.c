#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* findLongestWord(char* s, char* dictionary[]);
int isSubsequence(char* s, char* word);

char* findLongestWord(char* s, char* dictionary[])
{
  char* longest = "";
  sort(dictionary);
  for (int _fi1 = 0; _fi1 < (sizeof(dictionary) / sizeof(dictionary[0])); _fi1++)
  {
    char* word = dictionary[_fi1];
    if (isSubsequence(s, word))
    {
      if (strlen(word) > strlen(longest))
      {
        longest = word;
      }
    }
  }

  return longest;
}



int isSubsequence(char* s, char* word)
{
  int i = 0;
  int j = 0;
  while ((i < strlen(s)) && (j < strlen(word)))
  {
    if (s[i] == word[j])
    {
      j++;
    }
    i++;
  }

  return j == strlen(word);
}



int main()
{
  return 0;
}


