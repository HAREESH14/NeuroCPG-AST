#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* -- HashMap simulation -- */
#define HASHMAP_SIZE 100
typedef struct { int keys[HASHMAP_SIZE]; int vals[HASHMAP_SIZE]; int count; } HashMap;
HashMap hashmap_create() { HashMap m; m.count=0; return m; }
void hashmap_put(HashMap *m,int k,int v){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k){m->vals[i]=v;return;}m->keys[m->count]=k;m->vals[m->count]=v;m->count++;}
int hashmap_get(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return m->vals[i];return -1;}
int hashmap_contains(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return 1;return 0;}
/* -------------------------*/


int findMaxLength(int nums[], int nums_len);

int findMaxLength(int nums[], int nums_len)
{
  HashMap counts = hashmap_create();
  hashmap_put(&counts, 0, 1);
  int max_len = 0;
  int count = 0;
  for (int i = 0; i < nums_len; i++)
  {
    count += (nums[i] == 1 ? 1 : 1);
    if (hashmap_contains(&counts, count))
    {
      max_len = fmax(max_len, i - hashmap_get(&counts, count));
    }
    else
    {
      hashmap_put(&counts, count, i);
    }
  }

  return max_len;
}



int main()
{
  return 0;
}


