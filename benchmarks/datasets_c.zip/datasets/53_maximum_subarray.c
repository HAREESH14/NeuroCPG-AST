#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxSubArray(int nums[], int nums_len);

int maxSubArray(int nums[], int nums_len)
{
  int max_sum = nums[0];
  int current_sum = max_sum;
  for (int i = 1; i < nums_len; i++)
  {
    current_sum = fmax(current_sum + nums[i], nums[i]);
    max_sum = fmax(max_sum, current_sum);
  }

  return max_sum;
}



int main()
{
  return 0;
}


