#include <stdio.h>
#include <stdlib.h>

int singleNonDuplicate(int nums[], int nums_len);

int singleNonDuplicate(int nums[], int nums_len)
{
  int low = 0;
  int high = nums_len - 1;
  while (low < high)
  {
    int mid = low + ((high - low) / 2);
    if ((mid % 2) == 1)
    {
      mid--;
    }
    if (nums[mid] == nums[mid + 1])
    {
      low = mid + 2;
    }
    else
    {
      high = mid;
    }
  }

  return nums[low];
}



int main()
{
  return 0;
}


