#include <stdio.h>
#include <stdlib.h>

int find_triplet_equal_sum(int nums[], int nums_len);

int find_triplet_equal_sum(int nums[], int nums_len)
{
  int n = nums_len;
  int prefix_sum[n + 1];
  for (int i = 0; i < n; ++i)
  {
    prefix_sum[i + 1] = prefix_sum[i] + nums[i];
  }

  for (int i = 1; (i + 2) < n; ++i)
  {
    for (int j = i + 2; (j + 1) < n; ++j)
    {
      for (int k = j + 2; k < n; ++k)
      {
        int s1 = prefix_sum[i];
        int s2 = prefix_sum[j] - prefix_sum[i + 1];
        int s3 = prefix_sum[k] - prefix_sum[j + 1];
        int s4 = prefix_sum[n] - prefix_sum[k + 1];
        if (((s1 == s2) && (s2 == s3)) && (s3 == s4))
        {
          return 1;
        }
      }

    }

  }

  return 0;
}



int main()
{
  return 0;
}


