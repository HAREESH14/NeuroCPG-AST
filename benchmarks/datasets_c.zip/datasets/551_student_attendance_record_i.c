#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int checkRecord(char* s);

int checkRecord(char* s)
{
  int late = 0;
  int absent = 0;
  for (int i = 0; i < strlen(s); i++)
  {
    if (s[i] == 'A')
    {
      absent++;
      late = 0;
    }
    else
      if (s[i] == 'L')
    {
      late++;
    }
    else
    {
      late = 0;
    }
    if ((absent >= 2) || (late >= 3))
    {
      return 0;
    }
  }

  return 1;
}



int main()
{
  return 0;
}


