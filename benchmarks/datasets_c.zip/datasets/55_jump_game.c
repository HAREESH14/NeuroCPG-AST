#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int canJump(int nums[], int nums_len);

int canJump(int nums[], int nums_len)
{
  int maxReach = 0;
  for (int i = 0; i < nums_len; ++i)
  {
    if (i > maxReach)
    {
      return 0;
    }
    maxReach = fmax(maxReach, i + nums[i]);
  }

  return 1;
}



int main()
{
  return 0;
}


