#include <stdio.h>
#include <stdlib.h>

int arrayPairSum(int nums[], int nums_len);

int arrayPairSum(int nums[], int nums_len)
{
  sort(nums);
  int sum = 0;
  for (int i = 0; i < nums_len; i += 2)
  {
    sum += nums[i];
  }

  return sum;
}



int main()
{
  return 0;
}


