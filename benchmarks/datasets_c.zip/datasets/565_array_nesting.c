#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int arrayNesting(int nums[], int nums_len);

int arrayNesting(int nums[], int nums_len)
{
  int n = nums_len;
  int max_len = 0;
  for (int i = 0; i < n; ++i)
  {
    if (nums[i] != 1)
    {
      int start = nums[i];
      int count = 0;
      while (nums[start] != 1)
      {
        int temp = start;
        start = nums[start];
        count++;
        nums[temp] = 1;
      }

      max_len = fmax(max_len, count);
    }
  }

  return max_len;
}



int main()
{
  return 0;
}


