#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int lengthOfLastWord(char* s);

int lengthOfLastWord(char* s)
{
  int length = 0;
  int tail = strlen(s) - 1;
  while ((tail >= 0) && (s[tail] == ' '))
  {
    tail--;
  }

  while ((tail >= 0) && (s[tail] != ' '))
  {
    length++;
    tail--;
  }

  return length;
}



int main()
{
  return 0;
}


