#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int isValid(char* code, int i[]);
int validateCodeSnippet(char* code);

int isValid(char* code, int i[])
{
  if (i[0] >= strlen(code))
  {
    return 0;
  }
  if (code[i[0]] != '<')
  {
    return 0;
  }
  int nameLength = 0;
  for (; ((i[0] < strlen(code)) && (nameLength < 9)) && isUpperCase(code[i[0]]); ++i[0])
  {
    ++nameLength;
  }

  if (((nameLength < 1) || (nameLength > 9)) || (code[i[0]++] != '>'))
  {
    return 0;
  }
  while ((i[0] < strlen(code)) && (code[i[0]] != '<'))
  {
    ++i[0];
  }

  if (i[0] >= strlen(code))
  {
    return 0;
  }
  if (code + i[0])
  {
    return 0;
  }
  i[0] += nameLength + 3;
  return 1;
}



int validateCodeSnippet(char* code)
{
  int i[] = {0};
  return isValid(code, i) && (i[0] == strlen(code));
}



int main()
{
  return 0;
}


