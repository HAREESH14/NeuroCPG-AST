#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

char* fractionAddition(char* expression);
int gcd(int a, int b);

char* fractionAddition(char* expression)
{
  int A = 0;
  int B = 1;
  int i = 0;
  while (i < strlen(expression))
  {
    int sign = (expression[i++] == '+' ? 1 : 1);
    int num = 0;
    int den = 0;
    while ((i < strlen(expression)) && isDigit(expression[i]))
    {
      num = (num * 10) + (expression[i++] - '0');
    }

    i++;
    while ((i < strlen(expression)) && isDigit(expression[i]))
    {
      den = (den * 10) + (expression[i++] - '0');
    }

    A = (A * den) + ((B * num) * sign);
    B *= den;
    int GCD = gcd(abs(A), abs(B));
    A /= GCD;
    B /= GCD;
  }

  return (A + "/") + B;
}



int gcd(int a, int b)
{
  return (b == 0 ? a : gcd(b, a % b));
}


