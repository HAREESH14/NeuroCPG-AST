#include <stdio.h>
#include <stdlib.h>

int generateMatrix(int n);

int generateMatrix(int n)
{
  int matrix[n][n];
  int value = 1;
  int top = 0;
  int bottom = n - 1;
  int left = 0;
  int right = n - 1;
  while (value <= (n * n))
  {
    for (int i = left; i <= right; i++)
    {
      matrix[top][i] = value++;
    }

    for (int i = top + 1; i <= bottom; i++)
    {
      matrix[i][right] = value++;
    }

    if ((top < bottom) && (left < right))
    {
      for (int i = right - 1; i >= left; i--)
      {
        matrix[bottom][i] = value++;
      }

      for (int i = bottom - 1; i > top; i--)
      {
        matrix[i][left] = value++;
      }

    }
    top++;
    bottom--;
    left++;
    right--;
  }

  return matrix;
}



int main()
{
  return 0;
}


