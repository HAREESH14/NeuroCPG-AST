#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* longestPalindromicSubstring(char* s);

char* longestPalindromicSubstring(char* s)
{
  int n = strlen(s);
  if (n == 0)
  {
    return "";
  }
  int start = 0;
  int maxLength = 1;
  for (int i = 0; i < n; ++i)
  {
    int l = i;
    int r = i;
    while ((r < (n - 1)) && (s[r] == s[r + 1]))
    {
      r++;
    }

    i = r;
    while (((l > 0) && (r < (n - 1))) && (s[l - 1] == s[r + 1]))
    {
      l--;
      r++;
    }

    int length = (r - l) + 1;
    if (length > maxLength)
    {
      start = l;
      maxLength = length;
    }
  }

  return s + start;
}



int main()
{
  return 0;
}


