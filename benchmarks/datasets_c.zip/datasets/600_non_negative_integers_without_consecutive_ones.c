#include <stdio.h>
#include <stdlib.h>

int findIntegers(int n);

int findIntegers(int n)
{
  int dp[32][2];
  dp[0][0] = 1;
  dp[0][1] = 1;
  for (int i = 1; i < 32; i++)
  {
    dp[i][0] = dp[i - 1][0] + dp[i - 1][1];
    dp[i][1] = dp[i - 1][0];
  }

  int ans = 0;
  int prev_bit = 0;
  for (int i = 30; i >= 0; i--)
  {
    if ((n & (1 << i)) != 0)
    {
      ans += dp[i][0];
      if (prev_bit == 1)
      {
        break;
      }
      prev_bit = 1;
    }
    else
    {
      prev_bit = 0;
    }
  }

  return ans + 1;
}



int main()
{
  return 0;
}


