#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* s;
int i;
int count;
char ch;

char next();
int hasNext();

char next()
{
  if (hasNext())
  {
    return ' ';
  }
  if (count == 0)
  {
    ch = s[i++];
    while ((i < strlen(s)) && isDigit(s[i]))
    {
      count = (count * 10) + (s[i++] - '0');
    }

  }
  count--;
  return ch;
}



int hasNext()
{
  return (i < strlen(s)) || (count != 0);
}


