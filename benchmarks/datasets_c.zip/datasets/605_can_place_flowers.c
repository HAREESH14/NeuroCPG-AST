#include <stdio.h>
#include <stdlib.h>

int canPlaceFlowers(int flowerbed[], int flowerbed_len, int n);

int canPlaceFlowers(int flowerbed[], int flowerbed_len, int n)
{
  int count = 0;
  for (int i = 0; i < flowerbed_len; i++)
  {
    if (((flowerbed[i] == 0) && ((i == 0) || (flowerbed[i - 1] == 0))) && ((i == (flowerbed_len - 1)) || (flowerbed[i + 1] == 0)))
    {
      flowerbed[i] = 1;
      count++;
    }
    if (count >= n)
    {
      return 1;
    }
  }

  return count >= n;
}



int main()
{
  return 0;
}


