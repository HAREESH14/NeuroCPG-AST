#include <stdio.h>
#include <stdlib.h>

int triangleNumber(int nums[], int nums_len);

int triangleNumber(int nums[], int nums_len)
{
  sort(nums);
  int count = 0;
  for (int i = 0; i < nums_len; ++i)
  {
    for (int j = i + 1; j < nums_len; ++j)
    {
      for (int k = j + 1; k < nums_len; ++k)
      {
        if ((nums[i] + nums[j]) > nums[k])
        {
          count++;
        }
        else
        {
          break;
        }
      }

    }

  }

  return count;
}



int main()
{
  return 0;
}


