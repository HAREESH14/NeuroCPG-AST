#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maximumProduct(int nums[], int nums_len);

int maximumProduct(int nums[], int nums_len)
{
  sort(nums);
  int n = nums_len;
  return fmax((nums[0] * nums[1]) * nums[n - 1], (nums[n - 1] * nums[n - 2]) * nums[n - 3]);
}



int main()
{
  return 0;
}


