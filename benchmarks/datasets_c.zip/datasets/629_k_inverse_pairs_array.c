#include <stdio.h>
#include <stdlib.h>

int kInversePairs(int n, int k);

int kInversePairs(int n, int k)
{
  int mod = 1000000007;
  int dp[n + 1][k + 1];
  for (int i = 1; i <= n; i++)
  {
    dp[i][0] = 1;
    for (int j = 1; j <= k; j++)
    {
      dp[i][j] = (dp[i][j - 1] + dp[i - 1][j]) % mod;
      if ((j - i) >= 0)
      {
        dp[i][j] = ((dp[i][j] - dp[i - 1][j - i]) + mod) % mod;
      }
    }

  }

  return dp[n][k];
}



int main()
{
  return 0;
}


