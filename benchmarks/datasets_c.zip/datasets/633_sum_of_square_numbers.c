#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int judgeSquareSum(int c);

int judgeSquareSum(int c)
{
  for (int a = 0; a <= sqrt(c); ++a)
  {
    int b = (int) sqrt(c - (a * a));
    if (((a * a) + (b * b)) == c)
    {
      return 1;
    }
  }

  return 0;
}


