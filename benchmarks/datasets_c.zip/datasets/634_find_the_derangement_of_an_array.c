#include <stdio.h>
#include <stdlib.h>

int findDerangement(int n);

int findDerangement(int n)
{
  const int MOD = 1000000007;
  long dp[n + 1];
  dp[2] = 1;
  for (int i = 3; i <= n; ++i)
  {
    dp[i] = ((i - 1) * (dp[i - 1] + dp[i - 2])) % MOD;
  }

  return (int) dp[n];
}



int main()
{
  return 0;
}


