#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double findMaxAverage(int nums[], int nums_len, int k);

double findMaxAverage(int nums[], int nums_len, int k)
{
  int n = nums_len;
  double sum = 0;
  for (int i = 0; i < k; i++)
  {
    sum += nums[i];
  }

  double max_avg = sum / k;
  for (int i = k; i < n; i++)
  {
    sum = (sum - nums[i - k]) + nums[i];
    max_avg = fmax(max_avg, sum / k);
  }

  return max_avg;
}



int main()
{
  return 0;
}


