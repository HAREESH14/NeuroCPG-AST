#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double findMaxAverage(int nums[], int nums_len, int k);

double findMaxAverage(int nums[], int nums_len, int k)
{
  long sum = 0;
  for (int i = 0; i < k; i++)
  {
    sum += nums[i];
  }

  double max_avg = ((double) sum) / k;
  for (int i = k; i < nums_len; i++)
  {
    sum += nums[i] - nums[i - k];
    max_avg = fmax(max_avg, ((double) sum) / k);
  }

  return max_avg;
}



int main()
{
  return 0;
}


