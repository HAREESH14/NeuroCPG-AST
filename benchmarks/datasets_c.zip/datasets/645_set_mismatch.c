#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int findErrorNums(int nums[], int nums_len);

int findErrorNums(int nums[], int nums_len)
{
  int result[2];
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    int index = abs(num) - 1;
    if (nums[index] > 0)
    {
      nums[index] = -nums[index];
    }
    else
    {
      result[0] = index + 1;
    }
  }

  for (int i = 0; i < nums_len; i++)
  {
    if (nums[i] > 0)
    {
      result[1] = i + 1;
      break;
    }
  }

  return result;
}



int main()
{
  return 0;
}


