#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int countSubstrings(char* s);

int countSubstrings(char* s)
{
  int n = strlen(s);
  int count = 0;
  for (int center = 0; center < ((2 * n) - 1); ++center)
  {
    int left = center / 2;
    int right = left + (center % 2);
    while (((left >= 0) && (right < n)) && (s[left] == s[right]))
    {
      ++count;
      --left;
      ++right;
    }

  }

  return count;
}



int main()
{
  return 0;
}


