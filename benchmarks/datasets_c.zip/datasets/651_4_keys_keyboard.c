#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxA(int n);

int maxA(int n)
{
  int dp[n + 1];
  for (int i = 1; i <= n; ++i)
  {
    dp[i] = i;
    for (int j = 1; j <= (i - 3); ++j)
    {
      dp[i] = fmax(dp[i], dp[j] * ((i - j) - 1));
    }

  }

  return dp[n];
}



int main()
{
  return 0;
}


