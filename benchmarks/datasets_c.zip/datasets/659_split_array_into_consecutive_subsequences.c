#include <stdio.h>
#include <stdlib.h>

int canSplit(int nums[]);

int canSplit(int nums[])
{
  int freq[20001];
  int needed[20001];
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int n = nums[_fi1];
    freq[n]++;
  }

  for (int _fi2 = 0; _fi2 < (sizeof(nums) / sizeof(nums[0])); _fi2++)
  {
    int n = nums[_fi2];
    if (freq[n] == 0)
    {
      continue;
    }
    if (needed[n - 1] == 0)
    {
      if ((freq[n + 1] > 0) && (freq[n + 2] > 0))
      {
        freq[n]--;
        freq[n + 1]--;
        freq[n + 2]--;
        needed[n + 2]++;
      }
      else
      {
        return 0;
      }
    }
    else
    {
      freq[n]--;
      needed[n - 1]--;
      needed[n]++;
    }
  }

  return 1;
}



int main()
{
  return 0;
}


