#include <stdio.h>
#include <stdlib.h>

int isNumber(char* s);

int isNumber(char* s)
{
  char* pattern = "^[-+]?(([0-9]+(\\.[0-9]*)?)|(\\.[0-9]+))(e[-+]?[0-9]+)?$";
  return matches(pattern, s);
}


