#include <stdio.h>
#include <stdlib.h>

int newInteger(int n);

int newInteger(int n)
{
  int result = 0;
  int base = 1;
  while (n > 0)
  {
    result += (n % 9) * base;
    n /= 9;
    base *= 10;
  }

  return result;
}



int main()
{
  return 0;
}


