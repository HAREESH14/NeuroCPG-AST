#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int strangePrinter(char* s);

int strangePrinter(char* s)
{
  int n = strlen(s);
  if (n == 0)
  {
    return 0;
  }
  int dp[n][n];
  for (int i = 0; i < n; i++)
  {
    dp[i][i] = 1;
  }

  for (int len = 1; len < n; len++)
  {
    for (int i = 0; i < (n - len); i++)
    {
      int j = i + len;
      dp[i][j] = dp[i + 1][j] + 1;
      for (int k = i + 1; k <= j; k++)
      {
        if (s[i] == s[k])
        {
          dp[i][j] = fmin(dp[i][j], dp[i + 1][k - 1] + dp[k][j]);
        }
      }

    }

  }

  return dp[0][n - 1];
}



int main()
{
  return 0;
}


