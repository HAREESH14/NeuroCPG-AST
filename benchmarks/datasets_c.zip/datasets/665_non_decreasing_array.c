#include <stdio.h>
#include <stdlib.h>

int checkPossibility(int nums[], int nums_len);

int checkPossibility(int nums[], int nums_len)
{
  int cnt = 0;
  for (int i = 1; i < nums_len; i++)
  {
    if (nums[i] < nums[i - 1])
    {
      cnt++;
      if ((i == 1) || (nums[i] >= nums[i - 2]))
      {
        nums[i - 1] = nums[i];
      }
      else
      {
        nums[i] = nums[i - 1];
      }
      if (cnt > 1)
      {
        return 0;
      }
    }
  }

  return 1;
}



int main()
{
  return 0;
}


