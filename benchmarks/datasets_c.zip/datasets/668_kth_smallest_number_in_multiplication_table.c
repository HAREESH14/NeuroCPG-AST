#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int findKthNumber(int m, int n, int k);

int findKthNumber(int m, int n, int k)
{
  int low = 1;
  int high = m * n;
  while (low < high)
  {
    int mid = low + ((high - low) / 2);
    int count = 0;
    for (int i = 1; i <= m; i++)
    {
      count += fmin(mid / i, n);
    }

    if (count < k)
    {
      low = mid + 1;
    }
    else
    {
      high = mid;
    }
  }

  return low;
}



int main()
{
  return 0;
}


