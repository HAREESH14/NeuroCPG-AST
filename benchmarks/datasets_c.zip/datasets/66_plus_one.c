#include <stdio.h>
#include <stdlib.h>

int plusOne(int digits[], int digits_len);

int plusOne(int digits[], int digits_len)
{
  int n = digits_len;
  for (int i = n - 1; i >= 0; i--)
  {
    if (digits[i] < 9)
    {
      digits[i]++;
      return digits;
    }
    digits[i] = 0;
  }

  int newDigits[n + 1];
  newDigits[0] = 1;
  return newDigits;
}



int main()
{
  return 0;
}


