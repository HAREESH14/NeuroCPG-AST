#include <stdio.h>
#include <stdlib.h>

int findNumberOfLIS(int nums[], int nums_len);

int findNumberOfLIS(int nums[], int nums_len)
{
  int n = nums_len;
  int maxLength = 0;
  int ans = 0;
  int length[n];
  int count[n];
  for (int i = 0; i < n; ++i)
  {
    length[i] = (count[i] = 1);
    for (int j = 0; j < i; ++j)
    {
      if (nums[i] > nums[j])
      {
        if (length[i] == (length[j] + 1))
        {
          count[i] += count[j];
        }
        else
          if (length[i] < (length[j] + 1))
        {
          length[i] = length[j] + 1;
          count[i] = count[j];
        }
      }
    }

    if (maxLength == length[i])
    {
      ans += count[i];
    }
    else
      if (maxLength < length[i])
    {
      maxLength = length[i];
      ans = count[i];
    }
  }

  return ans;
}



int main()
{
  return 0;
}


