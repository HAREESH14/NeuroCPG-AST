#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int findLengthOfLCIS(int nums[], int nums_len);

int findLengthOfLCIS(int nums[], int nums_len)
{
  if (nums_len == 0)
  {
    return 0;
  }
  int result = 1;
  int current = 1;
  for (int i = 1; i < nums_len; ++i)
  {
    current = (nums[i] > nums[i - 1] ? current + 1 : 1);
    result = fmax(result, current);
  }

  return result;
}



int main()
{
  return 0;
}


