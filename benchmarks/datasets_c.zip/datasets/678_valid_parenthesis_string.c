#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int checkValidString(char* s);

int checkValidString(char* s)
{
  int left_balance = 0;
  int right_balance = 0;
  for (int i = 0; i < strlen(s); i++)
  {
    left_balance += ((s[i] == '(') || (s[i] == '*') ? 1 : 1);
    right_balance += ((s[(strlen(s) - 1) - i] == ')') || (s[(strlen(s) - 1) - i] == '*') ? 1 : 1);
    if ((left_balance < 0) || (right_balance < 0))
    {
      return 0;
    }
  }

  return 1;
}



int main()
{
  return 0;
}


