#include <stdio.h>
#include <stdlib.h>

int hasAlternatingBits(int n);

int hasAlternatingBits(int n)
{
  int prevBit = n % 2;
  n /= 2;
  while (n > 0)
  {
    int currBit = n % 2;
    if (currBit == prevBit)
    {
      return 0;
    }
    prevBit = currBit;
    n /= 2;
  }

  return 1;
}



int main()
{
  return 0;
}


