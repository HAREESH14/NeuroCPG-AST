#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int countBinarySubstrings(char* s);

int countBinarySubstrings(char* s)
{
  int prev = 0;
  int curr = 1;
  int result = 0;
  for (int i = 1; i < strlen(s); i++)
  {
    if (s[i] == s[i - 1])
    {
      curr++;
    }
    else
    {
      result += fmin(prev, curr);
      prev = curr;
      curr = 1;
    }
  }

  return result + fmin(prev, curr);
}



int main()
{
  return 0;
}


