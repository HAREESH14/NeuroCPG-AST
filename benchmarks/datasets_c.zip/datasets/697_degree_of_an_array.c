#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* -- HashMap simulation -- */
#define HASHMAP_SIZE 100
typedef struct { int keys[HASHMAP_SIZE]; int vals[HASHMAP_SIZE]; int count; } HashMap;
HashMap hashmap_create() { HashMap m; m.count=0; return m; }
void hashmap_put(HashMap *m,int k,int v){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k){m->vals[i]=v;return;}m->keys[m->count]=k;m->vals[m->count]=v;m->count++;}
int hashmap_get(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return m->vals[i];return -1;}
int hashmap_contains(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return 1;return 0;}
/* -------------------------*/


int findShortestSubArray(int nums[], int nums_len);

int findShortestSubArray(int nums[], int nums_len)
{
  HashMap freq_map = hashmap_create();
  HashMap start_map = hashmap_create();
  int max_freq = 0;
  int min_length = nums_len;
  for (int i = 0; i < nums_len; ++i)
  {
    if (hashmap_contains(&start_map, nums[i]))
    {
      hashmap_put(&start_map, nums[i], i);
    }
    hashmap_put(&freq_map, nums[i], getOrDefault(nums[i], 0) + 1);
    int freq = hashmap_get(&freq_map, nums[i]);
    if (freq > max_freq)
    {
      max_freq = freq;
      min_length = (i - hashmap_get(&start_map, nums[i])) + 1;
    }
    else
      if (freq == max_freq)
    {
      min_length = fmin(min_length, (i - hashmap_get(&start_map, nums[i])) + 1);
    }
  }

  return min_length;
}


