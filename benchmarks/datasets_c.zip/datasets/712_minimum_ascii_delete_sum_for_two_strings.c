#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int minimumDeleteSum(char* s1, char* s2);

int minimumDeleteSum(char* s1, char* s2)
{
  int dp[strlen(s1) + 1][strlen(s2) + 1];
  for (int i = 1; i <= strlen(s1); i++)
  {
    dp[i][0] = dp[i - 1][0] + s1[i - 1];
  }

  for (int j = 1; j <= strlen(s2); j++)
  {
    dp[0][j] = dp[0][j - 1] + s2[j - 1];
  }

  for (int i = 1; i <= strlen(s1); i++)
  {
    for (int j = 1; j <= strlen(s2); j++)
    {
      if (s1[i - 1] == s2[j - 1])
      {
        dp[i][j] = dp[i - 1][j - 1];
      }
      else
      {
        dp[i][j] = fmin(dp[i - 1][j] + s1[i - 1], dp[i][j - 1] + s2[j - 1]);
      }
    }

  }

  return dp[strlen(s1)][strlen(s2)];
}



int main()
{
  return 0;
}


