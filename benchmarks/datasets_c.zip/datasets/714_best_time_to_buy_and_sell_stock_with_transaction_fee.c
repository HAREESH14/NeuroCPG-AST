#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxProfit(int prices[], int fee);

int maxProfit(int prices[], int fee)
{
  int cash = 0;
  int hold = -prices[0];
  for (int _fi1 = 0; _fi1 < (sizeof(prices) / sizeof(prices[0])); _fi1++)
  {
    int price = prices[_fi1];
    int temp = cash;
    cash = fmax(cash, (hold + price) - fee);
    hold = fmax(hold, temp - price);
  }

  return cash;
}



int main()
{
  return 0;
}


