#include <stdio.h>
#include <stdlib.h>

int isOneBitCharacter(int bits[], int bits_len);

int isOneBitCharacter(int bits[], int bits_len)
{
  int i;
  for (i = 0; i < (bits_len - 1); i++)
  {
    i += bits[i];
  }

  return i == (bits_len - 1);
}



int main()
{
  return 0;
}


