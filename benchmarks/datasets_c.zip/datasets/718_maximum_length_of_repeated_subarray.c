#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int findLength(int nums1[], int nums1_len, int nums2[], int nums2_len);

int findLength(int nums1[], int nums1_len, int nums2[], int nums2_len)
{
  int m = nums1_len;
  int n = nums2_len;
  int dp[m + 1][n + 1];
  int maxLength = 0;
  for (int i = m - 1; i >= 0; i--)
  {
    for (int j = n - 1; j >= 0; j--)
    {
      if (nums1[i] == nums2[j])
      {
        dp[i][j] = dp[i + 1][j + 1] + 1;
        maxLength = fmax(maxLength, dp[i][j]);
      }
    }

  }

  return maxLength;
}



int main()
{
  return 0;
}


