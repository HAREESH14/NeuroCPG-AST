#include <stdio.h>
#include <stdlib.h>

int pivotIndex(int nums[], int nums_len);

int pivotIndex(int nums[], int nums_len)
{
  int total_sum = 0;
  int left_sum = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    total_sum += num;
  }

  for (int i = 0; i < nums_len; ++i)
  {
    if (left_sum == ((total_sum - left_sum) - nums[i]))
    {
      return i;
    }
    left_sum += nums[i];
  }

  return 1;
}



int main()
{
  return 0;
}


