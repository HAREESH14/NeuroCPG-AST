#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* minWindowSubSequence(char* s1, char* s2);

char* minWindowSubSequence(char* s1, char* s2)
{
  int m = strlen(s1);
  int n = strlen(s2);
  int dp[n + 1][m + 1];
  for (int j = 0; j <= m; ++j)
  {
    dp[0][j] = j;
  }

  for (int i = 1; i <= n; ++i)
  {
    for (int j = 1; j <= m; ++j)
    {
      if (s1[j - 1] == s2[i - 1])
      {
        dp[i][j] = dp[i - 1][j - 1];
      }
      else
      {
        dp[i][j] = dp[i][j - 1];
      }
    }

  }

  int start = 0;
  int length = m + 1;
  for (int j = 1; j <= m; ++j)
  {
    if ((dp[n][j] != 0) && ((j - dp[n][j]) < length))
    {
      start = dp[n][j];
      length = j - start;
    }
  }

  return (length == (m + 1) ? "" : s1 + start);
}



int main()
{
  return 0;
}


