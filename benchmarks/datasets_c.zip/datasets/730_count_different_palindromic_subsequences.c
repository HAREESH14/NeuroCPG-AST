#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int countPalindromicSubsequences(char* S);

int countPalindromicSubsequences(char* S)
{
  int n = strlen(S);
  int mod = 1000000007;
  int dp[4][n + 1];
  for (int i = n - 1; i >= 0; i--)
  {
    for (int j = i + 1; j <= n; j++)
    {
      int c = S[i] - 'a';
      dp[c][j] = ((((dp[0][j - 1] + dp[1][j - 1]) + dp[2][j - 1]) + dp[3][j - 1]) - dp[c][i]) + 2;
      if (dp[c][j] < 0)
      {
        dp[c][j] += mod;
      }
    }

  }

  return (((dp[0][n] + dp[1][n]) + dp[2][n]) + dp[3][n]) % mod;
}



int main()
{
  return 0;
}


