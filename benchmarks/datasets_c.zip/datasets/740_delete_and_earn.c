#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxPoints(int nums[]);

int maxPoints(int nums[])
{
  int dp[100001];
  int max_points = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    dp[num]++;
  }

  for (int i = 2; i < 100001; i++)
  {
    dp[i] = fmax(dp[i - 1], dp[i - 2] + (i * dp[i]));
    max_points = fmax(max_points, dp[i]);
  }

  return max_points;
}



int main()
{
  return 0;
}


