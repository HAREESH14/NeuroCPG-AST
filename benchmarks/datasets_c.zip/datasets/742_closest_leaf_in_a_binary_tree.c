#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* toLowerCase(char* s);

char* toLowerCase(char* s)
{
  return strlwr(s);
}



int main()
{
  return 0;
}


