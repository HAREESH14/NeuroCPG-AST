#include <stdio.h>
#include <stdlib.h>

char nextGreatestLetter(char letters[], char target);

char nextGreatestLetter(char letters[], char target)
{
  for (int _fi1 = 0; _fi1 < (sizeof(letters) / sizeof(letters[0])); _fi1++)
  {
    char letter = letters[_fi1];
    if (letter > target)
    {
      return letter;
    }
  }

  return letters[0];
}



int main()
{
  return 0;
}


