#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int reachNumber(int target);

int reachNumber(int target)
{
  target = abs(target);
  int step = 0;
  int sum = 0;
  while (sum < target)
  {
    step++;
    sum += step;
  }

  while (((sum - target) % 2) != 0)
  {
    step++;
    sum += step;
  }

  return step;
}



int main()
{
  return 0;
}


