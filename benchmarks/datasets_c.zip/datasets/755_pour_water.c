#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minMoves(int target);

int minMoves(int target)
{
  target = abs(target);
  int step = 0;
  int sum = 0;
  while ((sum < target) || (((sum - target) % 2) != 0))
  {
    step++;
    sum += step;
  }

  return step;
}



int main()
{
  return 0;
}


