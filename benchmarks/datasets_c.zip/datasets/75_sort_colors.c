#include <stdio.h>
#include <stdlib.h>

void sortColors(int nums[], int nums_len);

void sortColors(int nums[], int nums_len)
{
  int red = 0;
  int white = 0;
  int blue = nums_len - 1;
  while (white <= blue)
  {
    if (nums[white] == 0)
    {
      int temp = nums[red];
      nums[red++] = nums[white];
      nums[white++] = temp;
    }
    else
      if (nums[white] == 1)
    {
      white++;
    }
    else
    {
      int temp = nums[white];
      nums[white] = nums[blue];
      nums[blue--] = temp;
    }
  }

}



int main()
{
  return 0;
}


