#include <stdio.h>
#include <stdlib.h>
/* -- HashMap simulation -- */
#define HASHMAP_SIZE 100
typedef struct { int keys[HASHMAP_SIZE]; int vals[HASHMAP_SIZE]; int count; } HashMap;
HashMap hashmap_create() { HashMap m; m.count=0; return m; }
void hashmap_put(HashMap *m,int k,int v){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k){m->vals[i]=v;return;}m->keys[m->count]=k;m->vals[m->count]=v;m->count++;}
int hashmap_get(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return m->vals[i];return -1;}
int hashmap_contains(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return 1;return 0;}
/* -------------------------*/


int anagramMappings(int nums1[], int nums1_len, int nums2[], int nums2_len);

int anagramMappings(int nums1[], int nums1_len, int nums2[], int nums2_len)
{
  HashMap num_map = hashmap_create();
  for (int i = 0; i < nums2_len; i++)
  {
    hashmap_put(&num_map, nums2[i], i);
  }

  int mapping[nums1_len];
  for (int i = 0; i < nums1_len; i++)
  {
    mapping[i] = hashmap_get(&num_map, nums1[i]);
  }

  return mapping;
}



int main()
{
  return 0;
}


