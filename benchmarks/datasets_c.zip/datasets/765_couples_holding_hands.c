#include <stdio.h>
#include <stdlib.h>

int minSwapsCouples(int row[], int row_len);

int minSwapsCouples(int row[], int row_len)
{
  int n = row_len;
  int position[n];
  for (int i = 0; i < n; ++i)
  {
    position[row[i]] = i;
  }

  int swaps = 0;
  for (int i = 0; i < n; i += 2)
  {
    int partner = ((row[i] % 2) == 0 ? row[i] + 1 : row[i] - 1);
    if (row[i + 1] != partner)
    {
      int temp = row[position[partner]];
      row[position[partner]] = row[i + 1];
      row[i + 1] = temp;
      temp = position[row[i + 1]];
      position[row[i + 1]] = position[partner];
      position[partner] = temp;
      swaps++;
    }
  }

  return swaps;
}



int main()
{
  return 0;
}


