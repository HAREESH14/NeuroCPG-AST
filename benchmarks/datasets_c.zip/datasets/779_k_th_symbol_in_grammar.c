#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxChunksToSorted(int arr[], int arr_len);

int maxChunksToSorted(int arr[], int arr_len)
{
  int max_val = 0;
  int chunks = 0;
  for (int i = 0; i < arr_len; i++)
  {
    max_val = fmax(max_val, arr[i]);
    if (max_val == i)
    {
      chunks++;
    }
  }

  return chunks;
}



int main()
{
  return 0;
}


