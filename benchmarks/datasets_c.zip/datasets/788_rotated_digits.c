#include <stdio.h>
#include <stdlib.h>

int rotatedDigits(int n);
int isGood(int num);

int rotatedDigits(int n)
{
  int count = 0;
  for (int i = 1; i <= n; i++)
  {
    if (isGood(i))
    {
      count++;
    }
  }

  return count;
}



int isGood(int num)
{
  int changed = 0;
  while (num != 0)
  {
    int digit = num % 10;
    if (((digit == 3) || (digit == 4)) || (digit == 7))
    {
      return 0;
    }
    if ((((digit == 2) || (digit == 5)) || (digit == 6)) || (digit == 9))
    {
      changed = 1;
    }
    num /= 10;
  }

  return changed;
}



int main()
{
  return 0;
}


