#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int isIdealPermutation(int nums[], int nums_len);

int isIdealPermutation(int nums[], int nums_len)
{
  for (int i = 0; i < nums_len; ++i)
  {
    if (abs(nums[i] - i) > 1)
    {
      return 0;
    }
  }

  return 1;
}



int main()
{
  return 0;
}


