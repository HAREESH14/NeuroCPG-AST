#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int canTransform(char* start, char* end);

int canTransform(char* start, char* end)
{
  if (strlen(start) != strlen(end))
  {
    return 0;
  }
  int i = 0;
  int j = 0;
  int n = strlen(start);
  while ((i < n) && (j < n))
  {
    while ((i < n) && (start[i] == 'X'))
    {
      i++;
    }

    while ((j < n) && (end[j] == 'X'))
    {
      j++;
    }

    if (start[i] != end[j])
    {
      return 0;
    }
    if (((start[i] == 'R') && (i > j)) || ((start[i] == 'L') && (i < j)))
    {
      return 0;
    }
    i++;
    j++;
  }

  return 1;
}



int main()
{
  return 0;
}


