#include <stdio.h>
#include <stdlib.h>

int kthSymbolInGrammar(int n, int k);

int kthSymbolInGrammar(int n, int k)
{
  if (n == 1)
  {
    return 0;
  }
  if ((k % 2) == 0)
  {
    return 1 - kthSymbolInGrammar(n - 1, k / 2);
  }
  else
  {
    return kthSymbolInGrammar(n - 1, (k + 1) / 2);
  }
}



int main()
{
  return 0;
}


