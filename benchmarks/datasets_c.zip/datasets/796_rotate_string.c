#include <stdio.h>
#include <stdlib.h>

int canTransform(int sx, int sy, int tx, int ty);

int canTransform(int sx, int sy, int tx, int ty)
{
  while ((sx != tx) || (sy != ty))
  {
    if ((sx > tx) || (sy > ty))
    {
      return 0;
    }
    if (sx < tx)
    {
      tx -= ty;
    }
    else
    {
      ty -= sx;
    }
  }

  return 1;
}



int main()
{
  return 0;
}


