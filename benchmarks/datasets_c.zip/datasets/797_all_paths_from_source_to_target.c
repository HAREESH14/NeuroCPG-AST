#include <stdio.h>
#include <stdlib.h>
/* -- HashMap simulation -- */
#define HASHMAP_SIZE 100
typedef struct { int keys[HASHMAP_SIZE]; int vals[HASHMAP_SIZE]; int count; } HashMap;
HashMap hashmap_create() { HashMap m; m.count=0; return m; }
void hashmap_put(HashMap *m,int k,int v){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k){m->vals[i]=v;return;}m->keys[m->count]=k;m->vals[m->count]=v;m->count++;}
int hashmap_get(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return m->vals[i];return -1;}
int hashmap_contains(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return 1;return 0;}
/* -------------------------*/


int numRabbits(int answers[]);

int numRabbits(int answers[])
{
  HashMap count = hashmap_create();
  int res = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(answers) / sizeof(answers[0])); _fi1++)
  {
    int a = answers[_fi1];
    hashmap_put(&count, a, getOrDefault(a, 0) + 1);
    if (hashmap_get(&count, a) == 1)
    {
      res += a + 1;
    }
    else
      if (hashmap_get(&count, a) > (a + 1))
    {
      hashmap_put(&count, a, 1);
      res += a + 1;
    }
  }

  return res;
}



int main()
{
  return 0;
}


