#include <stdio.h>
#include <stdlib.h>

int rotatedDigits(int n);

int rotatedDigits(int n)
{
  int count = 0;
  for (int i = 1; i <= n; ++i)
  {
    int isValidAfterRotation = 1;
    int isDifferentAfterRotation = 0;
    int num = i;
    while (num != 0)
    {
      int digit = num % 10;
      if (((digit == 3) || (digit == 4)) || (digit == 7))
      {
        isValidAfterRotation = 0;
        break;
      }
      if ((((digit == 2) || (digit == 5)) || (digit == 6)) || (digit == 9))
      {
        isDifferentAfterRotation = 1;
      }
      num /= 10;
    }

    if (isValidAfterRotation && isDifferentAfterRotation)
    {
      count++;
    }
  }

  return count;
}



int main()
{
  return 0;
}


