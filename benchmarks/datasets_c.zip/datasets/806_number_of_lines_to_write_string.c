#include <stdio.h>
#include <stdlib.h>

int numberOfWays(int n);

int numberOfWays(int n)
{
  int MOD = 1000000007;
  int dp[n + 1];
  dp[0] = 1;
  dp[1] = 1;
  for (int i = 2; i <= n; i++)
  {
    dp[i] = (dp[i - 1] + dp[i - 2]) % MOD;
  }

  return dp[n];
}



int main()
{
  return 0;
}


