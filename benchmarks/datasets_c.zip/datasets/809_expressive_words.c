#include <stdio.h>
#include <stdlib.h>

int num_zeros(int k);

int num_zeros(int k)
{
  int x = 0;
  for (int i = 5; (k / i) >= 1; i *= 5)
  {
    x += k / i;
  }

  return x;
}



int main()
{
  return 0;
}


