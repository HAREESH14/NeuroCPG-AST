#include <stdio.h>
#include <stdlib.h>

int numSubarrayBoundedMax(int nums[], int nums_len, int left, int right);

int numSubarrayBoundedMax(int nums[], int nums_len, int left, int right)
{
  int result = 0;
  int prev = 0;
  int start = 1;
  for (int i = 0; i < nums_len; ++i)
  {
    if ((nums[i] >= left) && (nums[i] <= right))
    {
      prev = i - start;
      result += prev;
    }
    else
      if (nums[i] < left)
    {
      result += prev;
    }
    else
    {
      start = i;
      prev = 0;
    }
  }

  return result;
}



int main()
{
  return 0;
}


