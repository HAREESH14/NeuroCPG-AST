#include <stdio.h>
#include <stdlib.h>

int search(int nums[], int nums_len, int target);

int search(int nums[], int nums_len, int target)
{
  int left = 0;
  int right = nums_len - 1;
  while (left <= right)
  {
    int mid = left + ((right - left) / 2);
    if (nums[mid] == target)
    {
      return 1;
    }
    if (nums[mid] == nums[left])
    {
      left++;
    }
    else
      if (nums[mid] > nums[left])
    {
      if ((nums[left] <= target) && (target < nums[mid]))
      {
        right = mid - 1;
      }
      else
      {
        left = mid + 1;
      }
    }
    else
    {
      if ((nums[mid] < target) && (target <= nums[right]))
      {
        left = mid + 1;
      }
      else
      {
        right = mid - 1;
      }
    }
  }

  return 0;
}



int main()
{
  return 0;
}


