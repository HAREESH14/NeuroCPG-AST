#include <stdio.h>
#include <stdlib.h>

int isPossibleToSplit(int nums[], int nums_len);

int isPossibleToSplit(int nums[], int nums_len)
{
  int n = nums_len;
  int total_sum = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    total_sum += num;
  }

  if ((total_sum % n) != 0)
  {
    return 0;
  }
  int target_sum = (total_sum * (n / 2)) / n;
  int dp[(n / 2) + 1][target_sum + 1];
  dp[0][0] = 1;
  for (int _fi2 = 0; _fi2 < (sizeof(nums) / sizeof(nums[0])); _fi2++)
  {
    int num = nums[_fi2];
    for (int count = n / 2; count >= 1; --count)
    {
      for (int sum = target_sum; sum >= num; --sum)
      {
        dp[count][sum] = dp[count][sum] || dp[count - 1][sum - num];
      }

    }

    if (dp[n / 2][target_sum])
    {
      return 1;
    }
  }

  return 0;
}



int main()
{
  return 0;
}


