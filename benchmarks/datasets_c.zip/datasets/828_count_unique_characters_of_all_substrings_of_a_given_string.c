#include <stdio.h>
#include <stdlib.h>

int xorGame(int nums[], int nums_len);

int xorGame(int nums[], int nums_len)
{
  int xorSum = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    xorSum ^= num;
  }

  return (xorSum == 0) || ((nums_len % 2) == 0);
}



int main()
{
  return 0;
}


