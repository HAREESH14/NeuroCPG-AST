#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// Removed C++ header

int backspaceCompare(char* s, char* t) {
    int i = strlen(s) - 1, j = strlen(t) - 1;
    while (1) {
        int back;
        for (back = 0; i >= 0 && (back > 0 || s[i] == '#'); --i) {
            back = 0;
            i >= 0 && (back > 0 || s[i] == '#');
            --i;
            back += s[i] == '#' ? 1 : -1;
        }
        for (back = 0; j >= 0 && (back > 0 || t[j] == '#'); --j) {
            back = 0;
            j >= 0 && (back > 0 || t[j] == '#');
            --j;
            back += t[j] == '#' ? 1 : -1;
        }
        if (i >= 0 && j >= 0 && s[i] == t[j]) {
            i--, j--;
        } else {
            return i == -1 && j == -1;
        }
    }
}

int main() {
    return 0;
}
