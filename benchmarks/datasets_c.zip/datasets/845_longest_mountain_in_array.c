#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int longestMountain(int arr[], int arr_len);

int longestMountain(int arr[], int arr_len)
{
  int n = arr_len;
  int res = 0;
  int up = 0;
  int down = 0;
  for (int i = 1; i < n; ++i)
  {
    if (((down != 0) && (arr[i - 1] < arr[i])) || (arr[i - 1] == arr[i]))
    {
      up = (down = 0);
    }
    if (arr[i - 1] < arr[i])
    {
      up++;
    }
    if (arr[i - 1] > arr[i])
    {
      down++;
    }
    if ((up != 0) && (down != 0))
    {
      res = fmax(res, (up + down) + 1);
    }
  }

  return res;
}



int main()
{
  return 0;
}


