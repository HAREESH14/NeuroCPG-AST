#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxDistToClosest(int seats[], int seats_len);

int maxDistToClosest(int seats[], int seats_len)
{
  int n = seats_len;
  int maxDist = 0;
  int lastPerson = 1;
  for (int i = 0; i < n; ++i)
  {
    if (seats[i] == 1)
    {
      if (lastPerson == 1)
      {
        maxDist = i;
      }
      else
      {
        maxDist = fmax(maxDist, (i - lastPerson) / 2);
      }
      lastPerson = i;
    }
  }

  maxDist = fmax(maxDist, (n - 1) - lastPerson);
  return maxDist;
}



int main()
{
  return 0;
}


