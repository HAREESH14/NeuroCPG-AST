#include <stdio.h>
#include <stdlib.h>

int numFriendRequests(int ages[]);

int numFriendRequests(int ages[])
{
  int count[121];
  int total_requests = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(ages) / sizeof(ages[0])); _fi1++)
  {
    int age = ages[_fi1];
    count[age]++;
  }

  for (int a = 1; a <= 120; a++)
  {
    for (int b = 1; b <= 120; b++)
    {
      if (((a * 0.5) + 7) >= b)
      {
        continue;
      }
      if (a < b)
      {
        continue;
      }
      if (a < (b * 2))
      {
        total_requests += count[a] * count[b];
        if (a == b)
        {
          total_requests -= count[a];
        }
      }
    }

  }

  return total_requests;
}



int main()
{
  return 0;
}


