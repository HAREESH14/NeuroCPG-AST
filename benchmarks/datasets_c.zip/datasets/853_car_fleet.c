#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxProfitAssignment(int difficulty[], int difficulty_len, int profit[], int worker[]);

int maxProfitAssignment(int difficulty[], int difficulty_len, int profit[], int worker[])
{
  int jobIdx[difficulty_len];
  for (int i = 0; i < difficulty_len; i++)
  {
    jobIdx[i] = i;
  }

  sort(jobIdx, comparingInt(0));
  sort(worker);
  int i = 0;
  int maxProfit = 0;
  int totalProfit = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(worker) / sizeof(worker[0])); _fi1++)
  {
    int ability = worker[_fi1];
    while ((i < difficulty_len) && (ability >= difficulty[jobIdx[i]]))
    {
      maxProfit = fmax(maxProfit, profit[jobIdx[i]]);
      i++;
    }

    totalProfit += maxProfit;
  }

  return totalProfit;
}



int main()
{
  return 0;
}


