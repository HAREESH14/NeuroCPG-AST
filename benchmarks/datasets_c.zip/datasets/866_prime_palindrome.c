#include <stdio.h>
#include <stdlib.h>

int isRectangleOverlap(int rec1[], int rec2[]);

int isRectangleOverlap(int rec1[], int rec2[])
{
  return (((rec1[2] > rec2[0]) && (rec1[3] > rec2[1])) && (rec1[0] < rec2[2])) && (rec1[1] < rec2[3]);
}



int main()
{
  return 0;
}


