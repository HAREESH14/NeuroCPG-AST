#include <stdio.h>
#include <stdlib.h>

double new21Game(int n, int k, int maxPts);

double new21Game(int n, int k, int maxPts)
{
  if ((k == 0) || (n >= (k + maxPts)))
  {
    return 1;
  }
  double dp[n + 1];
  dp[0] = 1;
  double sum = 1;
  double ans = 0;
  for (int i = 1; i <= n; i++)
  {
    dp[i] = sum / maxPts;
    if (i < k)
    {
      sum += dp[i];
    }
    else
    {
      ans += dp[i];
    }
    if (i >= maxPts)
    {
      sum -= dp[i - maxPts];
    }
  }

  return ans;
}



int main()
{
  return 0;
}


