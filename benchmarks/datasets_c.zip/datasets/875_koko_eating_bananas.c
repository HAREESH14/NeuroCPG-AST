#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int longestMountain(int arr[], int arr_len);

int longestMountain(int arr[], int arr_len)
{
  int n = arr_len;
  int maxLength = 0;
  int i = 1;
  while (i < (n - 1))
  {
    if ((arr[i - 1] < arr[i]) && (arr[i] > arr[i + 1]))
    {
      int left = i - 1;
      int right = i + 1;
      while ((left > 0) && (arr[left - 1] < arr[left]))
      {
        left--;
      }

      while ((right < (n - 1)) && (arr[right] > arr[right + 1]))
      {
        right++;
      }

      maxLength = fmax(maxLength, (right - left) + 1);
      i = right;
    }
    else
    {
      i++;
    }
  }

  return maxLength;
}



int main()
{
  return 0;
}


