#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* shiftingLetters(char* s, int shifts[]);

char* shiftingLetters(char* s, int shifts[])
{
  int n = strlen(s);
  for (int i = n - 2; i >= 0; i--)
  {
    shifts[i] = (shifts[i] + shifts[i + 1]) % 26;
  }

  char result[n];
  for (int i = 0; i < n; i++)
  {
    result[i] = (char) ((((s[i] - 'a') + shifts[i]) % 26) + 'a');
  }

  return String();
}


