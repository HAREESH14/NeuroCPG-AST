#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int maxDistToClosest(int seats[], int seats_len);

int maxDistToClosest(int seats[], int seats_len)
{
  int maxDist = 0;
  int lastPerson = 1;
  for (int i = 0; i < seats_len; ++i)
  {
    if (seats[i] == 1)
    {
      maxDist = (lastPerson < 0 ? i : fmax(maxDist, (i - lastPerson) / 2));
      lastPerson = i;
    }
  }

  return fmax(maxDist, (seats_len - 1) - lastPerson);
}



int main()
{
  return 0;
}


