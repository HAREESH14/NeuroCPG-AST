#include <stdio.h>
#include <stdlib.h>

int peakIndexInMountainArray(int arr[], int arr_len);

int peakIndexInMountainArray(int arr[], int arr_len)
{
  int low = 0;
  int high = arr_len - 1;
  while (low < high)
  {
    int mid = low + ((high - low) / 2);
    if (arr[mid] < arr[mid + 1])
    {
      low = mid + 1;
    }
    else
    {
      high = mid;
    }
  }

  return low;
}



int main()
{
  return 0;
}


