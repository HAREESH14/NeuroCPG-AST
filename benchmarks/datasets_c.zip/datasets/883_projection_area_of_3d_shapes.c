#include <stdio.h>
#include <stdlib.h>

int carFleet(int target, int position[], int position_len, int speed[]);

int carFleet(int target, int position[], int position_len, int speed[])
{
  int n = position_len;
  int indices[n];
  for (int i = 0; i < n; i++)
  {
    indices[i] = i;
  }

  // sort(indices); // Needs manual sort implementation
  int fleets = 0;
  double lastArrival = 1;
  for (int _fi1 = 0; _fi1 < (sizeof(indices) / sizeof(indices[0])); _fi1++)
  {
    int i = indices[_fi1];
    double arrival = ((double) (target - position[i])) / speed[i];
    if (arrival > lastArrival)
    {
      fleets++;
      lastArrival = arrival;
    }
  }

  return fleets;
}



int main()
{
  return 0;
}


