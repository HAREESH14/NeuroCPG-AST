#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int scoreOfParentheses(char* s);

int scoreOfParentheses(char* s)
{
  int score = 0;
  int depth = 0;
  for (int i = 0; i < strlen(s); i++)
  {
    if (s[i] == '(')
    {
      depth++;
    }
    else
    {
      depth--;
      if (s[i - 1] == '(')
      {
        score += 1 << depth;
      }
    }
  }

  return score;
}



int main()
{
  return 0;
}


