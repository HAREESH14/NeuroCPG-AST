#include <stdio.h>
#include <stdlib.h>

int mirrorReflection(int p, int q);

int mirrorReflection(int p, int q)
{
  int m = p;
  int n = q;
  int gcd;
  while (n != 0)
  {
    gcd = m % n;
    m = n;
    n = gcd;
  }

  if (((p / m) % 2) == 0)
  {
    return 2;
  }
  if (((q / m) % 2) == 0)
  {
    return 0;
  }
  return 1;
}



int main()
{
  return 0;
}


