#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int areAlmostEqual(char* s, char* goal);

int areAlmostEqual(char* s, char* goal)
{
  if (strcmp(s, goal) == 0)
  {
    return 1;
  }
  int count = 0;
  int index1 = 1;
  int index2 = 1;
  for (int i = 0; i < strlen(s); i++)
  {
    if (s[i] != goal[i])
    {
      count++;
      if (index1 == 1)
      {
        index1 = i;
      }
      else
      {
        index2 = i;
      }
      if (count > 2)
      {
        return 0;
      }
    }
  }

  return ((count == 2) && (s[index1] == goal[index2])) && (s[index2] == goal[index1]);
}



int main()
{
  return 0;
}


