#include <stdio.h>
#include <stdlib.h>

int lemonadeChange(int bills[]);

int lemonadeChange(int bills[])
{
  int five = 0;
  int ten = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(bills) / sizeof(bills[0])); _fi1++)
  {
    int bill = bills[_fi1];
    if (bill == 5)
    {
      five++;
    }
    else
      if (bill == 10)
    {
      if (five == 0)
      {
        return 0;
      }
      five--;
      ten++;
    }
    else
    {
      if ((ten > 0) && (five > 0))
      {
        ten--;
        five--;
      }
      else
        if (five >= 3)
      {
        five -= 3;
      }
      else
      {
        return 0;
      }
    }
  }

  return 1;
}



int main()
{
  return 0;
}


