#include <stdio.h>
#include <stdlib.h>

int isPrime(int n);
int isPalindrome(int n);
int primePalindrome(int n);

int isPrime(int n)
{
  if (n <= 1)
  {
    return 0;
  }
  for (int i = 2; (i * i) <= n; i++)
  {
    if ((n % i) == 0)
    {
      return 0;
    }
  }

  return 1;
}



int isPalindrome(int n)
{
  int rev = 0;
  int orig = n;
  while (n > 0)
  {
    rev = (rev * 10) + (n % 10);
    n /= 10;
  }

  return orig == rev;
}



int primePalindrome(int n)
{
  while (1)
  {
    if (isPrime(n) && isPalindrome(n))
    {
      return n;
    }
    n++;
  }

}



int main()
{
  return 0;
}


