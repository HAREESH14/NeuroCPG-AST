#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int longestDistance(int n);

int longestDistance(int n)
{
  int last = 1;
  int longest = 0;
  for (int i = 0; n > 0; n >>= 1, i++)
  {
    if ((n & 1) == 1)
    {
      if (last >= 0)
      {
        longest = fmax(longest, i - last);
      }
      last = i;
    }
  }

  return longest;
}



int main()
{
  return 0;
}


