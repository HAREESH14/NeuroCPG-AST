#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minEatingSpeed(int piles[], int h);

int minEatingSpeed(int piles[], int h)
{
  int left = 1;
  int right = 1;
  for (int _fi1 = 0; _fi1 < (sizeof(piles) / sizeof(piles[0])); _fi1++)
  {
    int pile = piles[_fi1];
    right = fmax(right, pile);
  }

  while (left < right)
  {
    int mid = left + ((right - left) / 2);
    int totalHours = 0;
    for (int _fi2 = 0; _fi2 < (sizeof(piles) / sizeof(piles[0])); _fi2++)
    {
      int pile = piles[_fi2];
      totalHours += ((pile + mid) - 1) / mid;
    }

    if (totalHours > h)
    {
      left = mid + 1;
    }
    else
    {
      right = mid;
    }
  }

  return left;
}



int main()
{
  return 0;
}


