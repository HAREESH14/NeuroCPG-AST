#include <stdio.h>
#include <stdlib.h>

int nthMagicalNumber(int n, int a, int b);
int gcd(int a, int b);

int nthMagicalNumber(int n, int a, int b)
{
  long mod = 1000000007;
  long lcm = (a * b) / gcd(a, b);
  long left = 1;
  long right = (long) 1e14;
  long mid;
  while (left < right)
  {
    mid = left + ((right - left) / 2);
    if ((((mid / a) + (mid / b)) - (mid / lcm)) < n)
    {
      left = mid + 1;
    }
    else
    {
      right = mid;
    }
  }

  return (int) (left % mod);
}



int gcd(int a, int b)
{
  return (b == 0 ? a : gcd(b, a % b));
}



int main()
{
  return 0;
}


