#include <stdio.h>
#include <stdlib.h>

int numRescueBoats(int people[], int people_len, int limit);

int numRescueBoats(int people[], int people_len, int limit)
{
  sort(people);
  int left = 0;
  int right = people_len - 1;
  int boats = 0;
  while (left <= right)
  {
    if ((people[left] + people[right]) <= limit)
    {
      left++;
    }
    right--;
    boats++;
  }

  return boats;
}



int main()
{
  return 0;
}


