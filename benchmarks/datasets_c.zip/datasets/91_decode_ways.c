#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int numDecodings(char* s);

int numDecodings(char* s)
{
  int n = strlen(s);
  int dp[n + 1];
  dp[0] = 1;
  dp[1] = (s[0] != '0' ? 1 : 0);
  for (int i = 2; i <= n; i++)
  {
    int oneDigit = atoi(s + (i - 1));
    int twoDigits = atoi(s + (i - 2));
    if (oneDigit >= 1)
    {
      dp[i] += dp[i - 1];
    }
    if ((twoDigits >= 10) && (twoDigits <= 26))
    {
      dp[i] += dp[i - 2];
    }
  }

  return dp[n];
}



int main()
{
  return 0;
}


