#include <stdio.h>
#include <stdlib.h>

const int MOD = 1000000007;

int sumOfWidths(int nums[], int nums_len);

int sumOfWidths(int nums[], int nums_len)
{
  sort(nums);
  int n = nums_len;
  long res = 0;
  long c = 1;
  for (int i = 0; i < n; i++, c = (c * 2) % MOD)
  {
    res = (res + ((nums[i] - nums[(n - i) - 1]) * c)) % MOD;
  }

  return (int) res;
}


