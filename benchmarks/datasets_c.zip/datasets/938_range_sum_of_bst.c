#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int numDigitsLessThanN(int digits[], int n);

int numDigitsLessThanN(int digits[], int n)
{
  int ans = 0;
  int factor = 1;
  char* nStr = n;
  for (int i = strlen(nStr) - 1; i >= 0; --i)
  {
    ans += (binarySearch(digits, nStr[i] - '0') + 1) * factor;
    factor *= strlen(digits);
  }

  return ans;
}



int main()
{
  return 0;
}


