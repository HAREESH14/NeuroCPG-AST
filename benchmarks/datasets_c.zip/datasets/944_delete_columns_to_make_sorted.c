#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minDifference(int nums[], int nums_len, int k);

int minDifference(int nums[], int nums_len, int k)
{
  if (nums_len <= 1)
  {
    return 0;
  }
  sort(nums);
  int min_diff = nums[nums_len - 1] - nums[0];
  for (int i = 1; i < nums_len; i++)
  {
    int high = fmax(nums[i - 1] + k, nums[nums_len - 1] - k);
    int low = fmin(nums[i] - k, nums[0] + k);
    min_diff = fmin(min_diff, high - low);
  }

  return min_diff;
}



int main()
{
  return 0;
}


