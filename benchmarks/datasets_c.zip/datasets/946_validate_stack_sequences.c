#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minimumScore(int nums[], int nums_len, int k);

int minimumScore(int nums[], int nums_len, int k)
{
  sort(nums);
  int n = nums_len;
  int res = nums[n - 1] - nums[0];
  for (int i = 0; i < (n - 1); i++)
  {
    int high = fmax(nums[i] + k, nums[n - 1] - k);
    int low = fmin(nums[i + 1] - k, nums[0] + k);
    res = fmin(res, high - low);
  }

  return res;
}



int main()
{
  return 0;
}


