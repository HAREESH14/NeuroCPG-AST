#include <stdio.h>
#include <stdlib.h>

void sortArray(int nums[]);

void sortArray(int nums[])
{
  sort(nums);
}



int main()
{
  return 0;
}


