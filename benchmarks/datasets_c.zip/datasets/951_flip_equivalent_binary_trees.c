#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int partitionDisjoint(int nums[], int nums_len);

int partitionDisjoint(int nums[], int nums_len)
{
  int leftMax = nums[0];
  int globalMax = nums[0];
  int leftLength = 1;
  for (int i = 1; i < nums_len; ++i)
  {
    if (nums[i] < leftMax)
    {
      leftMax = globalMax;
      leftLength = i + 1;
    }
    else
    {
      globalMax = fmax(globalMax, nums[i]);
    }
  }

  return leftLength;
}



int main()
{
  return 0;
}


