#include <stdio.h>
#include <stdlib.h>

int sortArrayByParityII(int nums[], int nums_len);

int sortArrayByParityII(int nums[], int nums_len)
{
  int j = 1;
  for (int i = 0; i < nums_len; i += 2)
  {
    if ((nums[i] % 2) != 0)
    {
      while ((nums[j] % 2) != 0)
      {
        j += 2;
      }

      int temp = nums[i];
      nums[i] = nums[j];
      nums[j] = temp;
    }
  }

  return nums;
}



int main()
{
  return 0;
}


