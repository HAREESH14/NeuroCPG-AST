#include <stdio.h>
#include <stdlib.h>

int threeSumMulti(int arr[], int arr_len, int target);

int threeSumMulti(int arr[], int arr_len, int target)
{
  int MOD = 1000000007;
  long ans = 0;
  sort(arr);
  int n = arr_len;
  for (int i = 0; i < (n - 2); ++i)
  {
    int j = i + 1;
    int k = n - 1;
    while (j < k)
    {
      int sum = (arr[i] + arr[j]) + arr[k];
      if (sum > target)
      {
        k--;
      }
      else
        if (sum < target)
      {
        j++;
      }
      else
      {
        if (arr[j] != arr[k])
        {
          int left_count = 1;
          int right_count = 1;
          while ((j < (n - 1)) && (arr[j] == arr[j + 1]))
          {
            left_count++;
            j++;
          }

          while ((k > 0) && (arr[k] == arr[k - 1]))
          {
            right_count++;
            k--;
          }

          ans += ((long) left_count) * right_count;
          ans %= MOD;
          j++;
          k--;
        }
        else
        {
          ans += (((long) ((k - j) + 1)) * (k - j)) / 2;
          ans %= MOD;
          break;
        }
      }
    }

  }

  return (int) ans;
}



int main()
{
  return 0;
}


