#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int isLongPressedName(char* name, char* typed);

int isLongPressedName(char* name, char* typed)
{
  int i = 0;
  int j = 0;
  while (j < strlen(typed))
  {
    if ((i < strlen(name)) && (name[i] == typed[j]))
    {
      i++;
    }
    else
      if ((j == 0) || (typed[j] != typed[j - 1]))
    {
      return 0;
    }
    j++;
  }

  return i == strlen(name);
}



int main()
{
  return 0;
}


