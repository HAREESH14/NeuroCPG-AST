#include <stdio.h>
#include <stdlib.h>

int findSameBinaryValueParts(int arr[], int arr_len);

int findSameBinaryValueParts(int arr[], int arr_len)
{
  int ones = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(arr) / sizeof(arr[0])); _fi1++)
  {
    int n = arr[_fi1];
    ones += n;
  }

  if ((ones % 3) != 0)
  {
    return 1, 1;
  }
  int target = ones / 3;
  if (target == 0)
  {
    return 0, arr_len - 2;
  }
  int count = 0;
  int i = 1;
  int j = 1;
  ones = 0;
  for (int idx = 0; idx < arr_len; ++idx)
  {
    if (arr[idx] == 1)
    {
      ones++;
      if (ones == (target + 1))
      {
        count++;
      }
      if ((count == 1) && (i == 1))
      {
        i = idx;
      }
      if ((count == 2) && (j == 1))
      {
        j = idx;
      }
      if (count == 3)
      {
        break;
      }
    }
  }

  return i, j;
}



int main()
{
  return 0;
}


