#include <stdio.h>
#include <stdlib.h>
/* -- HashMap simulation -- */
#define HASHMAP_SIZE 100
typedef struct { int keys[HASHMAP_SIZE]; int vals[HASHMAP_SIZE]; int count; } HashMap;
HashMap hashmap_create() { HashMap m; m.count=0; return m; }
void hashmap_put(HashMap *m,int k,int v){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k){m->vals[i]=v;return;}m->keys[m->count]=k;m->vals[m->count]=v;m->count++;}
int hashmap_get(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return m->vals[i];return -1;}
int hashmap_contains(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return 1;return 0;}
/* -------------------------*/


int numSubarraysWithSum(int nums[], int goal);

int numSubarraysWithSum(int nums[], int goal)
{
  HashMap prefixSumCount = hashmap_create();
  hashmap_put(&prefixSumCount, 0, 1);
  int sum = 0;
  int result = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(nums) / sizeof(nums[0])); _fi1++)
  {
    int num = nums[_fi1];
    sum += num;
    result += getOrDefault(sum - goal, 0);
    hashmap_put(&prefixSumCount, sum, getOrDefault(sum, 0) + 1);
  }

  return result;
}



int main()
{
  return 0;
}


