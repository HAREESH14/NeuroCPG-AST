#include <stdio.h>
#include <stdlib.h>

int subarraysDivByK(int nums[], int nums_len, int k);

int subarraysDivByK(int nums[], int nums_len, int k)
{
  int prefixSumsModK[k];
  prefixSumsModK[0] = 1;
  int runningSum = 0;
  int count = 0;
  for (int i = 0; i < nums_len; ++i)
  {
    runningSum += nums[i];
    int mod = ((runningSum % k) + k) % k;
    count += prefixSumsModK[mod]++;
  }

  return count;
}



int main()
{
  return 0;
}


