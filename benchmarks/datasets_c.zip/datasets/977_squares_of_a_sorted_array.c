#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int distinctSubseqII(char* s);

int distinctSubseqII(char* s)
{
  int mod = (int) (1e9 + 7);
  int n = strlen(s);
  int dp[n + 1];
  dp[0] = 1;
  int last[26];
  fill(last, 1);
  for (int i = 1; i <= n; ++i)
  {
    dp[i] = (dp[i - 1] * 2) % mod;
    if (last[s[i - 1] - 'a'] != 1)
    {
      dp[i] = ((dp[i] - dp[last[s[i - 1] - 'a']]) + mod) % mod;
    }
    last[s[i - 1] - 'a'] = i - 1;
  }

  dp[n] = ((dp[n] - 1) + mod) % mod;
  return dp[n];
}



int main()
{
  return 0;
}


