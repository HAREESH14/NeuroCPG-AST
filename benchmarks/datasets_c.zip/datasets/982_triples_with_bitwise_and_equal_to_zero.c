#include <stdio.h>
#include <stdlib.h>

int minMovesUnique(int nums[], int nums_len);

int minMovesUnique(int nums[], int nums_len)
{
  sort(nums);
  int moves = 0;
  for (int i = 1; i < nums_len; i++)
  {
    if (nums[i] <= nums[i - 1])
    {
      moves += (nums[i - 1] - nums[i]) + 1;
      nums[i] = nums[i - 1] + 1;
    }
  }

  return moves;
}



int main()
{
  return 0;
}


