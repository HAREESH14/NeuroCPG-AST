#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int bagOfTokensScore(int tokens[], int tokens_len, int power);

int bagOfTokensScore(int tokens[], int tokens_len, int power)
{
  sort(tokens);
  int score = 0;
  int maxScore = 0;
  int left = 0;
  int right = tokens_len - 1;
  while (left <= right)
  {
    if (power >= tokens[left])
    {
      power -= tokens[left++];
      score++;
      maxScore = fmax(maxScore, score);
    }
    else
      if (score > 0)
    {
      power += tokens[right--];
      score--;
    }
    else
    {
      break;
    }
  }

  return maxScore;
}



int main()
{
  return 0;
}


