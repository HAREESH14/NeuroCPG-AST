#include <stdio.h>
#include <stdlib.h>

char* largestTimeFromDigits(int A[]);

char* largestTimeFromDigits(int A[])
{
  sort(A);
  for (int i = 3; i >= 0; i--)
  {
    if (A[i] <= 2)
    {
      for (int j = 3; j >= 0; j--)
      {
        if (((A[i] != 2) || (A[j] <= 3)) && (A[j] != A[i]))
        {
          for (int k = 3; k >= 0; k--)
          {
            if (((A[k] <= 5) && (A[k] != A[i])) && (A[k] != A[j]))
            {
              int l = ((6 - i) - j) - k;
              return format("%d%d:%d%d", A[i], A[j], A[k], A[l]);
            }
          }

        }
      }

    }
  }

  return "";
}



int main()
{
  return 0;
}


