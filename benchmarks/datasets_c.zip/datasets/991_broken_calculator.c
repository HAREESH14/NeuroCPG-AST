#include <stdio.h>
#include <stdlib.h>
/* -- HashMap simulation -- */
#define HASHMAP_SIZE 100
typedef struct { int keys[HASHMAP_SIZE]; int vals[HASHMAP_SIZE]; int count; } HashMap;
HashMap hashmap_create() { HashMap m; m.count=0; return m; }
void hashmap_put(HashMap *m,int k,int v){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k){m->vals[i]=v;return;}m->keys[m->count]=k;m->vals[m->count]=v;m->count++;}
int hashmap_get(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return m->vals[i];return -1;}
int hashmap_contains(HashMap *m,int k){int i;for(i=0;i<m->count;i++)if(m->keys[i]==k)return 1;return 0;}
/* -------------------------*/


int canReorderArray(int arr[]);

int canReorderArray(int arr[])
{
  HashMap count = hashmap_create();
  for (int _fi1 = 0; _fi1 < (sizeof(arr) / sizeof(arr[0])); _fi1++)
  {
    int n = arr[_fi1];
    hashmap_put(&count, n, getOrDefault(n, 0) + 1);
  }

  sort(arr);
  for (int _fi2 = 0; _fi2 < (sizeof(arr) / sizeof(arr[0])); _fi2++)
  {
    int x = arr[_fi2];
    if (hashmap_get(&count, x) == 0)
    {
      continue;
    }
    if (getOrDefault(2 * x, 0) > 0)
    {
      hashmap_put(&count, x, hashmap_get(&count, x) - 1);
      hashmap_put(&count, 2 * x, hashmap_get(&count, 2 * x) - 1);
    }
    else
    {
      return 0;
    }
  }

  return 1;
}



int main()
{
  return 0;
}


