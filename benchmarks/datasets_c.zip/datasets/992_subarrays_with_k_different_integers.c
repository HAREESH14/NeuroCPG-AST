#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int minDeletionSize(char* strs[], int strs_len);

int minDeletionSize(char* strs[], int strs_len)
{
  int n = strs_len;
  int m = strs[0];
  int dp[m];
  for (int j = 0; j < m; ++j)
  {
    dp[j] = 1;
    for (int i = 0; i < j; ++i)
    {
      int flag = 1;
      for (int k = 0; k < (n - 1); ++k)
      {
        flag = flag && (strs[k] <= strs[k]);
      }

      dp[j] = (flag ? fmax(dp[j], dp[i] + 1) : dp[j]);
    }

  }

  int maxLength = 0;
  for (int _fi1 = 0; _fi1 < (sizeof(dp) / sizeof(dp[0])); _fi1++)
  {
    int num = dp[_fi1];
    maxLength = fmax(maxLength, num);
  }

  return m - maxLength;
}


