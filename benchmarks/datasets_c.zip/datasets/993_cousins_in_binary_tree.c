#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int tallestBillboard(int rods[], int rods_len);

int tallestBillboard(int rods[], int rods_len)
{
  int n = rods_len;
  int totalLength = stream(rods);
  int dp[n + 1][totalLength + 1];
  for (int i = 0; i < (n + 1); i++)
  {
    fill(dp[i], 1);
  }

  dp[0][0] = 0;
  for (int i = 1; i <= n; i++)
  {
    for (int j = 0; j <= totalLength; j++)
    {
      dp[i][j] = dp[i - 1][j];
      if (rods[i - 1] <= j)
      {
        dp[i][j] = fmax(dp[i][j], dp[i - 1][j - rods[i - 1]] + rods[i - 1]);
      }
      if (rods[i - 1] <= (totalLength - j))
      {
        dp[i][j] = fmax(dp[i][j], dp[i - 1][j + rods[i - 1]]);
      }
    }

  }

  return dp[n][0] / 2;
}



int main()
{
  return 0;
}


