#include <stdio.h>
#include <stdlib.h>

int prisonAfterNDays(int cells[], int n);

int prisonAfterNDays(int cells[], int n)
{
  int temp[8];
  n = ((n % 14) == 0 ? 14 : n % 14);
  for (int i = 1; i <= n; ++i)
  {
    for (int j = 1; j < 7; ++j)
    {
      temp[j] = (cells[j - 1] == cells[j + 1] ? 1 : 0);
    }

    cells = clone();
  }

  return cells;
}



int main()
{
  return 0;
}


