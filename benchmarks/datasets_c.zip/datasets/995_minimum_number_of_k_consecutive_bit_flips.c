#include <stdio.h>
#include <stdlib.h>

int minKBitFlips(int nums[], int nums_len, int k);

int minKBitFlips(int nums[], int nums_len, int k)
{
  int n = nums_len;
  int flipped[n];
  int flips = 0;
  int ans = 0;
  for (int i = 0; i < n; ++i)
  {
    if (i >= k)
    {
      flips -= flipped[i - k];
    }
    if (((flips + nums[i]) % 2) == 0)
    {
      if ((i + k) > n)
      {
        return 1;
      }
      flipped[i] = 1;
      flips++;
      ans++;
    }
  }

  return ans;
}



int main()
{
  return 0;
}


